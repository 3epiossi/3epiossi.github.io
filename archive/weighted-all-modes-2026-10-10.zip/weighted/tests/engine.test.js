import test from "node:test";
import assert from "node:assert/strict";
import { GameEngine } from "../src/core/game-engine.js";
import { BLACK, WHITE } from "../src/core/constants.js";
import { remainingBag, weightOf, computeScores } from "../src/core/rules.js";
import { mulberry32, playGame } from "./helpers.js";

const newEngine = (seed = 7) => new GameEngine({ rng: mulberry32(seed) });

test("開局：黑先手、手上有一顆棋、盤上 4 顆、袋中 59 顆", () => {
  const e = newEngine();
  assert.equal(e.currentTurn, BLACK);
  assert.notEqual(e.hand, null);
  assert.equal(e.bagSize(), 59);
  assert.equal(e.board.flat().filter(Boolean).length, 4);
});

test("落子時手上的棋以下棋者的顏色朝上，並換到對手並重新抽棋", () => {
  const e = newEngine();
  const m = e.legalMoves()[0];
  const handBefore = e.hand;
  assert.ok(e.executeMove(m.r, m.c));
  assert.equal(e.board[m.r][m.c].id, handBefore);
  assert.equal(e.board[m.r][m.c].face, BLACK);
  assert.equal(e.currentTurn, WHITE);
  assert.notEqual(e.hand, handBefore);
});

test("非法位置不會改變狀態", () => {
  const e = newEngine();
  const before = JSON.stringify(e.board);
  assert.equal(e.executeMove(0, 0), false);
  assert.equal(JSON.stringify(e.board), before);
});

test("自動對局可以打完：棋盤與歷史一致、64 顆棋不重複", () => {
  const e = playGame({ seed: 3 });
  assert.ok(e.gameOver);
  const ids = e.board.flat().filter(Boolean).map(d => d.id);
  assert.equal(new Set(ids).size, ids.length);
  assert.equal(remainingBag(e.board, null).length + ids.length, 64);
  assert.ok(e.settlementData);
  const tip = e.tree.getBranchTipNode();
  assert.equal(tip.gameOver, true);
});

test("PASS：抽到的棋放回袋子，輪到對手", () => {
  const e = newEngine();
  e.board = e.board.map(row => row.map(() => null)); // 清空後沒有任何合法步
  e.currentTurn = BLACK;
  assert.equal(e.legalMoves().length, 0);
  const bagBefore = e.bagSize();
  e.passTurn();
  assert.equal(e.gameOver, true); // 雙方都沒有合法位置 → 終局
  assert.ok(e.bagSize() >= bagBefore);
});

test("時光機：跳回歷史節點可還原棋盤、輪次與手上的棋", () => {
  const e = newEngine(11);
  const root = e.tree.getCurrentNode();
  const rootBoard = JSON.stringify(e.board);
  const rootHand = e.hand;
  const m = e.legalMoves()[0];
  e.executeMove(m.r, m.c);
  assert.ok(e.jumpToNode(root.id));
  assert.equal(JSON.stringify(e.board), rootBoard);
  assert.equal(e.hand, rootHand);
  assert.equal(e.currentTurn, BLACK);
});

test("歷史局面不能直接落子；從這裡開始下會建立新分支並保留原路線", () => {
  const e = newEngine(5);
  const root = e.tree.getCurrentNode();
  const m = e.legalMoves()[0];
  e.executeMove(m.r, m.c);
  const mainLen = e.tree.getBranchHistory().length;

  e.jumpToNode(root.id);
  const m2 = e.legalMoves()[0];
  assert.equal(e.executeMove(m2.r, m2.c), false); // 非端點

  e.startFromHere(root.id);
  assert.equal(e.tree.branches.size, 2);
  assert.ok(e.executeMove(m2.r, m2.c));
  e.tree.switchBranch("main");
  assert.equal(e.tree.getBranchHistory().length, mainLen);
});

test("自由排盤：棋從袋子取、不重複；完成後重建 #0 並指定先手", () => {
  const e = newEngine(9);
  e.setupCell(0, 0, "black");
  e.setupCell(0, 1, "white");
  e.setupCell(0, 0, "toggle"); // 黑 → 白
  assert.equal(e.board[0][0].face, WHITE);
  e.setupCell(0, 0, "toggle"); // 白 → 清除
  assert.equal(e.board[0][0], null);
  const ids = e.board.flat().filter(Boolean).map(d => d.id);
  assert.equal(new Set(ids).size, ids.length);

  e.commitSetup(WHITE);
  assert.equal(e.currentTurn, WHITE);
  assert.equal(e.tree.nodes.size, 1);
  assert.ok(e.board[0][1]);
});

test("計分帳：落子後黑方增加 = 落下那面 + 每顆翻面的黑白權重差；白方同量減少", () => {
  const e = newEngine(2);
  const before = computeScores(e.board);
  const m = e.legalMoves()[0];
  const placedBlack = weightOf(e.hand, BLACK);
  let swing = 0, whiteLost = 0;
  for (const [fr, fc] of m.flips) {
    const id = e.board[fr][fc].id;
    swing += weightOf(id, BLACK);
    whiteLost += weightOf(id, WHITE);
  }
  e.executeMove(m.r, m.c);
  const after = computeScores(e.board);
  assert.equal(after.black - before.black, placedBlack + swing);
  assert.equal(before.white - after.white, whiteLost);
});
