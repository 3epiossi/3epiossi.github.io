import test from "node:test";
import assert from "node:assert/strict";
import { BLACK, WHITE } from "../src/core/constants.js";
import { GameEngine } from "../src/core/game-engine.js";
import {
  classifyPattern, findPatterns, bonusOfPatterns, BONUS_LEVELS, normalizeBonusLevel
} from "../src/core/bonus.js";
import { createEmptyBoard, createDisc, discId, remainingBag, applyMoveToBoard, getLegalMoves, opp, isBoardFull, hasLegalMove, computeScores } from "../src/core/rules.js";
import { searchRoot } from "../src/ai/v6/search.js";
import { searchRootV7, V7_PARAMS } from "../src/ai/v7/search.js";
import { PARAMS } from "../src/ai/v6/eval.js";
import { findBestMoveForCPU } from "../src/ai/ai-service.js";
import { mulberry32 } from "./helpers.js";

const LOW = BONUS_LEVELS.low;

test("牌型判定：三條、有序順子（遞增 / 遞減）、湊十；無序順子不算", () => {
  assert.equal(classifyPattern(5, 5, 5), "trips");
  assert.equal(classifyPattern(3, 4, 5), "ordered");
  assert.equal(classifyPattern(6, 5, 4), "ordered");
  assert.equal(classifyPattern(1, 2, 7), "ten");
  assert.equal(classifyPattern(3, 3, 4), "ten");
  assert.equal(classifyPattern(5, 3, 4), null);
  assert.equal(classifyPattern(1, 5, 8), null);
});

test("加分 = 各組總和 × 組數（Combo ×2、×3）", () => {
  const P = BONUS_LEVELS.mid; // 4 / 8 / 16
  assert.equal(bonusOfPatterns([], P), 0);
  assert.equal(bonusOfPatterns([{ type: "ordered" }], P), 8);
  assert.equal(bonusOfPatterns([{ type: "ordered" }, { type: "ten" }], P), (8 + 4) * 2);
  assert.equal(bonusOfPatterns([{ type: "trips" }, { type: "ten" }, { type: "ten" }], P), (16 + 4 + 4) * 3);
  assert.equal(bonusOfPatterns([{ type: "trips" }], null), 0);
});

test("加分等級：無效值一律當作無加分", () => {
  assert.equal(normalizeBonusLevel("mid"), "mid");
  assert.equal(normalizeBonusLevel("xxx"), "off");
  assert.equal(BONUS_LEVELS.off, null);
});

test("只算經過新棋、三格都是己方的直線三連", () => {
  const b = createEmptyBoard();
  // 第 1 列：黑 3、黑 4、（新）黑 5 → 有序順子；第 2 列同一欄有白棋，不構成三連
  b[0][0] = createDisc(discId(1, 3), BLACK);
  b[0][1] = createDisc(discId(1, 4), BLACK);
  b[0][2] = createDisc(discId(2, 5), BLACK);
  b[1][2] = createDisc(discId(5, 5), WHITE);
  b[2][2] = createDisc(discId(5, 5 - 1), BLACK);
  const found = findPatterns(b, 0, 2, BLACK);
  assert.deepEqual(found.map(p => p.type), ["ordered"]);
  assert.deepEqual(found[0].cells, [[0, 0], [0, 1], [0, 2]]);
});

test("引擎：加分入袋、被翻也不扣；時光機會還原累計加分；終局以總分判勝負", () => {
  const e = new GameEngine({ rng: mulberry32(12), bonusLevel: "high" });
  let sawBonus = false;
  let nodeWithBonus = null;
  while (!e.gameOver) {
    const m = e.legalMoves();
    if (!m.length) { e.passTurn(); continue; }
    const before = { ...e.bonus };
    const player = e.currentTurn;
    const pick = m[0];
    e.executeMove(pick.r, pick.c);
    const gained = e.bonus[player] - before[player];
    if (e.lastMove.bonus) {
      sawBonus = true;
      assert.equal(gained, e.lastMove.bonus.points);
      if (!nodeWithBonus) nodeWithBonus = { id: e.tree.currentNodeId, bonus: { ...e.bonus } };
    } else {
      assert.equal(gained, 0);
    }
    assert.ok(e.bonus[opp(player)] >= before[opp(player)]); // 對手的加分不會被扣
  }
  assert.ok(sawBonus, "這局應該至少出現一次牌型");
  const s = e.settlementData;
  assert.equal(s.totalBlack, s.black + s.bonusBlack);
  assert.equal(s.totalWhite, s.white + s.bonusWhite);
  assert.equal(s.winner, s.totalBlack === s.totalWhite ? 0 : s.totalBlack > s.totalWhite ? BLACK : WHITE);
  e.jumpToNode(nodeWithBonus.id);
  assert.deepEqual(e.bonus, nodeWithBonus.bonus);
});

test("無加分模式：不記錄牌型，總分等於權重", () => {
  const e = new GameEngine({ rng: mulberry32(5) });
  while (!e.gameOver) {
    const m = e.legalMoves();
    if (!m.length) { e.passTurn(); continue; }
    e.executeMove(m[0].r, m[0].c);
    assert.equal(e.lastMove.bonus, undefined);
  }
  assert.equal(e.settlementData.bonusBlack, 0);
  assert.equal(e.settlementData.totalBlack, e.settlementData.black);
});

test("v7 搜尋中的加分與規則層判定完全一致（第一層：v7 分數 − v6 分數 = 這步加分）", () => {
  let checked = 0;
  for (let g = 0; g < 6; g++) {
    const e = new GameEngine({ rng: mulberry32(g), bonusLevel: "mid" });
    while (!e.gameOver) {
      const moves = e.legalMoves();
      if (!moves.length) { e.passTurn(); continue; }
      const base = { board: e.board, player: e.currentTurn, handId: e.hand, bag: remainingBag(e.board, e.hand), timeMs: 1e5, maxDepth: 1, multiPV: true, exactEmpties: -1 };
      const r6 = searchRoot({ ...base, params: { ...PARAMS, mpc: false } });
      const r7 = searchRootV7({ ...base, bonusPoints: BONUS_LEVELS.mid, params: { ...V7_PARAMS, mpc: false, bonusWeight: 1 } });
      const s6 = new Map(r6.scores.map(x => [x.sq, x.score]));
      for (const x of r7.scores) {
        const m = moves.find(mm => mm.r * 8 + mm.c === x.sq);
        const nb = applyMoveToBoard(e.board, m, e.hand, e.currentTurn);
        const expect = bonusOfPatterns(findPatterns(nb, m.r, m.c, e.currentTurn), BONUS_LEVELS.mid);
        assert.ok(Math.abs(x.score - s6.get(x.sq) - expect) < 1e-6, `格 ${x.sq}：${x.score - s6.get(x.sq)} ≠ ${expect}`);
        checked++;
      }
      e.executeMove(moves[0].r, moves[0].c);
    }
  }
  assert.ok(checked > 500);
});

// 暴力參照：以規則層逐一展開抽棋（含加分），回傳 player 角度的期望分差
function chanceRef(board, player, bag, points) {
  if (isBoardFull(board) || (!hasLegalMove(board, player) && !hasLegalMove(board, opp(player)))) {
    const s = computeScores(board);
    return player === BLACK ? s.black - s.white : s.white - s.black;
  }
  if (!hasLegalMove(board, player)) return -chanceRef(board, opp(player), bag, points);
  let sum = 0;
  for (let i = 0; i < bag.length; i++) {
    const rest = bag.filter((_, j) => j !== i);
    let best = -Infinity;
    for (const m of getLegalMoves(board, player)) {
      const nb = applyMoveToBoard(board, m, bag[i], player);
      const v = bonusOfPatterns(findPatterns(nb, m.r, m.c, player), points) - chanceRef(nb, opp(player), rest, points);
      if (v > best) best = v;
    }
    sum += best;
  }
  return sum / bag.length;
}

test("v7 終盤精確期望值（含加分）與暴力展開完全一致", () => {
  let checked = 0;
  for (let g = 0; g < 20 && checked < 15; g++) {
    const e = new GameEngine({ rng: mulberry32(600 + g), bonusLevel: "high" });
    while (!e.gameOver && e.board.flat().filter(x => !x).length > 4) {
      if (!e.legalMoves().length) { e.passTurn(); continue; }
      const r = findBestMoveForCPU(e.board, e.currentTurn, e.hand, { timeMs: 10 });
      e.executeMove(r.chosen.r, r.chosen.c);
    }
    if (e.gameOver || !e.legalMoves().length) continue;
    const bag = remainingBag(e.board, e.hand);
    const res = searchRootV7({ board: e.board, player: e.currentTurn, handId: e.hand, bag, bonusPoints: BONUS_LEVELS.high, timeMs: 5000 });
    assert.ok(res.chanceExact);
    for (const x of res.scores) {
      const m = e.legalMoves().find(mm => mm.r * 8 + mm.c === x.sq);
      const nb = applyMoveToBoard(e.board, m, e.hand, e.currentTurn);
      const ref = bonusOfPatterns(findPatterns(nb, m.r, m.c, e.currentTurn), BONUS_LEVELS.high) - chanceRef(nb, opp(e.currentTurn), bag, BONUS_LEVELS.high);
      assert.ok(Math.abs(ref - x.score) < 1e-6, `${x.score} ≠ ${ref}`);
      checked++;
    }
  }
  assert.ok(checked >= 5);
});

test("加分模式下 AI 只選合法位置", () => {
  const e = new GameEngine({ rng: mulberry32(31), bonusLevel: "low" });
  for (let i = 0; i < 12; i++) {
    const m = e.legalMoves();
    if (!m.length) { e.passTurn(); continue; }
    const r = findBestMoveForCPU(e.board, e.currentTurn, e.hand, { timeMs: 50, bonusPoints: LOW });
    assert.ok(e.findLegalMove(r.chosen.r, r.chosen.c));
    e.executeMove(r.chosen.r, r.chosen.c);
  }
});
