import test from "node:test";
import assert from "node:assert/strict";
import * as bb from "../src/ai/v6/bitboard.js";
import { searchRoot } from "../src/ai/v6/search.js";
import { GameEngine } from "../src/core/game-engine.js";
import { getLegalMoves, flipsFor, remainingBag, createEmptyBoard, createDisc } from "../src/core/rules.js";
import { findBestMoveForCPU } from "../src/ai/ai-service.js";
import { BLACK, WHITE } from "../src/core/constants.js";
import { mulberry32, randomMove, greedyMove, engineMove, playGame } from "./helpers.js";

test("位元棋盤的可下位置與翻面，與規則引擎在隨機對局中完全一致", () => {
  const rng = mulberry32(42);
  let checked = 0;
  for (let g = 0; g < 30; g++) {
    const e = new GameEngine({ rng });
    while (!e.gameOver) {
      const { bH, bL, wH, wL } = bb.fromBoard(e.board, BLACK);
      for (const player of [BLACK, WHITE]) {
        const [pH, pL, oH, oL] = player === BLACK ? [bH, bL, wH, wL] : [wH, wL, bH, bL];
        bb.mobility(pH, pL, oH, oL);
        const got = bb.squaresOf(bb.RH, bb.RL, []).sort((a, b) => a - b);
        const ref = getLegalMoves(e.board, player).map(m => m.r * 8 + m.c).sort((a, b) => a - b);
        assert.deepEqual(got, ref);
        for (const s of ref) {
          bb.flips(pH, pL, oH, oL, s);
          const f = bb.squaresOf(bb.RH, bb.RL, []).sort((a, b) => a - b);
          const fr = flipsFor(e.board, s >> 3, s & 7, player).map(([r, c]) => r * 8 + c).sort((a, b) => a - b);
          assert.deepEqual(f, fr);
        }
        checked++;
      }
      const m = e.legalMoves();
      if (!m.length) { e.passTurn(); continue; }
      const pick = m[Math.floor(rng() * m.length)];
      e.executeMove(pick.r, pick.c);
    }
  }
  assert.ok(checked > 1000);
});

test("v6 只選合法位置，並在時間內回傳", () => {
  const e = new GameEngine({ rng: mulberry32(8) });
  for (let i = 0; i < 15; i++) {
    const m = e.legalMoves();
    if (!m.length) { e.passTurn(); continue; }
    e.executeMove(m[0].r, m[0].c);
  }
  const t0 = Date.now();
  const res = findBestMoveForCPU(e.board, e.currentTurn, e.hand, { timeMs: 200 });
  assert.ok(Date.now() - t0 < 1000);
  assert.ok(e.findLegalMove(res.chosen.r, res.chosen.c));
  // 只確認有實際搜尋；深度會受同時執行的其他測試搶 CPU 影響，不寫死門檻
  assert.ok(res.info.depth >= 1);
});

test("終盤精確期望值：只剩一格時，分數等於實際終局分差", () => {
  // 第 1 列除了 H1 都是白棋，A2 黑棋 — 其餘填滿黑棋，黑方下 H1 會翻掉 B1～G1
  const b = createEmptyBoard();
  let id = 0;
  const used = new Set();
  const next = () => { while (used.has(id)) id++; used.add(id); return id; };
  for (let s = 0; s < 64; s++) {
    if (s === 7) continue;
    const face = s < 7 ? (s === 0 ? BLACK : WHITE) : BLACK;
    b[s >> 3][s & 7] = createDisc(next(), face);
  }
  const hand = 63; // 0～62 都在盤上，剩下唯一一顆
  const bag = remainingBag(b, hand);
  assert.equal(bag.length, 0);
  const res = searchRoot({ board: b, player: BLACK, handId: hand, bag, timeMs: 1000 });
  assert.ok(res.exact);
  const e = new GameEngine();
  e.board = b; e.currentTurn = BLACK; e.hand = hand;
  e.executeMove(0, 7);
  const s = e.settlementData;
  assert.equal(Math.round(res.scores[0].score * 1000) / 1000, s.black - s.white);
});

test("終盤精確期望值：剩少數格時會逐一展開抽棋（chanceExact）", () => {
  const e = new GameEngine({ rng: mulberry32(3) });
  while (!e.gameOver && e.board.flat().filter(x => !x).length > 6) {
    if (!e.legalMoves().length) { e.passTurn(); continue; }
    const m = greedyMove(e);
    e.executeMove(m.r, m.c);
  }
  if (e.gameOver || !e.legalMoves().length) return;
  const res = searchRoot({ board: e.board, player: e.currentTurn, handId: e.hand, bag: remainingBag(e.board, e.hand), timeMs: 1000 });
  assert.ok(res.chanceExact);
  assert.equal(res.scores.length, e.legalMoves().length);
});

test("明顯強過隨機與貪心（黑白各 2 局，100ms/步）", () => {
  const rng = mulberry32(99);
  for (const [name, opp] of [["隨機", () => (e) => randomMove(e, rng)], ["貪心", () => greedyMove]]) {
    let wins = 0;
    for (let g = 0; g < 4; g++) {
      const v6Black = g % 2 === 0;
      const v6 = (e) => engineMove(e, 100);
      const o = opp();
      const e = playGame({ seed: 500 + (g >> 1), pickBlack: v6Black ? v6 : o, pickWhite: v6Black ? o : v6 });
      const s = e.settlementData;
      if ((v6Black ? s.black - s.white : s.white - s.black) > 0) wins++;
    }
    assert.ok(wins >= 3, `對${name}只贏 ${wins}/4`);
  }
});
