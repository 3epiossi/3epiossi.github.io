/**
 * 加分模式（牌型）機率與期望值計算
 *
 * 牌型（同一直線上連續 3 顆己方的棋，讀朝上那面的數字，依直線上的位置順序）：
 *   湊十：三顆相加 = 10
 *   有序順子：沿直線依序連號，遞增或遞減（如 3-4-5、6-5-4）
 *   無序順子：三個數字是連號，但順序打亂（如 5-3-4）
 *   三條：三顆同數字
 * 牌型互斥：順子的和 = 3a+3 不可能是 10；三條的和 = 3a 也不可能是 10；有序順子優先於無序順子。
 *
 * 1) 理論：64 顆棋依序取 3 顆（不放回），某一面的數字 1～8 各 8 顆，窮舉精確機率。
 * 2) 實戰：實際對局中，每次落子檢查「經過新落下的棋、三格都是己方」的三連，統計牌型頻率。
 *
 *   node weighted/tests/poker-odds.js --games 300 --engine-games 20
 */
import { GameEngine } from "../src/core/game-engine.js";
import { weightOf } from "../src/core/rules.js";
import { mulberry32, randomMove, engineMove } from "./helpers.js";

const args = Object.fromEntries(process.argv.slice(2).reduce((acc, a, i, arr) => {
  if (a.startsWith("--")) acc.push([a.slice(2), arr[i + 1]]);
  return acc;
}, []));
const RANDOM_GAMES = Number(args.games || 300);
const ENGINE_GAMES = Number(args["engine-games"] || 20);
const POINTS = { ten: 3, straight: 6, ordered: 10, trips: 8 }; // 暫定加分（有序順子 +10 是暫定值）
const NAMES = { ten: "湊十", straight: "無序順子", ordered: "有序順子", trips: "三條" };
const TYPES = ["ten", "straight", "ordered", "trips"];

export function classify(a, b, c) {
  if (a === b && b === c) return "trips";
  if (a + b + c === 10) return "ten";
  if ((b === a + 1 && c === b + 1) || (b === a - 1 && c === b - 1)) return "ordered";
  const s = [a, b, c].sort((x, y) => x - y);
  if (s[1] === s[0] + 1 && s[2] === s[1] + 1) return "straight";
  return null;
}

const pct = (x) => (100 * x).toFixed(2) + "%";

// ===== 1) 理論機率（精確窮舉） =====
{
  const nums = [];
  for (let v = 1; v <= 8; v++) for (let k = 0; k < 8; k++) nums.push(v);
  const count = { ten: 0, straight: 0, ordered: 0, trips: 0 };
  let total = 0;
  for (let i = 0; i < 64; i++) for (let j = 0; j < 64; j++) for (let k = 0; k < 64; k++) {
    if (i === j || j === k || i === k) continue;
    total++;
    const t = classify(nums[i], nums[j], nums[k]);
    if (t) count[t]++;
  }
  console.log(`\n【理論】依序取 3 顆棋（共 ${total} 種排列），朝上數字形成牌型的機率`);
  let ev = 0, any = 0;
  for (const t of TYPES) {
    const p = count[t] / total;
    ev += p * POINTS[t]; any += p;
    console.log(`  ${NAMES[t].padEnd(4, "　")}  ${pct(p).padStart(7)}  加分 +${POINTS[t]}  期望值 ${(p * POINTS[t]).toFixed(3)}`);
  }
  console.log(`  任一牌型 ${pct(any)}，每組三連的加分期望值 ${ev.toFixed(3)}`);
}

// ===== 2) 實戰頻率 =====
const AXES = [[0, 1], [1, 0], [1, 1], [1, -1]];

/** 落子後，經過 (r, c) 且三格都是 player 的三連，逐一判斷牌型 */
function patternsAt(board, r, c, player) {
  const found = [];
  let windows = 0;
  for (const [dr, dc] of AXES) {
    for (let start = -2; start <= 0; start++) {
      const cells = [0, 1, 2].map(k => [r + (start + k) * dr, c + (start + k) * dc]);
      if (cells.some(([y, x]) => y < 0 || y > 7 || x < 0 || x > 7)) continue;
      const discs = cells.map(([y, x]) => board[y][x]);
      if (discs.some(d => !d || d.face !== player)) continue;
      windows++;
      const [a, b, cc] = discs.map(d => weightOf(d.id, player));
      const t = classify(a, b, cc);
      if (t) found.push(t);
    }
  }
  return { found, windows };
}

function simulate(label, games, pickFor, seedBase) {
  const stat = { moves: 0, windows: 0, ten: 0, straight: 0, ordered: 0, trips: 0, scoringMoves: 0, combos: {}, bonus: 0, bonusCombo: 0, weightTotal: 0 };
  const byPhase = [0, 0, 0, 0, 0, 0]; // 每 10 手一段的加分
  for (let g = 0; g < games; g++) {
    const e = new GameEngine({ rng: mulberry32(seedBase + g) });
    const pick = pickFor(g);
    let ply = 0;
    while (!e.gameOver) {
      if (!e.legalMoves().length) { e.passTurn(); continue; }
      const player = e.currentTurn;
      const m = pick(e);
      e.executeMove(m.r, m.c);
      const { found, windows } = patternsAt(e.board, m.r, m.c, player);
      stat.moves++; stat.windows += windows;
      let base = 0;
      for (const t of found) { stat[t]++; base += POINTS[t]; }
      if (found.length) {
        stat.scoringMoves++;
        stat.combos[found.length] = (stat.combos[found.length] || 0) + 1;
        const withCombo = base * (1 + 0.5 * (found.length - 1));
        stat.bonus += base; stat.bonusCombo += withCombo;
        byPhase[Math.min(5, Math.floor(ply / 10))] += withCombo;
      }
      ply++;
    }
    stat.weightTotal += e.settlementData.black + e.settlementData.white;
  }
  const perGame = (x) => (x / games).toFixed(2);
  console.log(`\n【實戰：${label}】${games} 局、${stat.moves} 步`);
  console.log(`  每步平均有 ${(stat.windows / stat.moves).toFixed(2)} 組「經過新棋、全是己方」的三連`);
  for (const t of TYPES) {
    console.log(`  ${NAMES[t].padEnd(4, "　")}  每局 ${perGame(stat[t])} 次（雙方合計），每組三連命中率 ${pct(stat[t] / stat.windows)}`);
  }
  console.log(`  有得分的步數比例 ${pct(stat.scoringMoves / stat.moves)}；Combo 分布 ${JSON.stringify(stat.combos)}`);
  console.log(`  每局加分（雙方合計）：無 Combo ${perGame(stat.bonus)}、含 Combo ${perGame(stat.bonusCombo)}；` +
    `每局權重總分 ${perGame(stat.weightTotal)}，加分約佔 ${pct(stat.bonusCombo / (stat.bonusCombo + stat.weightTotal))}`);
  console.log(`  加分在各階段的分布（每 10 手）：${byPhase.map(x => perGame(x)).join(" / ")}`);
}

const rng = mulberry32(2024);
simulate("隨機落子", RANDOM_GAMES, () => (e) => randomMove(e, rng), 1000);
simulate("v6 引擎互下（不懂加分，20ms/步）", ENGINE_GAMES, () => (e) => engineMove(e, 20), 5000);
