/**
 * 量測 v6 評估值與終局實際分差的比例（依剩餘空格分段）。
 * 加分模式要把「真實分數」的加分換算成評估值，比例會隨棋局階段改變。
 *
 *   node weighted/tests/eval-scale.js --games 30 --time 60
 */
import { GameEngine } from "../src/core/game-engine.js";
import { findBestMoveForCPU } from "../src/ai/ai-service.js";
import { mulberry32 } from "./helpers.js";

const args = Object.fromEntries(process.argv.slice(2).reduce((acc, a, i, arr) => {
  if (a.startsWith("--")) acc.push([a.slice(2), arr[i + 1]]);
  return acc;
}, []));
const GAMES = Number(args.games || 30), TIME = Number(args.time || 60);
const BUCKETS = [[60, 51], [50, 41], [40, 31], [30, 21], [20, 11], [10, 1]];
const data = BUCKETS.map(() => []);

for (let g = 0; g < GAMES; g++) {
  const e = new GameEngine({ rng: mulberry32(8800 + g) });
  const rec = [];
  while (!e.gameOver) {
    if (!e.legalMoves().length) { e.passTurn(); continue; }
    const empties = e.board.flat().filter(x => !x).length;
    const r = findBestMoveForCPU(e.board, e.currentTurn, e.hand, { timeMs: TIME });
    rec.push({ empties, player: e.currentTurn, score: r.maxScore });
    e.executeMove(r.chosen.r, r.chosen.c);
  }
  const s = e.settlementData;
  for (const x of rec) {
    const margin = x.player === 1 ? s.black - s.white : s.white - s.black;
    const b = BUCKETS.findIndex(([hi, lo]) => x.empties <= hi && x.empties >= lo);
    data[b].push([x.score, margin]);
  }
}
for (let i = 0; i < BUCKETS.length; i++) {
  const d = data[i];
  const mx = d.reduce((a, [x]) => a + x, 0) / d.length, my = d.reduce((a, [, y]) => a + y, 0) / d.length;
  let sxy = 0, sxx = 0, syy = 0;
  for (const [x, y] of d) { sxy += (x - mx) * (y - my); sxx += (x - mx) ** 2; syy += (y - my) ** 2; }
  const k = sxy / sxx, corr = sxy / Math.sqrt(sxx * syy);
  console.log(`空格 ${BUCKETS[i][0]}～${BUCKETS[i][1]}：終局分差 ≈ ${k.toFixed(2)} × 評估值（相關係數 ${corr.toFixed(2)}，n=${d.length}）→ 加分換算係數 ${(1 / k).toFixed(2)}`);
}
