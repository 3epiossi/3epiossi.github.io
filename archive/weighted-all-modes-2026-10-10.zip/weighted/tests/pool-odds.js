/**
 * 多池子規則下的牌型機率
 *
 * 規則：雙方共用一個可容納 N 顆棋的池子（N = 1～8）。輪到誰，就從池子裡挑一顆下，
 * 下完後從袋子補一顆進池子。N = 1 等同目前「抽一顆就得下」的規則。
 *
 * 牌型（同一直線上連續 3 顆己方的棋，讀朝上那面的數字）：
 *   湊十：三顆相加 = 10
 *   有序順子：沿直線依序連號，遞增或遞減（3-4-5、6-5-4）
 *   三條：三顆同數字
 *
 * 1) 理論：盤上已有兩顆己方的棋、第三格空著。池子裡的 N 顆棋中，「至少一顆能完成牌型」的機率。
 * 2) 實戰：照新規則實際對局，比較「隨機下」與「追牌型」兩種玩家。
 *
 *   node weighted/tests/pool-odds.js --games 300
 */
import { BLACK, WHITE } from "../src/core/constants.js";
import {
  createInitialBoard, getLegalMoves, applyMoveToBoard, weightOf, isBoardFull, hasLegalMove, opp
} from "../src/core/rules.js";
import { mulberry32 } from "./helpers.js";

const args = Object.fromEntries(process.argv.slice(2).reduce((acc, a, i, arr) => {
  if (a.startsWith("--")) acc.push([a.slice(2), arr[i + 1]]);
  return acc;
}, []));
const GAMES = Number(args.games || 300);
const POINTS = { ten: 3, ordered: 10, trips: 8 }; // 暫定加分，只用來讓「追牌型」玩家排優先順序
const TYPES = ["ten", "ordered", "trips"];
const NAMES = { ten: "湊十", ordered: "有序順子", trips: "三條" };
const pct = (x) => (100 * x).toFixed(1) + "%";

/** a, b, c 依直線上的順序 */
function classify(a, b, c) {
  if (a === b && b === c) return "trips";
  if (a + b + c === 10) return "ten";
  if ((b === a + 1 && c === b + 1) || (b === a - 1 && c === b - 1)) return "ordered";
  return null;
}

// ===== 1) 理論 =====
// 64 顆棋的某一面：1～8 各 8 顆。先抽出盤上那兩顆 (a, b)，池子是從剩下 62 顆裡抽 N 顆。
// 「池子裡沒有任何一顆能用」的機率 = C(62−K, N) / C(62, N)，K = 剩下的棋裡能完成牌型的顆數。
function comb(n, k) {
  if (k < 0 || k > n) return 0;
  let r = 1;
  for (let i = 0; i < k; i++) r = r * (n - i) / (i + 1);
  return r;
}
function theory(N, placedIdx /* 新棋在三連中的位置 0/1/2 */) {
  const res = { ten: 0, ordered: 0, trips: 0, any: 0 };
  let total = 0;
  for (let a = 1; a <= 8; a++) for (let b = 1; b <= 8; b++) {
    // 盤上兩顆依序抽出的機率（不放回）
    const w = (8 / 64) * ((a === b ? 7 : 8) / 63);
    total += w;
    const usable = { ten: new Set(), ordered: new Set(), trips: new Set() };
    for (let v = 1; v <= 8; v++) {
      const tri = placedIdx === 0 ? [v, a, b] : placedIdx === 1 ? [a, v, b] : [a, b, v];
      const t = classify(...tri);
      if (t) usable[t].add(v);
    }
    const remaining = (v) => 8 - (v === a ? 1 : 0) - (v === b ? 1 : 0);
    const hit = (values) => {
      let K = 0;
      for (const v of values) K += remaining(v);
      return 1 - comb(62 - K, N) / comb(62, N);
    };
    for (const t of TYPES) res[t] += w * hit(usable[t]);
    res.any += w * hit(new Set([...usable.ten, ...usable.ordered, ...usable.trips]));
  }
  for (const k in res) res[k] /= total;
  return res;
}

console.log("\n【理論】盤上已有兩顆己方的棋，池子裡至少有一顆能完成牌型的機率");
console.log("（有序順子：新棋落在三連的端點 / 中間；平均以端點 2/3、中間 1/3 加權）\n");
console.log("池子 N │ 湊十    │ 有序順子（端點 / 中間 / 平均） │ 三條    │ 任一牌型");
for (let N = 1; N <= 8; N++) {
  const end = theory(N, 0), mid = theory(N, 1);
  const avg = (k) => (2 * end[k] + mid[k]) / 3;
  console.log(`   ${N}   │ ${pct(avg("ten")).padStart(6)}  │ ${pct(end.ordered).padStart(6)} / ${pct(mid.ordered).padStart(6)} / ${pct(avg("ordered")).padStart(6)}       │ ${pct(avg("trips")).padStart(6)}  │ ${pct(avg("any")).padStart(6)}`);
}

// ===== 2) 實戰模擬 =====
const AXES = [[0, 1], [1, 0], [1, 1], [1, -1]];
function patternsAt(board, r, c, player) {
  const found = [];
  for (const [dr, dc] of AXES) {
    for (let start = -2; start <= 0; start++) {
      const cells = [0, 1, 2].map(k => [r + (start + k) * dr, c + (start + k) * dc]);
      if (cells.some(([y, x]) => y < 0 || y > 7 || x < 0 || x > 7)) continue;
      const discs = cells.map(([y, x]) => board[y][x]);
      if (discs.some(d => !d || d.face !== player)) continue;
      const t = classify(...discs.map(d => weightOf(d.id, player)));
      if (t) found.push(t);
    }
  }
  return found;
}
const bonusOf = (found) => found.reduce((s, t) => s + POINTS[t], 0) * (1 + 0.5 * Math.max(0, found.length - 1));

function playGame(N, chase, rng) {
  const bag = [];
  for (let id = 0; id < 64; id++) bag.push(id);
  const drawOne = () => bag.splice(Math.floor(rng() * bag.length), 1)[0];
  let board = createInitialBoard(drawOne);
  const pool = [];
  while (pool.length < N && bag.length) pool.push(drawOne());

  let turn = BLACK;
  const stat = { moves: 0, scoring: 0, ten: 0, ordered: 0, trips: 0 };
  while (!isBoardFull(board) && (hasLegalMove(board, BLACK) || hasLegalMove(board, WHITE))) {
    const moves = getLegalMoves(board, turn);
    if (!moves.length) { turn = opp(turn); continue; }
    let pickIdx, pickMove, found;
    if (chase) {
      // 追牌型：所有「池中棋 × 合法位置」裡加分最高的；同分隨機
      let best = -1, cands = [];
      for (let i = 0; i < pool.length; i++) {
        for (const m of moves) {
          const nb = applyMoveToBoard(board, m, pool[i], turn);
          const f = patternsAt(nb, m.r, m.c, turn);
          const v = bonusOf(f);
          if (v > best) { best = v; cands = [[i, m, f]]; }
          else if (v === best) cands.push([i, m, f]);
        }
      }
      [pickIdx, pickMove, found] = cands[Math.floor(rng() * cands.length)];
    } else {
      pickIdx = Math.floor(rng() * pool.length);
      pickMove = moves[Math.floor(rng() * moves.length)];
    }
    board = applyMoveToBoard(board, pickMove, pool[pickIdx], turn);
    if (!found) found = patternsAt(board, pickMove.r, pickMove.c, turn);
    pool.splice(pickIdx, 1);
    if (bag.length) pool.push(drawOne());
    stat.moves++;
    if (found.length) stat.scoring++;
    for (const t of found) stat[t]++;
    turn = opp(turn);
  }
  return stat;
}

for (const [label, chase] of [["隨機下（隨便選棋、隨便下）", false], ["追牌型（每步都挑加分最高的棋與位置）", true]]) {
  console.log(`\n【實戰：${label}】每個池子大小 ${GAMES} 局；次數為每局雙方合計`);
  console.log("池子 N │ 湊十  │ 有序順子 │ 三條  │ 有得分的步數");
  for (let N = 1; N <= 8; N++) {
    const rng = mulberry32(9000 + N);
    const sum = { moves: 0, scoring: 0, ten: 0, ordered: 0, trips: 0 };
    for (let g = 0; g < GAMES; g++) {
      const s = playGame(N, chase, rng);
      for (const k in sum) sum[k] += s[k];
    }
    const per = (k) => (sum[k] / GAMES).toFixed(1).padStart(5);
    console.log(`   ${N}   │ ${per("ten")} │  ${per("ordered")}   │ ${per("trips")} │ ${pct(sum.scoring / sum.moves).padStart(6)}`);
  }
}
