/**
 * 加分模式評測：v7（搜尋計算加分）對 v6（不考慮加分），雙方都照規則拿加分，以總分判勝負。
 *
 *   node weighted/tests/bonus-duel.js --level mid --games 100 --depth 6
 *   node weighted/tests/bonus-duel.js --level low --games 40 --time 100 --params '{"bonusWeight":0.3}'
 *
 * --level：low（2/4/8）、mid（4/8/16）、high（8/16/32）
 * --depth：固定深度（結果可重現，最可靠）；不給則用 --time 限時（雜訊很大，需要大量局數）
 * --params：只套用在 v7 一方
 * --control 1：對照組，兩邊都用 v6，用來確認測試本身公平（固定深度時應剛好 50%、分差 0）
 */
import { GameEngine } from "../src/core/game-engine.js";
import { findBestMoveForCPU } from "../src/ai/ai-service.js";
import { V7_PARAMS } from "../src/ai/v7/search.js";
import { BONUS_LEVELS } from "../src/core/bonus.js";
import { mulberry32 } from "./helpers.js";

const args = Object.fromEntries(process.argv.slice(2).reduce((acc, a, i, arr) => {
  if (a.startsWith("--")) acc.push([a.slice(2), arr[i + 1]]);
  return acc;
}, []));
const GAMES = Number(args.games || 40);
const TIME = Number(args.time || 100);
const DEPTH = args.depth ? Number(args.depth) : undefined;
const LEVEL = args.level || "low";
const POINTS = BONUS_LEVELS[LEVEL];
const PARAMS_V7 = args.params ? { ...V7_PARAMS, ...JSON.parse(args.params) } : undefined;
const CONTROL = args.control === "1";

let v7Wins = 0, draws = 0, margin = 0, bonusV7 = 0, bonusV6 = 0, weightTotal = 0;
const t0 = Date.now();
for (let g = 0; g < GAMES; g++) {
  const v7Color = g % 2 === 0 ? 1 : 2;
  const e = new GameEngine({ rng: mulberry32(3000 + Math.floor(g / 2)), bonusLevel: LEVEL });
  while (!e.gameOver) {
    if (!e.legalMoves().length) { e.passTurn(); continue; }
    const isV7 = e.currentTurn === v7Color && !CONTROL;
    const r = findBestMoveForCPU(e.board, e.currentTurn, e.hand, {
      timeMs: DEPTH ? 60000 : TIME,
      maxDepth: DEPTH,
      bonusPoints: isV7 ? POINTS : null,
      ...(isV7 && PARAMS_V7 ? { params: PARAMS_V7 } : {})
    });
    e.executeMove(r.chosen.r, r.chosen.c);
  }
  const s = e.settlementData;
  const d = v7Color === 1 ? s.totalBlack - s.totalWhite : s.totalWhite - s.totalBlack;
  margin += d;
  if (d > 0) v7Wins++; else if (d === 0) draws++;
  bonusV7 += v7Color === 1 ? s.bonusBlack : s.bonusWhite;
  bonusV6 += v7Color === 1 ? s.bonusWhite : s.bonusBlack;
  weightTotal += s.black + s.white;
}
const totalBonus = bonusV7 + bonusV6;
console.log(`[加分 ${POINTS.ten}/${POINTS.ordered}/${POINTS.trips}${CONTROL ? "，對照組" : ""}] v7 對 v6（${DEPTH ? DEPTH + " 層" : TIME + "ms/步"}）${GAMES} 局：` +
  `v7 勝率 ${(100 * (v7Wins + draws / 2) / GAMES).toFixed(0)}%，平均總分差 ${(margin / GAMES).toFixed(1)}；` +
  `每局加分 v7 ${(bonusV7 / GAMES).toFixed(1)} / v6 ${(bonusV6 / GAMES).toFixed(1)}；加分佔總分 ${(100 * totalBonus / (totalBonus + weightTotal)).toFixed(1)}%；` +
  `${((Date.now() - t0) / 1000).toFixed(0)} 秒`);
