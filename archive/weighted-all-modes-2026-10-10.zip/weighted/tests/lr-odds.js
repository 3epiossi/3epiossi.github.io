/**
 * 左右數字棋子的牌型機率
 *
 * 棋子：左數字、右數字（各 1～8），64 顆剛好是所有 (左, 右) 組合各一顆，兩面相同。
 * 同一直線上連續 3 顆棋，每顆可以自由選左或右的數字（2³ = 8 種選法），
 * 只要有任一種選法成立就算：
 *   三條：三個數字相同
 *   順子（依序）：沿直線方向依序連號，遞增或遞減（3-4-5、6-5-4）
 *   順子（不限順序）：三個數字連號（5-3-4 也算）
 *
 *   node weighted/tests/lr-odds.js --games 300
 */
import { GameEngine } from "../src/core/game-engine.js";
import { mulberry32 } from "./helpers.js";

const args = Object.fromEntries(process.argv.slice(2).reduce((acc, a, i, arr) => {
  if (a.startsWith("--")) acc.push([a.slice(2), arr[i + 1]]);
  return acc;
}, []));
const GAMES = Number(args.games || 300);

const L = (id) => (id & 7) + 1;
const R = (id) => (id >> 3) + 1;

/** 三顆棋（依直線順序）在 8 種選法中，能組成哪些牌型 */
function patterns(a, b, c) {
  const A = [L(a), R(a)], B = [L(b), R(b)], C = [L(c), R(c)];
  let trips = false, ordered = false, anySeq = false;
  for (const x of A) for (const y of B) for (const z of C) {
    if (x === y && y === z) trips = true;
    if ((y === x + 1 && z === y + 1) || (y === x - 1 && z === y - 1)) ordered = true;
    const s = [x, y, z].sort((p, q) => p - q);
    if (s[1] === s[0] + 1 && s[2] === s[1] + 1) anySeq = true;
  }
  return { trips, ordered, anySeq };
}

const pct = (x) => (100 * x).toFixed(2) + "%";
const every = (p) => `約每 ${(1 / p).toFixed(1)} 組三連一次`;

// ===== 1) 理論：64 顆依序取 3 顆（不放回） =====
let total = 0;
const c = { trips: 0, ordered: 0, anySeq: 0, tripsOrOrdered: 0, tripsOrAny: 0, tripsAndOrdered: 0, tripsAndAny: 0 };
for (let i = 0; i < 64; i++) for (let j = 0; j < 64; j++) for (let k = 0; k < 64; k++) {
  if (i === j || j === k || i === k) continue;
  total++;
  const p = patterns(i, j, k);
  if (p.trips) c.trips++;
  if (p.ordered) c.ordered++;
  if (p.anySeq) c.anySeq++;
  if (p.trips || p.ordered) c.tripsOrOrdered++;
  if (p.trips || p.anySeq) c.tripsOrAny++;
  if (p.trips && p.ordered) c.tripsAndOrdered++;
  if (p.trips && p.anySeq) c.tripsAndAny++;
}
console.log(`\n【理論】64 顆依序取 3 顆（${total} 種排列），每顆可選左或右的數字`);
console.log(`  三條              ${pct(c.trips / total).padStart(7)}   ${every(c.trips / total)}`);
console.log(`  順子（依序）      ${pct(c.ordered / total).padStart(7)}   ${every(c.ordered / total)}`);
console.log(`  順子（不限順序）  ${pct(c.anySeq / total).padStart(7)}   ${every(c.anySeq / total)}`);
console.log(`  三條或順子（依序）       ${pct(c.tripsOrOrdered / total)}；兩者同時成立 ${pct(c.tripsAndOrdered / total)}`);
console.log(`  三條或順子（不限順序）   ${pct(c.tripsOrAny / total)}；兩者同時成立 ${pct(c.tripsAndAny / total)}`);

// 對照：每顆只有一個數字（1～8 各 8 顆）
{
  let t = 0, tr = 0, od = 0, an = 0;
  const n = (id) => (id & 7) + 1;
  for (let i = 0; i < 64; i++) for (let j = 0; j < 64; j++) for (let k = 0; k < 64; k++) {
    if (i === j || j === k || i === k) continue;
    t++;
    const x = n(i), y = n(j), z = n(k);
    if (x === y && y === z) tr++;
    if ((y === x + 1 && z === y + 1) || (y === x - 1 && z === y - 1)) od++;
    const s = [x, y, z].sort((p, q) => p - q);
    if (s[1] === s[0] + 1 && s[2] === s[1] + 1) an++;
  }
  console.log(`\n【對照】每顆只有一個數字時：三條 ${pct(tr / t)}、順子（依序）${pct(od / t)}、順子（不限順序）${pct(an / t)}`);
}

// ===== 2) 實戰：完整對局中，每次落子檢查「經過新棋、三格都是己方」的三連 =====
const AXES = [[0, 1], [1, 0], [1, 1], [1, -1]];
function triplesAt(board, r, cc, player) {
  const out = [];
  for (const [dr, dc] of AXES) {
    for (let st = -2; st <= 0; st++) {
      const cells = [0, 1, 2].map(k => [r + (st + k) * dr, cc + (st + k) * dc]);
      if (cells.some(([y, x]) => y < 0 || y > 7 || x < 0 || x > 7)) continue;
      const ds = cells.map(([y, x]) => board[y][x]);
      if (ds.some(d => !d || d.face !== player)) continue;
      out.push(ds.map(d => d.id));
    }
  }
  return out;
}

function simulate(label, chase) {
  let moves = 0, windows = 0, scoring = 0;
  const per = { trips: 0, ordered: 0, anySeq: 0 };
  for (let g = 0; g < GAMES; g++) {
    const rng = mulberry32(7000 + g);
    const e = new GameEngine({ rng });
    while (!e.gameOver) {
      const legal = e.legalMoves();
      if (!legal.length) { e.passTurn(); continue; }
      const player = e.currentTurn;
      let pick;
      if (chase) {
        // 追牌型：挑能完成最多組（三條算 2、順子算 1）的位置
        let best = -1, cands = [];
        for (const m of legal) {
          const save = e.board[m.r][m.c];
          const old = m.flips.map(([y, x]) => e.board[y][x].face);
          e.board[m.r][m.c] = { id: e.hand, face: player };
          for (const [y, x] of m.flips) e.board[y][x].face = player;
          let v = 0;
          for (const t of triplesAt(e.board, m.r, m.c, player)) { const p = patterns(...t); v += (p.trips ? 2 : 0) + (p.ordered ? 1 : 0); }
          m.flips.forEach(([y, x], i) => { e.board[y][x].face = old[i]; });
          e.board[m.r][m.c] = save;
          if (v > best) { best = v; cands = [m]; } else if (v === best) cands.push(m);
        }
        pick = cands[Math.floor(rng() * cands.length)];
      } else {
        pick = legal[Math.floor(rng() * legal.length)];
      }
      e.executeMove(pick.r, pick.c);
      const ts = triplesAt(e.board, pick.r, pick.c, player);
      moves++; windows += ts.length;
      let any = false;
      for (const t of ts) {
        const p = patterns(...t);
        if (p.trips) per.trips++;
        if (p.ordered) per.ordered++;
        if (p.anySeq) per.anySeq++;
        if (p.trips || p.ordered) any = true;
      }
      if (any) scoring++;
    }
  }
  const f = (k) => (per[k] / GAMES).toFixed(1).padStart(5);
  console.log(`\n【實戰：${label}】${GAMES} 局，每步平均 ${(windows / moves).toFixed(2)} 組三連；每局出現次數（雙方合計）`);
  console.log(`  三條 ${f("trips")}　順子（依序）${f("ordered")}　順子（不限順序）${f("anySeq")}　有三條或依序順子的步數 ${pct(scoring / moves)}`);
}
simulate("隨機下", false);
simulate("追牌型", true);
