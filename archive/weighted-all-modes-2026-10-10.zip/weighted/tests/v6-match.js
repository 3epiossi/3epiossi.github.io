/**
 * v6 對戰評測：v6 對指定對手（預設 v5），黑白各半、同一組亂數種子。
 *
 *   node weighted/tests/v6-match.js --games 20 --time 200 --vs v5
 *   node weighted/tests/v6-match.js --games 20 --time 200 --vs v6 --params '{"mobEarly":2}'
 *
 * --params 只套用在受測的 v6；對手若也是 v6 則用預設參數，方便比較調參效果。
 */
import { PARAMS } from "../src/ai/v6/eval.js";
import { mulberry32, randomMove, greedyMove, engineMove, playGame } from "./helpers.js";

const args = Object.fromEntries(process.argv.slice(2).reduce((acc, a, i, arr) => {
  if (a.startsWith("--")) acc.push([a.slice(2), arr[i + 1]]);
  return acc;
}, []));
const games = Number(args.games || 20);
const timeMs = Number(args.time || 200);
const vs = args.vs || "greedy";
const seed = Number(args.seed || 1);
const testParams = { ...PARAMS, ...(args.params ? JSON.parse(args.params) : {}) };
const rng = mulberry32(seed * 31 + 7);

const opponent = {
  random: (e) => randomMove(e, rng),
  greedy: (e) => greedyMove(e),
  self: (e) => engineMove(e, timeMs)
}[vs];
if (!opponent) { console.error("--vs 只能是 random / greedy / self"); process.exit(1); }
const tested = (e) => engineMove(e, timeMs, testParams);

let win = 0, loss = 0, draw = 0, margin = 0;
const t0 = Date.now();
for (let g = 0; g < games; g++) {
  const testedBlack = g % 2 === 0;
  const e = playGame({
    seed: seed * 10000 + Math.floor(g / 2), // 同一種子黑白各下一次
    pickBlack: testedBlack ? tested : opponent,
    pickWhite: testedBlack ? opponent : tested
  });
  const s = e.settlementData;
  const d = testedBlack ? s.black - s.white : s.white - s.black;
  margin += d;
  if (d > 0) win++; else if (d < 0) loss++; else draw++;
}
console.log(`引擎對 ${vs}（${timeMs}ms/步）${games} 局：勝 ${win}、負 ${loss}、和 ${draw}，勝率 ${(100 * (win + draw / 2) / games).toFixed(1)}%，平均分差 ${(margin / games).toFixed(1)}，${((Date.now() - t0) / 1000).toFixed(0)} 秒`);
