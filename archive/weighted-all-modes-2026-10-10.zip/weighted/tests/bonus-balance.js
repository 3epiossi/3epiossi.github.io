/**
 * 加分模式數值平衡（N = 1：每回合抽一顆就得下）
 *
 * 牌型：湊十 / 有序順子 / 三條（同一直線上連續 3 顆己方的棋，且包含剛落下的那顆）。
 * 一步同時完成 k 組牌型 = Combo k，加分 = 各牌型加分總和 × Combo 倍率。
 *
 * 玩家模型：「懂加分的 v6」— 每一步取 v6 對所有落點的評分（multiPV），
 * 加上該步立即拿到的加分，挑總和最高的位置。
 *
 * 平衡指標：
 *   - 加分佔總分的比例（目標 15～25%）
 *   - 加分改變勝負的比例：只比權重與「權重 + 加分」的勝方不同（目標約 15～30%）
 *   - 各牌型每局出現次數、Combo 次數
 *
 *   node weighted/tests/bonus-balance.js --games 20 --time 30 --points 3,9,20 --combo linear
 */
import { GameEngine } from "../src/core/game-engine.js";
import { weightOf, applyMoveToBoard, getLegalMoves } from "../src/core/rules.js";
import { searchV6 } from "../src/ai/v6.js";
import { mulberry32 } from "./helpers.js";

const args = Object.fromEntries(process.argv.slice(2).reduce((acc, a, i, arr) => {
  if (a.startsWith("--")) acc.push([a.slice(2), arr[i + 1]]);
  return acc;
}, []));
const GAMES = Number(args.games || 20);
const TIME = Number(args.time || 30);
const [P_TEN, P_ORD, P_TRIPS] = (args.points || "3,9,20").split(",").map(Number);
const COMBO = args.combo || "half";
const DUEL = args.duel === "1"; // 懂加分 vs 不懂加分（只看 v6 評分）的對戰，雙方輪流執黑
const POINTS = { ten: P_TEN, ordered: P_ORD, trips: P_TRIPS };
const MULT = {
  half: (k) => 1 + 0.5 * (k - 1),     // ×1、×1.5、×2、×2.5
  linear: (k) => k,                   // ×1、×2、×3、×4
  double: (k) => 2 ** (k - 1)         // ×1、×2、×4、×8
}[COMBO];

function classify(a, b, c) {
  if (a === b && b === c) return "trips";
  if (a + b + c === 10) return "ten";
  if ((b === a + 1 && c === b + 1) || (b === a - 1 && c === b - 1)) return "ordered";
  return null;
}
const AXES = [[0, 1], [1, 0], [1, 1], [1, -1]];
function patternsAt(board, r, c, player) {
  const found = [];
  for (const [dr, dc] of AXES) {
    for (let start = -2; start <= 0; start++) {
      const cells = [0, 1, 2].map(k => [r + (start + k) * dr, c + (start + k) * dc]);
      if (cells.some(([y, x]) => y < 0 || y > 7 || x < 0 || x > 7)) continue;
      const discs = cells.map(([y, x]) => board[y][x]);
      if (discs.some(d => !d || d.face !== player)) continue;
      const t = classify(...discs.map(d => weightOf(d.id, player)));
      if (t) found.push(t);
    }
  }
  return found;
}
const bonusOf = (found) => found.length ? found.reduce((s, t) => s + POINTS[t], 0) * MULT(found.length) : 0;

const stat = { ten: 0, ordered: 0, trips: 0, combo: 0, bonus: 0, weight: 0, flipped: 0, blackWinsTotal: 0, draws: 0, moves: 0 };
// 出現機會：這一步的合法位置中，至少有一個能湊成該牌型（與加分值無關，代表實戰難度）
const avail = { ten: 0, ordered: 0, trips: 0 };
// 走法改變率：懂加分的選擇與純 v6 最佳步不同的比例，分開局（1～20 手）/ 中盤（21～40）/ 終盤（41～）
const changed = [0, 0, 0], phaseMoves = [0, 0, 0], phaseBonus = [0, 0, 0];
let awareWins = 0;
for (let g = 0; g < GAMES; g++) {
  const e = new GameEngine({ rng: mulberry32(7000 + g) });
  const bonus = { 1: 0, 2: 0 };
  const awareColor = g % 2 === 0 ? 1 : 2;
  let ply = 0;
  while (!e.gameOver) {
    const moves = getLegalMoves(e.board, e.currentTurn);
    if (!moves.length) { e.passTurn(); continue; }
    const player = e.currentTurn;
    const res = searchV6(e.board, player, e.hand, { timeMs: TIME, multiPV: true });
    const scoreBySq = new Map(res.scores.map(x => [x.sq, x.score]));
    const aware = !DUEL || player === awareColor;
    let best = null, bestV = -Infinity, bestFound = [];
    let pure = null, pureV = -Infinity;
    const can = { ten: false, ordered: false, trips: false };
    stat.moves++;
    for (const m of moves) {
      const nb = applyMoveToBoard(e.board, m, e.hand, player);
      const found = patternsAt(nb, m.r, m.c, player);
      for (const t of found) can[t] = true;
      const base = scoreBySq.get(m.r * 8 + m.c) ?? -1e9;
      const v = base + (aware ? bonusOf(found) : 0);
      if (v > bestV) { bestV = v; best = m; bestFound = found; }
      if (base > pureV) { pureV = base; pure = m; }
    }
    for (const t in can) if (can[t]) avail[t]++;
    const phase = ply < 20 ? 0 : ply < 40 ? 1 : 2;
    if (aware) { phaseMoves[phase]++; if (best !== pure) changed[phase]++; }
    phaseBonus[phase] += bonusOf(bestFound);
    ply++;
    e.executeMove(best.r, best.c);
    for (const t of bestFound) stat[t]++;
    if (bestFound.length >= 2) stat.combo++;
    bonus[player] += bonusOf(bestFound);
  }
  const s = e.settlementData;
  stat.bonus += bonus[1] + bonus[2];
  stat.weight += s.black + s.white;
  const byWeight = Math.sign(s.black - s.white);
  const byTotal = Math.sign(s.black + bonus[1] - s.white - bonus[2]);
  if (byWeight !== byTotal) stat.flipped++;
  if (byTotal > 0) stat.blackWinsTotal++;
  if (byTotal === 0) stat.draws++;
  if (DUEL && byTotal === (awareColor === 1 ? 1 : -1)) awareWins++;
}
const per = (k) => (stat[k] / GAMES).toFixed(1);
console.log(JSON.stringify({
  points: `${P_TEN}/${P_ORD}/${P_TRIPS}`,
  combo: COMBO,
  perGame: { ten: per("ten"), ordered: per("ordered"), trips: per("trips"), combo2plus: per("combo") },
  bonusPerGame: per("bonus"),
  bonusShare: (100 * stat.bonus / (stat.bonus + stat.weight)).toFixed(1) + "%",
  outcomeChanged: (100 * stat.flipped / GAMES).toFixed(0) + "%",
  blackWin: (100 * stat.blackWinsTotal / GAMES).toFixed(0) + "%",
  moveChanged: changed.map((c, i) => (100 * c / Math.max(1, phaseMoves[i])).toFixed(0) + "%").join(" / "),
  bonusByPhase: phaseBonus.map(x => (x / GAMES).toFixed(1)).join(" / "),
  ...(DUEL ? { awareWin: (100 * awareWins / GAMES).toFixed(0) + "%" } : {}),
  available: Object.fromEntries(Object.entries(avail).map(([k, v]) => [k, (100 * v / stat.moves).toFixed(1) + "%"]))
}));
