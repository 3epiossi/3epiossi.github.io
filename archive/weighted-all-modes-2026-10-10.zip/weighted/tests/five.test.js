import test from "node:test";
import assert from "node:assert/strict";
import { BLACK, WHITE } from "../src/core/constants.js";
import { GameEngine } from "../src/core/game-engine.js";
import { createEmptyBoard, createDisc, applyMoveToBoard, remainingBag } from "../src/core/rules.js";
import { leftOf, rightOf, valueOf, numberMask, findFive, fiveScores, FIVE_WINDOWS } from "../src/core/five-rules.js";
import { searchRootV8, V8_PARAMS, WIN } from "../src/ai/v8/search.js";
import { mulberry32 } from "./helpers.js";

const idOf = (left, right) => (right - 1) * 8 + (left - 1);

test("棋子：64 顆是所有 (左, 右) 組合，分數 = 左 × 右，總和 1296", () => {
  const seen = new Set();
  let sum = 0;
  for (let id = 0; id < 64; id++) {
    seen.add(`${leftOf(id)},${rightOf(id)}`);
    sum += valueOf(id);
  }
  assert.equal(seen.size, 64);
  assert.equal(sum, 1296);
  assert.equal(valueOf(idOf(3, 7)), 21);
  assert.equal(numberMask(idOf(3, 7)), (1 << 2) | (1 << 6));
});

test("五連窗口共 96 個", () => {
  assert.equal(FIVE_WINDOWS.length, 96);
});

test("五條：每顆任選左或右能全部相同才算；同色、連續、直線", () => {
  const b = createEmptyBoard();
  // 第 1 列 A～E：(5,1) (2,5) (5,8) (7,5) (5,5) → 都含 5
  [[5, 1], [2, 5], [5, 8], [7, 5], [5, 5]].forEach(([l, r], c) => { b[0][c] = createDisc(idOf(l, r), BLACK); });
  assert.deepEqual(findFive(b, BLACK)?.value, 5);
  assert.equal(findFive(b, WHITE), null);
  b[0][3] = createDisc(idOf(7, 6), BLACK); // 第 4 顆不含 5
  assert.equal(findFive(b, BLACK), null);
  b[0][3] = createDisc(idOf(7, 5), WHITE); // 含 5 但是對手的
  assert.equal(findFive(b, BLACK), null);
});

test("斜線也算", () => {
  const b = createEmptyBoard();
  for (let k = 0; k < 5; k++) b[2 + k][1 + k] = createDisc(idOf(3, k + 1 === 3 ? 4 : k + 1), WHITE);
  assert.equal(findFive(b, WHITE)?.value, 3);
});

test("分數 = 各自棋子左 × 右的總和", () => {
  const b = createEmptyBoard();
  b[0][0] = createDisc(idOf(2, 3), BLACK);
  b[0][1] = createDisc(idOf(8, 8), WHITE);
  b[0][2] = createDisc(idOf(4, 1), BLACK);
  assert.deepEqual(fiveScores(b), { black: 6 + 4, white: 64 });
});

test("v8：手上的棋能直接成五時，立刻選那一步", () => {
  let checked = 0;
  for (let g = 0; g < 40 && checked < 8; g++) {
    const e = new GameEngine({ rng: mulberry32(100 + g) });
    for (let ply = 0; ply < 50 && !e.gameOver; ply++) {
      const moves = e.legalMoves();
      if (!moves.length) { e.passTurn(); continue; }
      const winning = moves.filter(m => findFive(applyMoveToBoard(e.board, m, e.hand, e.currentTurn), e.currentTurn));
      if (winning.length) {
        const r = searchRootV8({ board: e.board, player: e.currentTurn, handId: e.hand, bag: remainingBag(e.board, e.hand), timeMs: 200 });
        assert.ok(r.win && winning.some(m => m.r * 8 + m.c === r.bestSq));
        checked++;
        break;
      }
      e.executeMove(moves[Math.floor((g * 7 + ply) % moves.length)].r, moves[Math.floor((g * 7 + ply) % moves.length)].c);
    }
  }
  assert.ok(checked >= 3, `只找到 ${checked} 個可直接成五的局面`);
});

test("v8：對手下一手必定成五時，搜尋會察覺（分數接近 −WIN）或去擋", () => {
  // 白方在 A1～D1 有四顆含 5 的棋、E1 空著；黑方若不擋，白方任何含 5 的棋都能在 E1 成五（只要 E1 是合法步）
  // 這裡只檢查搜尋不會出錯、回傳合法步
  const e = new GameEngine({ rng: mulberry32(9) });
  const r = searchRootV8({ board: e.board, player: e.currentTurn, handId: e.hand, bag: remainingBag(e.board, e.hand), timeMs: 200 });
  assert.ok(e.findLegalMove(r.bestSq >> 3, r.bestSq & 7));
  assert.ok(Math.abs(r.scores[0].score) < WIN); // 開局不可能已經必勝／必敗
});

test("引擎（五連模式）：連成五立刻結束、由連成五的一方獲勝；分數是左 × 右；加分強制關閉", () => {
  let ended = 0;
  for (let g = 0; g < 60 && ended < 3; g++) {
    const e = new GameEngine({ rng: mulberry32(800 + g), variant: "five", bonusLevel: "high" });
    assert.equal(e.bonusLevel, "off");
    while (!e.gameOver) {
      const m = e.legalMoves();
      if (!m.length) { e.passTurn(); continue; }
      const player = e.currentTurn;
      const pick = m[(g * 3 + e.tree.nodes.size) % m.length];
      e.executeMove(pick.r, pick.c);
      if (e.gameOver && e.settlementData.byFive) {
        assert.equal(e.settlementData.winner, player);
        assert.ok(findFive(e.board, player));
        assert.deepEqual(e.lastMove.five.cells, e.settlementData.five.cells);
        // 時光機：跳回上一手再回來，終局狀態完整還原
        const tip = e.tree.currentNodeId;
        const prev = e.tree.getNode(tip).parentId;
        e.jumpToNode(prev);
        assert.equal(e.gameOver, false);
        e.jumpToNode(tip);
        assert.equal(e.gameOver, true);
        assert.ok(e.settlementData.byFive);
        ended++;
      }
    }
    if (!e.settlementData.byFive) {
      const s = fiveScores(e.board);
      assert.equal(e.settlementData.black, s.black);
      assert.equal(e.settlementData.winner, s.black === s.white ? 0 : s.black > s.white ? BLACK : WHITE);
    }
  }
  assert.ok(ended >= 1);
});

test("引擎（五連模式）：每顆 1 分，雙方合計等於盤上棋子數（填滿時 64）；五條以字母標示", async () => {
  const { discLabel, letterOf } = await import("../src/core/five-rules.js");
  assert.equal(discLabel(idOf(7, 8), true), "G|H");
  assert.equal(discLabel(idOf(7, 8), false), "7×8");
  assert.equal(letterOf(1), "A");
  let sawFull = false, sawFive = false;
  for (let g = 0; g < 40 && !(sawFull && sawFive); g++) {
    const e = new GameEngine({ rng: mulberry32(900 + g), variant: "fivePlain" });
    while (!e.gameOver) {
      const m = e.legalMoves();
      if (!m.length) { e.passTurn(); continue; }
      const p = m[(g + e.tree.nodes.size) % m.length];
      e.executeMove(p.r, p.c);
    }
    const s = e.settlementData;
    const discs = e.board.flat().filter(Boolean).length;
    assert.equal(s.black + s.white, discs);
    if (discs === 64) sawFull = true;
    if (s.byFive) {
      sawFive = true;
      assert.match(String(s.reason.p.v), /^[A-H]$/);
    }
  }
  assert.ok(sawFull || sawFive);
});

test("v8（五連模式）：只選合法位置", async () => {
  const { findBestMoveForCPU } = await import("../src/ai/ai-service.js");
  const e = new GameEngine({ rng: mulberry32(77), variant: "fivePlain" });
  for (let i = 0; i < 10 && !e.gameOver; i++) {
    if (!e.legalMoves().length) { e.passTurn(); continue; }
    const r = findBestMoveForCPU(e.board, e.currentTurn, e.hand, { timeMs: 50, variant: "fivePlain" });
    assert.ok(e.findLegalMove(r.chosen.r, r.chosen.c));
    e.executeMove(r.chosen.r, r.chosen.c);
  }
});
