/**
 * 🌿 權重黑白棋 (Weighted Othello) - 對局樹與多分支系統 (Game Tree & Multi-Branch System)
 * 統一 Undo / Redo / Branch / Replay 的核心資料結構。
 * 節點儲存的是「這一步之後」的完整局面：棋盤、輪到誰、當前抽到的棋（hand）。
 */

import { msg } from "../i18n.js";
import { cloneBoard, cloneMove } from "../core/rules.js";
import { BLACK } from "../core/constants.js";

export class GameTreeNode {
  constructor({
    id,
    parentId = null,
    branchId = "main",
    stepIdx = 0,
    turn = BLACK,
    hand = null,
    move = null,
    board,
    gameOver = false,
    settlementData = null,
    logText = "",
    bonus = null,
    tag = null,
    createdAt = Date.now()
  }) {
    this.id = id;
    this.parentId = parentId;
    this.branchId = branchId;
    this.stepIdx = stepIdx;
    this.turn = turn;
    this.hand = hand;
    this.move = move ? cloneMove(move) : null;
    this.board = cloneBoard(board);
    this.gameOver = gameOver;
    this.settlementData = settlementData ? { ...settlementData } : null;
    this.logText = logText;
    this.bonus = bonus ? { ...bonus } : { 1: 0, 2: 0 }; // 雙方累計加分（加分模式）
    this.tag = tag;
    this.createdAt = createdAt;
    this.children = [];
  }
}

let idCounter = 0;
const nextId = (prefix) => `${prefix}_${Date.now().toString(36)}_${(idCounter++).toString(36)}`;

export class GameTree {
  constructor(initialBoard, turn = BLACK, hand = null) {
    this.nodes = new Map();
    this.branches = new Map();
    this.activeBranchId = "main";
    this.currentNodeId = null;
    this.init(initialBoard, turn, hand);
  }

  init(initialBoard, turn = BLACK, hand = null) {
    this.nodes.clear();
    this.branches.clear();

    const root = new GameTreeNode({
      id: "root_0",
      stepIdx: 0,
      turn,
      hand,
      board: initialBoard,
      logText: msg("logRoot")
    });
    this.nodes.set(root.id, root);
    this.branches.set("main", {
      id: "main",
      name: msg("branchMain"),
      forkNodeId: null,
      forkStepIdx: 0,
      parentBranchId: null,
      tipNodeId: root.id,
      createdAt: Date.now()
    });
    this.activeBranchId = "main";
    this.currentNodeId = root.id;
  }

  getNode(nodeId) {
    return this.nodes.get(nodeId);
  }

  getCurrentNode() {
    return this.nodes.get(this.currentNodeId);
  }

  getBranchTipNode(branchId = this.activeBranchId) {
    const branch = this.branches.get(branchId);
    if (!branch) return this.getCurrentNode() || this.nodes.get("root_0");
    if (branch.tipNodeId && this.nodes.has(branch.tipNodeId)) return this.nodes.get(branch.tipNodeId);
    return this.getCurrentNode() || this.nodes.get("root_0");
  }

  /** 在目前節點之後新增一步 */
  appendMoveNode({ turn, hand, move, board, gameOver, settlementData, logText, bonus }) {
    const parent = this.getCurrentNode();
    const node = new GameTreeNode({
      id: nextId("node"),
      parentId: parent ? parent.id : null,
      branchId: this.activeBranchId,
      stepIdx: parent ? parent.stepIdx + 1 : 1,
      turn, hand, move, board, gameOver, settlementData, logText, bonus
    });
    this.nodes.set(node.id, node);
    if (parent) parent.children.push(node.id);
    this.currentNodeId = node.id;
    const branch = this.branches.get(this.activeBranchId);
    if (branch) branch.tipNodeId = node.id;
    return node;
  }

  /** 由根節點到分支端點的完整順序節點 */
  getBranchHistory(branchId = this.activeBranchId) {
    const list = [];
    let curr = this.getBranchTipNode(branchId);
    while (curr) {
      list.unshift(curr);
      if (!curr.parentId) break;
      curr = this.nodes.get(curr.parentId);
    }
    return list;
  }

  createBranchFromNode(forkNodeId, branchName) {
    const forkNode = this.nodes.get(forkNodeId);
    if (!forkNode) return null;
    const id = nextId("branch");
    const name = branchName || msg("branchDefault", { n: forkNode.stepIdx });
    this.branches.set(id, {
      id,
      name,
      forkNodeId,
      forkStepIdx: forkNode.stepIdx,
      parentBranchId: this.activeBranchId,
      tipNodeId: forkNodeId,
      createdAt: Date.now()
    });
    this.activeBranchId = id;
    this.currentNodeId = forkNodeId;
    return { branchId: id, name, forkNode };
  }

  switchBranch(branchId, targetNodeId = null) {
    if (!this.branches.has(branchId)) return false;
    this.activeBranchId = branchId;
    if (targetNodeId && this.nodes.has(targetNodeId)) {
      this.currentNodeId = targetNodeId;
      return true;
    }
    const tip = this.getBranchTipNode(branchId);
    if (tip) this.currentNodeId = tip.id;
    return true;
  }
}
