/**
 * 🚀 權重黑白棋 (Weighted Othello) - 應用程式主入口與控制器 (Application Controller)
 * 架構與原專案一致：engine（規則）→ session（席位控制）→ sync() 推導 → render() 繪製。
 */

import { BLACK, WHITE, EMPTY } from "./core/constants.js";
import { opp, weightOf, blackWeight, whiteWeight, applyMoveToBoard } from "./core/rules.js";
import { GameEngine, normalizeVariant, isFiveVariant } from "./core/game-engine.js";
import { BoardView } from "./ui/board-view.js";
import { HandView } from "./ui/hand-view.js";
import { CoachView } from "./ui/coach-view.js";
import { HistoryView } from "./ui/history-view.js";
import { Storage } from "./storage/storage.js";
import { initI18n, applyI18n, tr, tx, pieceify, escapeHtml, clampName } from "./i18n.js";
import { explainScoredSquares, explainFiveSquares, moveFromSquare, bonusForMove } from "./ai/ai-service.js";
import { valueOf as fiveValueOf, findFive, discLabel } from "./core/five-rules.js";
import { PatternFx } from "./ui/pattern-fx.js";
import { normalizeBonusLevel } from "./core/bonus.js";
import { AiClient } from "./ai/ai-client.js";

// 與原專案共用的通用模組（唯讀引用，不修改）
import { ModalManager } from "../../src/ui/modal-manager.js";
import { sound } from "../../src/ui/sound.js";
import {
  SkinManager,
  DEFAULT_BLACK_PRESETS,
  DEFAULT_WHITE_PRESETS,
  getPieceBackgroundCss
} from "../../src/ui/skin-workshop.js";
import {
  VIEW,
  CTRL,
  HUMAN,
  CPU_SEAT,
  seatKey,
  createSession,
  deriveUiState
} from "../../src/core/control-state.js";

const PASS_DELAY = 700;

export class WeightedOthelloApp {
  constructor() {
    this.settings = Storage.getSettings();
    initI18n({ black: this.settings.blackName, white: this.settings.whiteName });
    sound.setEnabled(this.settings.soundEnabled);
    this.skinManager = new SkinManager();

    const blackSeat = this.settings.blackRole || HUMAN;
    const whiteSeat = this.settings.whiteRole || CPU_SEAT;

    this.engine = new GameEngine({
      blackPlayerType: blackSeat,
      whitePlayerType: whiteSeat,
      variant: normalizeVariant(this.settings.variant),
      bonusLevel: normalizeBonusLevel(this.settings.bonusLevel)
    });

    this.session = createSession({ black: blackSeat, white: whiteSeat });
    this.ui = deriveUiState({ session: this.session, turn: this.engine.currentTurn, gameOver: false, isAtTip: true });

    this.currentMode = "play"; // "play" | "setup"
    this.setupBrush = "toggle";
    this.cpuTimer = null;
    this.cpuRequest = null;   // v6 在 Worker 思考中的請求（局面改變時作廢）
    this.hintRequest = null;
    this.aiClient = new AiClient();
    this.passTimer = null;
    this.activeAiCandidates = [];
    this.hintOpen = false;
    this.previewGhostMove = null;
    this.renderCount = 0;

    this.init();
  }

  init() {
    ModalManager.init();
    applyI18n();

    this.boardView = new BoardView({
      boardContainer: document.getElementById("boardContainer"),
      onCellClick: (r, c) => this.handleCellClick(r, c),
      onCellHover: (r, c, isEnter) => this.handleCellHover(r, c, isEnter)
    });

    this.handView = new HandView({
      widget: document.getElementById("handWidget"),
      valLabel: document.getElementById("sideDiceValLabel"),
      bagLabel: document.getElementById("handBagLabel"),
      modeLabel: document.getElementById("handModeLabel")
    });

    this.patternFx = new PatternFx({
      frame: document.getElementById("boardFrame"),
      board: document.getElementById("boardContainer")
    });

    this.coachView = new CoachView({
      container: document.getElementById("coachContainer"),
      onPreviewMove: (move) => {
        this.previewGhostMove = move;
        this.renderBoard();
      },
      onApplyMove: (move) => {
        this.previewGhostMove = null;
        if (this.ui.view === VIEW.REVIEW) {
          this.handleStartFromHere();
        } else {
          this.takeOverIfPaused();
          this.executeMove(move.r, move.c);
        }
      }
    });

    this.historyView = new HistoryView({
      historyContainer: document.getElementById("historyBox"),
      branchSelectEl: null,
      onJumpToNode: (nodeId) => this.handleJumpToNode(nodeId),
      onOpenBranchModal: () => this.openBranchModal(),
      onStepFirst: () => this.handleStepFirst(),
      onStepPrev: () => this.handleStepBack(),
      onStepNext: () => this.handleStepForward(),
      onStepLatest: () => this.handleStepLatest(),
      onSwitchBranch: (branchId) => {
        this.teardown();
        this.engine.tree.switchBranch(branchId);
        const node = this.engine.tree.getCurrentNode();
        if (node) this.engine.jumpToNode(node.id);
        this.sync();
      }
    });

    this.engine.subscribe((event, payload) => this.handleEngineEvent(event, payload));

    this.bindDOMEvents();
    this.bindKeyboardShortcuts();
    this.applyTheme(this.settings.theme || "neon");
    this.applyAnimationLevel();

    this.engine.resetGame();
    // 開場若輪到 CPU，先停在暫停狀態，別讓使用者一進來就被 CPU 搶著下
    this.session.paused = this.session.seats[seatKey(this.engine.currentTurn)] === CPU_SEAT;

    if (!Storage.hasSeenOnboarding()) {
      setTimeout(() => this.openTutorialModal(), 500);
    }
    this.checkDeveloperMode();
    this.sync();
    this.coachView.render([], false);
  }

  // ===== 事件綁定 =====

  applyFlip() {
    const f = !!this.settings.flipped;
    this.boardView.setFlipped(f);
    document.querySelector(".seatPlayers")?.classList.toggle("flipped", f);
  }

  applyAnimationLevel() {
    document.documentElement.dataset.anim = this.settings.animationLevel || "standard";
  }

  bindDOMEvents() {
    document.getElementById("flipBtn")?.addEventListener("click", () => {
      this.settings.flipped = !this.settings.flipped;
      Storage.saveSettings(this.settings);
      this.applyFlip();
      this.render();
    });

    const applyName = (side, v) => {
      this.settings[side + "Name"] = v;
      window.takuNames = { ...window.takuNames, [side]: v };
      Storage.saveSettings(this.settings);
      const input = document.getElementById(side === "black" ? "settingBlackName" : "settingWhiteName");
      if (input) input.value = v;
      applyI18n();
      this.sync();
    };
    document.querySelectorAll(".seatGroup .seatLabel").forEach((label) => {
      const side = label.closest(".seatGroup").dataset.side;
      label.style.cursor = "pointer";
      label.title = tr("renameTip");
      label.addEventListener("click", () => {
        const v = window.prompt(tr("renamePrompt"), this.settings[side + "Name"] || "");
        if (v !== null) applyName(side, clampName(v).trim());
      });
    });
    for (const side of ["black", "white"]) {
      const input = document.getElementById(side === "black" ? "settingBlackName" : "settingWhiteName");
      if (!input) continue;
      input.value = this.settings[side + "Name"] || "";
      input.placeholder = tr(side);
      const clampInput = (e) => {
        if (e && e.isComposing) return;
        const clamped = clampName(input.value);
        if (clamped !== input.value) input.value = clamped;
      };
      input.addEventListener("compositionend", () => { clampInput(); input.dispatchEvent(new Event("input")); });
      input.addEventListener("input", (e) => {
        if (e.isComposing) return;
        clampInput(e);
        const v = input.value.trim();
        this.settings[side + "Name"] = v;
        window.takuNames = { ...window.takuNames, [side]: v };
        Storage.saveSettings(this.settings);
        applyI18n();
        this.sync();
      });
    }
    this.applyFlip();

    window.addEventListener("langchange", () => {
      for (const side of ["black", "white"]) {
        const input = document.getElementById(side === "black" ? "settingBlackName" : "settingWhiteName");
        if (input) input.placeholder = tr(side);
      }
      document.querySelectorAll(".seatGroup .seatLabel").forEach((l) => { l.title = tr("renameTip"); });
      this.sync();
      if (this.hintOpen) this.calculateAiHints(); else this.coachView.render([], false);
      if (document.getElementById("skinModal")?.classList.contains("open")) this.renderSkinWorkshop();
    });

    // 模式切換器
    const modeTabs = document.querySelectorAll(".modeTabs .tabBtn");
    modeTabs.forEach((btn) => {
      btn.addEventListener("click", () => {
        if (btn.dataset.mode === "rules") { this.openTutorialModal(); return; }
        modeTabs.forEach((b) => b.classList.remove("active"));
        btn.classList.add("active");
        this.setMode(btn.dataset.mode);
      });
    });

    document.getElementById("themeToggleBtn")?.addEventListener("click", () => this.openSkinModal());
    document.getElementById("settingsBtn")?.addEventListener("click", () => ModalManager.open("settingsModal"));

    const soundBtn = document.getElementById("soundToggleBtn");
    soundBtn?.addEventListener("click", () => {
      this.settings.soundEnabled = !this.settings.soundEnabled;
      sound.setEnabled(this.settings.soundEnabled);
      soundBtn.textContent = this.settings.soundEnabled ? "🔊" : "🔇";
      Storage.saveSettings(this.settings);
    });

    const restartBtn = document.getElementById("restartBtn");
    restartBtn?.addEventListener("click", async () => {
      const ok = await ModalManager.confirm({
        title: tr("restartTitle"),
        message: tr("restartMsg"),
        confirmText: tr("restartOk"),
        cancelText: tr("confirmCancel"),
        danger: true
      });
      if (ok) {
        this.teardown();
        this.currentMode = "play";
        this.engine.resetGame();
        this.sync();
      }
    });

    // 席位控制列：點一下即時改變「誰在下」
    document.addEventListener("click", (e) => {
      const btn = e.target.closest("button.seatBtn");
      if (btn && !btn.disabled) this.setSeat(btn.dataset.side, btn.dataset.owner);
    });

    document.getElementById("hintBtn")?.addEventListener("click", () => this.toggleHint());
    document.getElementById("watchBtn")?.addEventListener("click", () => this.handleWatchCpuVsCpu());
    document.getElementById("twoPlayerBtn")?.addEventListener("click", () => this.handleTwoPlayers());
    document.getElementById("vsCpuBtn")?.addEventListener("click", () => this.handleVsCpu());
    document.getElementById("pauseResumeBtn")?.addEventListener("click", () => {
      if (this.ui.ctrl === CTRL.CPU) this.handlePauseCpu();
      else if (this.ui.ctrl === CTRL.PAUSED) this.handleResumeCpu();
    });

    document.getElementById("setupModeBtn")?.addEventListener("click", () => {
      this.setMode(this.currentMode === "setup" ? "play" : "setup");
    });

    document.getElementById("statusBanner")?.addEventListener("click", (e) => {
      const btn = e.target.closest("button[data-action]");
      if (!btn) return;
      const act = btn.dataset.action;
      if (act === "startFromHere") this.handleStartFromHere();
      else if (act === "restart") restartBtn?.click();
    });

    const brushBtns = document.querySelectorAll(".brushBtn");
    brushBtns.forEach((b) => {
      b.addEventListener("click", () => {
        brushBtns.forEach((x) => x.classList.remove("active"));
        b.classList.add("active");
        this.setupBrush = b.dataset.brush;
      });
    });

    document.getElementById("setupContinueBtn")?.addEventListener("click", () => this.finishSetup());

    document.querySelectorAll(".modalCloseBtn, .modalCancelBtn").forEach((btn) => {
      btn.addEventListener("click", () => {
        const modal = btn.closest(".modalBackdrop");
        if (modal) ModalManager.close(modal.id);
      });
    });

    this.bindSettingsForm();
  }

  bindSettingsForm() {
    const bind = (id, apply, initial) => {
      const el = document.getElementById(id);
      if (!el) return;
      el.value = String(initial);
      el.addEventListener("change", (e) => apply(e.target.value));
    };
    const variantSelect = document.getElementById("settingVariant");
    if (variantSelect) {
      variantSelect.value = this.engine.variant;
      variantSelect.addEventListener("change", async () => {
        const variant = normalizeVariant(variantSelect.value);
        if (variant === this.engine.variant) return;
        const started = this.engine.tree.nodes.size > 1;
        const ok = !started || await ModalManager.confirm({
          title: tr("variantRestartTitle"),
          message: tr("variantRestartMsg"),
          confirmText: tr("variantRestartOk"),
          cancelText: tr("confirmCancel")
        });
        if (!ok) { variantSelect.value = this.engine.variant; return; }
        this.settings.variant = variant;
        Storage.saveSettings(this.settings);
        this.teardown();
        this.currentMode = "play";
        this.engine.resetGame(this.settings.bonusLevel, variant);
        this.updateModeControls();
        this.sync();
      });
    }
    const bonusSelect = document.getElementById("settingBonusLevel");
    if (bonusSelect) {
      bonusSelect.value = this.engine.bonusLevel;
      bonusSelect.addEventListener("change", async () => {
        const level = normalizeBonusLevel(bonusSelect.value);
        if (level === this.engine.bonusLevel) return;
        // 已經下過棋才需要確認；剛開局直接換
        const started = this.engine.tree.nodes.size > 1;
        const ok = !started || await ModalManager.confirm({
          title: tr("bonusRestartTitle"),
          message: tr("bonusRestartMsg"),
          confirmText: tr("bonusRestartOk"),
          cancelText: tr("confirmCancel")
        });
        if (!ok) { bonusSelect.value = this.engine.bonusLevel; return; }
        this.settings.bonusLevel = level;
        Storage.saveSettings(this.settings);
        this.teardown();
        this.currentMode = "play";
        this.engine.resetGame(level);
        this.updateModeControls();
        this.sync();
      });
    }
    this.updateModeControls();
    bind("settingV6Time", (v) => {
      this.settings.v6Time = Number(v) || 1000; Storage.saveSettings(this.settings);
    }, this.settings.v6Time || 1000);
  }

  /** 設定視窗：五連模式不使用加分，加分選單停用並提示 */
  updateModeControls() {
    const five = isFiveVariant(this.engine.variant);
    const bonusSelect = document.getElementById("settingBonusLevel");
    if (bonusSelect) {
      bonusSelect.disabled = five;
      bonusSelect.value = this.engine.bonusLevel;
    }
    const note = document.getElementById("bonusFiveOffNote");
    if (note) note.style.display = five ? "inline" : "none";
    const variantSelect = document.getElementById("settingVariant");
    if (variantSelect) variantSelect.value = this.engine.variant;
  }

  bindKeyboardShortcuts() {
    window.addEventListener("keydown", (e) => {
      if (["INPUT", "SELECT", "TEXTAREA"].includes(e.target.tagName)) return;
      if (ModalManager.activeModals.size > 0) return;
      switch (e.key) {
        case "ArrowLeft": e.preventDefault(); this.handleStepBack(); break;
        case "ArrowRight": e.preventDefault(); this.handleStepForward(); break;
        case " ":
          // 空白鍵只有一個意思：暫停／繼續 CPU
          if (this.ui.ctrl === CTRL.CPU) { e.preventDefault(); this.handlePauseCpu(); }
          else if (this.ui.ctrl === CTRL.PAUSED) { e.preventDefault(); this.handleResumeCpu(); }
          break;
        case "h":
        case "H":
          e.preventDefault();
          this.calculateAiHints();
          break;
        case "Escape":
          this.previewGhostMove = null;
          this.render();
          break;
      }
    });
  }

  setMode(mode) {
    this.currentMode = mode;
    const setupBar = document.getElementById("setupToolsBar");
    if (setupBar) setupBar.style.display = mode === "setup" ? "flex" : "none";
    if (mode === "setup") {
      this.stopCpuTimer();
      this.hintOpen = false;
      this.activeAiCandidates = [];
      this.coachView.render([], false);
    }
    this.sync();
  }

  finishSetup() {
    const first = Number(document.getElementById("setupFirstSelect")?.value) === WHITE ? WHITE : BLACK;
    this.teardown();
    this.currentMode = "play";
    document.getElementById("setupToolsBar").style.display = "none";
    document.querySelector(".modeTabs .tabBtn[data-mode='play']")?.classList.add("active");
    this.engine.commitSetup(first);
    this.session.assist = null;
    this.session.paused = this.session.seats[seatKey(this.engine.currentTurn)] === CPU_SEAT;
    sound.playSpawn();
    this.sync();
  }

  applyTheme(themeKey) {
    document.body.className = `theme-${themeKey}`;
    this.settings.theme = themeKey;
    Storage.saveSettings(this.settings);
  }

  // ===== 遊戲事件處理 =====

  handleEngineEvent(event, payload) {
    if (event === "MOVE_EXECUTED") {
      if (payload.move.five) {
        this.patternFx.playFive(payload.move.five, this.engine.fiveLabel(payload.move.five.value), this.settings.animationLevel === "minimal");
      } else if (payload.move.bonus) {
        this.patternFx.play(payload.move.bonus, this.engine.bonusPoints, this.settings.animationLevel === "minimal");
      } else {
        this.patternFx.clear();
      }
      if (payload.move.flips.length >= 3) sound.playCapture(); else sound.playSpawn();
      this.clearHints();
    } else if (event === "PASS_EXECUTED") {
      sound.playPass();
      this.clearHints();
    } else if (event === "GAME_OVER") {
      sound.playVictory();
      this.session.assist = null;
      setTimeout(() => this.celebrate(payload), 80);
    } else if (event === "STATE_RESTORED") {
      if (payload.node.move?.five) this.patternFx.playFive(payload.node.move.five, this.engine.fiveLabel(payload.node.move.five.value), true);
    } else if (event === "GAME_RESET") {
      this.teardown();
      this.resetSessionToSettings();
    }
    this.sync();
  }

  clearHints() {
    this.hintRequest = null;
    this.activeAiCandidates = [];
    this.hintOpen = false;
    this.previewGhostMove = null;
    this.coachView.render([], false);
  }

  // ===== 狀態推導與同步中樞 =====

  sync() {
    // 暫停只用於「CPU 對 CPU」；人機對戰時 CPU 輪到就直接下，不需要暫停
    if (this.session.paused && !(this.session.seats.black === CPU_SEAT && this.session.seats.white === CPU_SEAT)) {
      this.session.paused = false;
    }

    const tipNode = this.engine.tree.getBranchTipNode();
    const currNode = this.engine.tree.getCurrentNode();
    const isAtTip = Boolean(currNode && tipNode && currNode.id === tipNode.id);
    const inSetup = this.currentMode === "setup";

    const ui = deriveUiState({
      session: this.session,
      turn: this.engine.currentTurn,
      gameOver: this.engine.gameOver,
      isAtTip,
      passPending: Boolean(this.passTimer)
    });
    this.ui = ui;

    // 沒有合法位置：稍等一下讓玩家看清楚，然後自動 PASS
    const mustPass = ui.view === VIEW.LIVE && !inSetup && !this.engine.gameOver && this.engine.legalMoves().length === 0;
    if (mustPass && !this.passTimer) {
      sound.playPass();
      this.passTimer = setTimeout(() => {
        this.passTimer = null;
        this.engine.passTurn();
      }, PASS_DELAY);
      this.ui = deriveUiState({ session: this.session, turn: this.engine.currentTurn, gameOver: false, isAtTip, passPending: true });
    }

    if (this.ui.runCpuTimer && !inSetup && !this.cpuTimer && !this.cpuRequest) {
      this.startCpuTimer();
    } else if ((!this.ui.runCpuTimer || inSetup) && (this.cpuTimer || this.cpuRequest)) {
      this.stopCpuTimer();
    }

    this.render();
  }

  teardown() {
    this.stopCpuTimer();
    if (this.passTimer) { clearTimeout(this.passTimer); this.passTimer = null; }
    this.previewGhostMove = null;
    this.activeAiCandidates = [];
    this.hintRequest = null;
    this.patternFx?.clear();
  }

  // ===== 玩家操作 =====

  handleCellClick(r, c) {
    if (this.currentMode === "setup") {
      if (this.ui.view !== VIEW.LIVE) return;
      this.engine.setupCell(r, c, this.setupBrush);
      this.render();
      return;
    }

    // CPU 暫停且輪到它時，棋盤開放給人類：真的下出合法步伐時才接管該席位
    const pausedTakeoverOk = this.ui.view === VIEW.LIVE && this.ui.ctrl === CTRL.PAUSED;
    if (this.ui.boardLocked && !pausedTakeoverOk) return;
    if (!this.engine.findLegalMove(r, c)) return;

    this.takeOverIfPaused();
    this.executeMove(r, c);
  }

  takeOverIfPaused() {
    if (this.ui.ctrl !== CTRL.PAUSED) return;
    const side = seatKey(this.engine.currentTurn);
    this.session.assist = null;
    if (this.session.seats[side] !== HUMAN) this.setSeat(side, HUMAN);
    else { this.session.paused = false; this.sync(); }
  }

  handleCellHover(r, c, isEnter) {
    if (!this.activeAiCandidates.length) return;
    if (!isEnter) {
      if (this.previewGhostMove && this.previewGhostMove.r === r && this.previewGhostMove.c === c) {
        this.previewGhostMove = null;
        this.renderBoard();
      }
      return;
    }
    const cand = this.activeAiCandidates.find(h => h.move.r === r && h.move.c === c);
    if (!cand || this.previewGhostMove === cand.move) return;
    this.previewGhostMove = cand.move;
    this.renderBoard();
  }

  executeMove(r, c) {
    const tip = this.engine.tree.getBranchTipNode();
    const curr = this.engine.tree.getCurrentNode();
    if (curr && tip && curr.id !== tip.id) return false; // REVIEW 狀態不允許直接落子

    this.stopCpuTimer();
    const player = this.engine.currentTurn;
    const ok = this.engine.executeMove(r, c);
    if (ok && this.session.assist && this.session.assist.color === player) {
      this.session.assist.left -= 1;
      if (this.session.assist.left <= 0) this.session.assist = null;
    }
    if (ok) this.sync();
    return ok;
  }

  // ===== CPU 行動推進 =====

  startCpuTimer() {
    this.stopCpuTimer();
    if (!this.ui.runCpuTimer) return;
    // 引擎本身要思考約一秒，不必再額外停頓
    this.cpuTimer = setTimeout(() => {
      this.cpuTimer = null;
      this.performCpuMove();
    }, 150);
  }

  performCpuMove() {
    if (this.engine.gameOver || this.ui.ctrl !== CTRL.CPU) return;
    const turn = this.engine.currentTurn;
    const nodeId = this.engine.tree.currentNodeId;
    const board = this.engine.board, hand = this.engine.hand;
    const req = {};
    this.cpuRequest = req;
    this.aiClient.search({ board, player: turn, hand, timeMs: this.settings.v6Time || 1000, bonusPoints: this.engine.bonusPoints, variant: this.engine.variant }).then((res) => {
      if (this.cpuRequest !== req) return; // 已暫停、悔棋或換局：結果作廢
      this.cpuRequest = null;
      if (this.engine.tree.currentNodeId !== nodeId || this.ui.ctrl !== CTRL.CPU) { this.sync(); return; }
      const move = res ? moveFromSquare(this.engine.board, turn, res.bestSq) : null;
      if (move) this.executeMove(move.r, move.c);
      else this.engine.passTurn();
    });
  }

  stopCpuTimer() {
    if (this.cpuTimer) { clearTimeout(this.cpuTimer); this.cpuTimer = null; }
    this.cpuRequest = null;
  }

  // ===== 席位與控制者切換 =====

  handlePauseCpu() {
    this.session.paused = true;
    this.stopCpuTimer();
    this.sync();
  }

  handleResumeCpu() {
    this.session.paused = false;
    this.sync();
  }

  syncEngineSeats() {
    this.engine.blackPlayerType = this.session.seats.black;
    this.engine.whitePlayerType = this.session.seats.white;
  }

  persistSeats() {
    this.settings.blackRole = this.session.seats.black;
    this.settings.whiteRole = this.session.seats.white;
    Storage.saveSettings(this.settings);
  }

  resetSessionToSettings() {
    this.session = createSession({
      black: this.settings.blackRole || HUMAN,
      white: this.settings.whiteRole || CPU_SEAT
    });
    this.syncEngineSeats();
    this.session.paused = this.session.seats[seatKey(this.engine.currentTurn)] === CPU_SEAT;
  }

  /** 改變一個席位的操作者：「換我下 / 讓 CPU 下 / CPU 對戰」唯一的入口 */
  setSeat(side, owner) {
    if (side !== "black" && side !== "white") return;
    if (owner !== HUMAN && owner !== CPU_SEAT) return;
    if (this.session.seats[side] === owner) return;

    this.session.seats[side] = owner;
    this.persistSeats();
    this.syncEngineSeats();

    if (owner === CPU_SEAT) {
      this.session.paused = true; // 切換到 CPU 一律先暫停，讓使用者決定何時放行
      this.session.assist = null;
    } else if (side === seatKey(this.engine.currentTurn)) {
      this.session.assist = null;
      this.session.paused = false;
    }
    this.teardown();
    this.sync();
  }

  handleWatchCpuVsCpu() {
    this.session.seats.black = CPU_SEAT;
    this.session.seats.white = CPU_SEAT;
    this.session.assist = null;
    this.session.paused = false;
    this.persistSeats();
    this.syncEngineSeats();
    this.teardown();
    this.sync();
  }

  handleVsCpu() {
    this.setSeat(seatKey(this.engine.currentTurn), CPU_SEAT);
    this.session.paused = false;
    this.sync();
  }

  handleTwoPlayers() {
    this.session.seats.black = HUMAN;
    this.session.seats.white = HUMAN;
    this.session.assist = null;
    this.session.paused = false;
    this.persistSeats();
    this.syncEngineSeats();
    this.teardown();
    this.sync();
  }

  // ===== AI 提示與教練 =====

  toggleHint() {
    if (this.hintOpen) {
      this.clearHints();
      this.render();
    } else {
      this.hintOpen = true;
      this.calculateAiHints();
    }
  }

  calculateAiHints() {
    if (this.engine.gameOver) {
      this.activeAiCandidates = [];
      this.coachView.render([], false, tr("coachEmptyEnded"));
      this.render();
      return;
    }
    this.hintOpen = true;
    const turn = this.engine.currentTurn;
    const hand = this.engine.hand;
    if (hand == null || this.engine.legalMoves().length === 0) {
      this.activeAiCandidates = [];
      this.coachView.render([], false, tr("coachEmptyNoMove"));
      this.render();
      return;
    }

    const nodeId = this.engine.tree.currentNodeId;
    const board = this.engine.board;
    const req = {};
    this.hintRequest = req;
    this.activeAiCandidates = [];
    this.coachView.render([], true);
    this.render();
    const bonusPoints = this.engine.bonusPoints;
    const variant = this.engine.variant;
    this.aiClient.search({ board, player: turn, hand, timeMs: this.settings.v6Time || 1000, multiPV: true, bonusPoints, variant }).then((res) => {
      if (this.hintRequest !== req || !this.hintOpen || this.engine.tree.currentNodeId !== nodeId) return;
      this.hintRequest = null;
      if (!res) { this.coachView.render([], false, tr("coachEmptyNoMove")); return; }
      if (isFiveVariant(variant)) {
        // 五連類模式：說明已含引擎的勝率估計
        const candidates = explainFiveSquares(board, turn, hand, res.scores, 3, variant === "fivePlain");
        this.activeAiCandidates = candidates;
        this.coachView.render(candidates, false);
        this.render();
        return;
      }
      const candidates = explainScoredSquares(board, turn, hand, res.scores, 3, bonusPoints);
      const note = (sc) => {
        const v = (sc >= 0 ? "+" : "") + sc.toFixed(1);
        return res.chanceExact ? tr("exChanceExact", { s: v }) : res.exact ? tr("exExact", { s: v }) : tr("exDepth", { d: res.depth, s: v });
      };
      for (const c of candidates) c.explanation.pros.push(note(c.score));
      this.activeAiCandidates = candidates;
      this.coachView.render(candidates, false);
      this.render();
    });
  }

  // ===== 歷史回放、跳轉與分支 =====

  handleJumpToNode(nodeId) {
    this.teardown();
    this.engine.jumpToNode(nodeId);
    this.sync();
  }

  handleStepFirst() {
    const root = this.engine.tree.getNode("root_0");
    if (root) this.handleJumpToNode(root.id);
  }

  handleStepLatest() {
    const tip = this.engine.tree.getBranchTipNode();
    if (!tip) return;
    // 回到最新時若輪到 CPU，先暫停，由使用者決定何時放行
    if (this.session.seats[seatKey(tip.turn)] === CPU_SEAT) this.session.paused = true;
    this.handleJumpToNode(tip.id);
  }

  handleStepBack() {
    const list = this.engine.tree.getBranchHistory();
    const idx = list.findIndex((n) => n.id === this.engine.tree.currentNodeId);
    if (idx > 0) this.handleJumpToNode(list[idx - 1].id);
  }

  handleStepForward() {
    const list = this.engine.tree.getBranchHistory();
    const idx = list.findIndex((n) => n.id === this.engine.tree.currentNodeId);
    if (idx >= 0 && idx < list.length - 1) this.handleJumpToNode(list[idx + 1].id);
  }

  /** 從歷史局面直接開闢新分支，原路線完整保留在分支選單裡 */
  handleStartFromHere(nodeId = null) {
    const target = nodeId || this.engine.tree.currentNodeId;
    if (!this.engine.tree.getNode(target)) return;
    this.teardown();
    this.session.assist = null;
    this.engine.startFromHere(target);
    this.session.paused = this.session.seats[seatKey(this.engine.currentTurn)] === CPU_SEAT;
    sound.playSpawn();
    this.sync();
  }

  openBranchModal() {
    const listEl = document.getElementById("branchTreeList");
    if (listEl) {
      const tree = this.engine.tree;
      const build = (branchId, depth, isLast) => {
        const branch = tree.branches.get(branchId);
        if (!branch) return "";
        const isActive = branchId === tree.activeBranchId;
        const children = [...tree.branches.values()]
          .filter((b) => b.parentBranchId === branchId)
          .sort((a, b) => a.forkStepIdx - b.forkStepIdx);
        const prefix = depth > 0 ? (isLast ? "└─ " : "├─ ") : "";
        let html = `<div class="branchTreeRow${isActive ? " active" : ""}" data-branch-id="${branchId}" style="--depth:${depth}">
          <span class="branchTreePrefix">${prefix}</span>
          <span class="branchTreeName">${escapeHtml(tx(branch.name))}</span>
          ${isActive ? '<span class="branchTreeCheck">✓</span>' : ""}
        </div>`;
        children.forEach((ch, i) => { html += build(ch.id, depth + 1, i === children.length - 1); });
        return html;
      };
      listEl.innerHTML = build("main", 0, true);
      listEl.onclick = (e) => {
        const row = e.target.closest(".branchTreeRow");
        if (!row || !row.dataset.branchId) return;
        this.teardown();
        tree.switchBranch(row.dataset.branchId);
        const node = tree.getCurrentNode();
        if (node) this.engine.jumpToNode(node.id);
        ModalManager.close("branchModal");
        this.sync();
      };
    }
    ModalManager.open("branchModal");
  }

  openTutorialModal() {
    ModalManager.open("tutorialModal");
    Storage.setOnboardingSeen();
  }

  // ===== 棋子外觀工坊 =====

  openSkinModal() {
    ModalManager.open("skinModal");
    const sb = document.getElementById("soundToggleBtn");
    if (sb) sb.textContent = this.settings.soundEnabled ? "🔊" : "🔇";
    this.bindSkinEventsOnce();
    this.renderSkinWorkshop();
  }

  renderSkinWorkshop() {
    const config = this.skinManager.config;
    const curTheme = this.settings.theme || "neon";
    document.querySelectorAll("#themePresetGroup .skinPresetChip").forEach((chip) => {
      chip.classList.toggle("active", chip.dataset.theme === curTheme);
    });

    const renderSide = (side, isBlack, presets) => {
      const conf = config[side];
      const badge = document.getElementById(`${side}SkinBadge`);
      const disc = document.getElementById(`${side}PreviewDisc`);
      const colorInput = document.getElementById(`${side}ColorInput`);
      const colorDot = document.getElementById(`${side}ColorDot`);
      const clearBtn = document.getElementById(`${side}ClearImgBtn`);
      const gloss = document.getElementById(`${side}GlossToggle`);
      const group = document.getElementById(`${side}PresetGroup`);

      if (badge) badge.textContent = conf.type === "preset" ? tr("p_" + conf.id) : (conf.type === "image" ? tr("customImage") : tr("customColor"));
      if (disc) disc.style.background = getPieceBackgroundCss(conf, isBlack);
      if (colorInput && conf.color) colorInput.value = conf.color;
      if (colorDot && conf.color) colorDot.style.background = conf.color;
      if (clearBtn) clearBtn.style.display = conf.type === "image" ? "inline-flex" : "none";
      if (gloss) gloss.checked = conf.gloss !== false;
      if (group) {
        group.innerHTML = "";
        presets.forEach((p) => {
          const chip = document.createElement("button");
          chip.className = `skinPresetChip ${conf.type === "preset" && conf.id === p.id ? "active" : ""}`;
          chip.innerHTML = `<span class="skinPresetDot" style="background:${p.color}"></span><span>${tr("p_" + p.id)}</span>`;
          chip.addEventListener("click", () => {
            this.saveSkin(side, { type: "preset", id: p.id, label: p.label, color: p.color, gradient: p.gradient, imageData: null, gloss: true });
          });
          group.appendChild(chip);
        });
      }
    };
    renderSide("black", true, DEFAULT_BLACK_PRESETS);
    renderSide("white", false, DEFAULT_WHITE_PRESETS);
  }

  saveSkin(side, conf) {
    this.skinManager.saveConfig({ [side]: conf });
    this.renderSkinWorkshop();
    this.render();
  }

  bindSkinEventsOnce() {
    if (this._skinEventsBound) return;
    this._skinEventsBound = true;

    for (const side of ["black", "white"]) {
      document.getElementById(`${side}ColorInput`)?.addEventListener("input", (e) => {
        this.saveSkin(side, { type: "color", id: `custom-${side}`, label: "自訂色彩", color: e.target.value, gradient: null, imageData: null, gloss: true });
      });

      const imgInput = document.getElementById(`${side}ImgInput`);
      imgInput?.addEventListener("change", async (e) => {
        const file = e.target.files?.[0];
        if (!file) return;
        try {
          const dataUrl = await SkinManager.resizeImageToDataUrl(file, 256);
          this.saveSkin(side, { type: "image", id: `custom-img-${side}`, label: "自訂圖片", color: null, gradient: null, imageData: dataUrl, gloss: true });
        } catch (err) {
          alert(tr("imgReadFail") + (err?.message || err));
        }
        imgInput.value = "";
      });

      document.getElementById(`${side}ClearImgBtn`)?.addEventListener("click", () => {
        const presets = side === "black" ? DEFAULT_BLACK_PRESETS : DEFAULT_WHITE_PRESETS;
        const p = presets[0];
        this.saveSkin(side, { type: "preset", id: p.id, label: p.label, color: p.color, gradient: p.gradient, imageData: null, gloss: true });
      });

      document.getElementById(`${side}GlossToggle`)?.addEventListener("change", (e) => {
        this.saveSkin(side, { ...this.skinManager.config[side], gloss: e.target.checked });
      });
    }

    document.querySelectorAll("#themePresetGroup .skinPresetChip").forEach((chip) => {
      chip.addEventListener("click", () => {
        if (!chip.dataset.theme) return;
        this.applyTheme(chip.dataset.theme);
        this.renderSkinWorkshop();
      });
    });

    document.getElementById("skinResetDefaultBtn")?.addEventListener("click", () => {
      this.applyTheme("neon");
      this.skinManager.resetDefaults();
      this.renderSkinWorkshop();
      this.render();
    });
  }

  // ===== 終局表現 =====

  celebrate(data) {
    if (!data || data.winner === EMPTY || this.settings.animationLevel === "minimal") return;
    const side = data.winner === BLACK ? "black" : "white";
    const card = document.querySelector(`.seatGroup[data-side="${side}"]`);
    if (!card) return;
    const rect = card.getBoundingClientRect();
    const layer = document.createElement("div");
    layer.className = "confettiLayer";
    layer.style.left = `${rect.left + rect.width / 2}px`;
    layer.style.top = `${rect.top + rect.height / 2}px`;
    const icons = ["🎉", "✨", "⭐", "🎊", "🏆"];
    for (let i = 0; i < 32; i++) {
      const p = document.createElement("span");
      p.className = "confettiPiece";
      const ang = Math.random() * Math.PI * 2;
      const dist = 70 + Math.random() * 190;
      p.textContent = icons[i % icons.length];
      p.style.setProperty("--dx", `${Math.cos(ang) * dist}px`);
      p.style.setProperty("--dy", `${Math.sin(ang) * dist - 40}px`);
      p.style.setProperty("--rot", `${Math.round(Math.random() * 720 - 360)}deg`);
      p.style.animationDelay = `${Math.random() * 0.25}s`;
      p.style.fontSize = `${14 + Math.random() * 14}px`;
      layer.appendChild(p);
    }
    document.body.appendChild(layer);
    setTimeout(() => layer.remove(), 2600);
  }

  checkDeveloperMode() {
    const hud = document.getElementById("developerHud");
    if (hud) hud.style.display = new URL(window.location.href).searchParams.get("debug") === "1" ? "grid" : "none";
  }

  // ===== 全域渲染 =====

  /** 目前輪到的玩家在各合法位置的預計得分：落下的棋 + 翻面造成的權重差，加分模式另計牌型加分 */
  legalMoveMap() {
    const map = new Map();
    const hand = this.engine.hand;
    if (hand == null || this.engine.gameOver) return map;
    const me = this.engine.currentTurn;
    const foe = opp(me);
    if (isFiveVariant(this.engine.variant)) {
      // 五連類模式：我方得分 = 落下的棋 + 翻過來的棋（加權五連用左 × 右，五連每顆 1 分）；能直接連成五的標 ★5
      const val = this.engine.variant === "five" ? fiveValueOf : () => 1;
      for (const m of this.engine.legalMoves()) {
        let gain = val(hand);
        for (const [fr, fc] of m.flips) gain += val(this.engine.board[fr][fc].id);
        const five = !!findFive(applyMoveToBoard(this.engine.board, m, hand, me), me);
        map.set(`${m.r},${m.c}`, { gain, bonus: 0, five, flips: m.flips });
      }
      return map;
    }
    for (const m of this.engine.legalMoves()) {
      let gain = weightOf(hand, me);
      for (const [fr, fc] of m.flips) {
        const d = this.engine.board[fr][fc];
        gain += weightOf(d.id, me) - weightOf(d.id, foe);
      }
      const bonus = this.engine.bonusPoints ? bonusForMove(this.engine.board, m, hand, me, this.engine.bonusPoints).points : 0;
      map.set(`${m.r},${m.c}`, { gain, bonus, flips: m.flips });
    }
    return map;
  }

  renderBoard() {
    const state = this.engine.getState();
    const inSetup = this.currentMode === "setup";
    const showLegal = !inSetup && this.ui.view === VIEW.LIVE && (this.ui.ctrl === CTRL.HUMAN || this.ui.ctrl === CTRL.PAUSED) && !this.passTimer;
    this.boardView.render({
      board: state.board,
      legalMoves: showLegal ? this.legalMoveMap() : new Map(),
      lastMove: state.lastMove,
      activeAiHints: this.activeAiCandidates,
      previewGhostMove: this.previewGhostMove,
      ghostDisc: state.hand != null ? { id: state.hand, face: state.currentTurn } : null,
      variant: state.variant
    });
  }

  render() {
    this.renderCount++;
    const state = this.engine.getState();
    const ui = this.ui;
    const inSetup = this.currentMode === "setup";
    const isCpuTurn = ui.ctrl === CTRL.CPU;
    const isPaused = ui.ctrl === CTRL.PAUSED;
    const isReview = ui.view === VIEW.REVIEW;
    const isEnded = ui.view === VIEW.ENDED;
    const currNode = this.engine.tree.getCurrentNode();

    const turnText = state.currentTurn === BLACK ? tr("sideBlack") : tr("sideWhite");
    const five = isFiveVariant(state.variant);
    const plain = state.variant === "fivePlain";
    const handWeight = state.hand == null ? "?" : five ? (plain ? 1 : fiveValueOf(state.hand)) : weightOf(state.hand, state.currentTurn);
    // 五連類模式的「抽到的棋」：加權五連「7×8（56 分）」，五連「G|H」
    const handDisc = state.hand == null ? "?" : plain
      ? discLabel(state.hand, true)
      : tr("discWithValue", { disc: discLabel(state.hand, false), v: fiveValueOf(state.hand) });

    // 1. 狀態橫幅
    const banner = document.getElementById("statusBanner");
    if (banner) banner.className = `statusBanner ${inSetup ? "review" : (isReview ? "review" : (isEnded ? "ended" : ui.ctrl))}`;
    const badge = document.getElementById("statusBadge");
    if (badge) badge.textContent = inSetup || isReview ? "🟠" : (isEnded ? "⚪" : (isPaused ? "🟡" : (isCpuTurn ? "🟣" : "🔵")));

    const statusText = document.getElementById("statusText");
    if (statusText) {
      let text;
      if (inSetup) text = tr("stSetup");
      else if (isReview) text = tr("stReview", { n: currNode ? currNode.stepIdx : 0 });
      else if (isEnded) text = tr("stEnded", { reason: state.settlementData ? tx(state.settlementData.reason) : tr("reasonDefault") });
      else if (this.passTimer) text = tr("stPassing", { turn: turnText });
      else if (isPaused) text = tr(ui.isCpuVsCpu ? "stPaused" : "stPausedOne", { turn: turnText });
      else if (isCpuTurn) {
        const actor = ui.isCpuVsCpu ? tr("stCpuVsCpu") : tr("stCpu");
        text = tr(five ? "stCpuThinkingFive" : "stCpuThinking", { actor, turn: turnText, w: handWeight, disc: handDisc });
      } else text = tr(five ? "stHumanFive" : "stHuman", { turn: turnText, w: handWeight, disc: handDisc });
      statusText.innerHTML = pieceify(escapeHtml(text));
    }

    const statusActions = document.getElementById("statusActions");
    if (statusActions) {
      if (isReview && !inSetup) {
        statusActions.innerHTML = `<button class="btn small success" data-action="startFromHere" title="${tr("startFromHereTip")}">${tr("startFromHere")}</button>`;
      } else if (isEnded && !inSetup) {
        statusActions.innerHTML = `<button class="btn small" data-action="restart" title="${tr("restartTip")}">${tr("restart")}</button>`;
      } else {
        statusActions.innerHTML = "";
      }
    }

    const boardFrame = document.getElementById("boardFrame");
    if (boardFrame) {
      boardFrame.classList.toggle("board-review", isReview);
      boardFrame.classList.toggle("board-cpu", isCpuTurn);
      boardFrame.classList.toggle("board-paused", isPaused);
    }

    // 2. 比分（權重總和 + 加分）
    const sc = this.engine.scores();
    const bonusOn = state.bonusMode;
    const totalB = sc.black + (bonusOn ? state.bonus[BLACK] : 0);
    const totalW = sc.white + (bonusOn ? state.bonus[WHITE] : 0);
    document.getElementById("scoreBlackNum").textContent = totalB;
    document.getElementById("scoreWhiteNum").textContent = totalW;
    // 五連模式的分數就是棋子數，不必再另外顯示
    const showCount = state.variant !== "fivePlain";
    document.getElementById("countBlackTag").textContent = showCount ? `${sc.blackCount}` : "";
    document.getElementById("countWhiteTag").textContent = showCount ? `${sc.whiteCount}` : "";
    document.getElementById("bonusBlackTag").textContent = bonusOn ? `🃏+${state.bonus[BLACK]}` : "";
    document.getElementById("bonusWhiteTag").textContent = bonusOn ? `🃏+${state.bonus[WHITE]}` : "";
    const result = state.gameOver ? state.settlementData : null;
    document.querySelectorAll(".seatGroup").forEach((g) => {
      const mine = g.dataset.side === "black" ? BLACK : WHITE;
      g.classList.toggle("winner", !!result && result.winner === mine);
      g.classList.toggle("loser", !!result && result.winner !== EMPTY && result.winner !== mine);
      g.classList.toggle("drawn", !!result && result.winner === EMPTY);
    });
    const leadBadge = document.getElementById("scoreLeadBadge");
    if (leadBadge) {
      const diff = totalB - totalW;
      leadBadge.classList.toggle("final", !!result);
      if (result) {
        const winnerName = tr(result.winner === BLACK ? "black" : "white");
        leadBadge.textContent = result.winner === EMPTY
          ? tr("finalDraw")
          : result.byFive
            ? tr("finalFive", { name: winnerName, v: this.engine.fiveLabel(result.five.value) })
            : tr("finalWin", { name: winnerName, n: Math.abs(diff) });
        leadBadge.style.background = "rgba(250, 204, 21, 0.25)";
        leadBadge.style.color = "#fde047";
      } else if (diff > 0) {
        leadBadge.textContent = tr("leadBlack", { n: diff });
        leadBadge.style.background = "rgba(56, 189, 248, 0.2)";
        leadBadge.style.color = "#38bdf8";
      } else if (diff < 0) {
        leadBadge.textContent = tr("leadWhite", { n: Math.abs(diff) });
        leadBadge.style.background = "rgba(250, 204, 21, 0.2)";
        leadBadge.style.color = "#facc15";
      } else {
        leadBadge.textContent = tr("leadTie");
        leadBadge.style.background = "rgba(255, 255, 255, 0.1)";
        leadBadge.style.color = "#cbd5e1";
      }
    }

    // 3. 棋盤與抽棋面板
    this.renderBoard();
    this.handView.render({
      hand: state.hand,
      face: state.currentTurn,
      bagSize: this.engine.bagSize(),
      gameOver: state.gameOver,
      bonusPoints: state.bonusPoints,
      variant: state.variant
    });

    // 4. 棋譜
    this.historyView.render({ gameTree: this.engine.tree, currentNodeId: this.engine.tree.currentNodeId });

    // 5. 自由排盤按鈕只在 LIVE 顯示；唯讀／終局時自動離開排盤模式
    const canSetup = ui.view === VIEW.LIVE || inSetup;
    const setupModeBtn = document.getElementById("setupModeBtn");
    if (setupModeBtn) {
      setupModeBtn.style.display = canSetup ? "inline-flex" : "none";
      setupModeBtn.classList.toggle("active", inSetup);
    }
    if (!canSetup && inSetup) {
      this.currentMode = "play";
      document.getElementById("setupToolsBar").style.display = "none";
    }

    // 6. 席位列
    const seatCurrentKey = seatKey(state.currentTurn);
    const seatsEditable = ui.view === VIEW.LIVE;
    document.querySelectorAll("#seatBar .seatGroup").forEach((g) => {
      g.classList.toggle("isTurn", g.dataset.side === seatCurrentKey);
    });
    document.querySelectorAll(".seatBtn").forEach((btn) => {
      btn.classList.toggle("active", ui.seats[btn.dataset.side] === btn.dataset.owner);
      btn.disabled = !seatsEditable;
    });

    // 7. 動作列
    const show = (id, on) => { const el = document.getElementById(id); if (el) el.style.display = on ? "inline-flex" : "none"; };
    const live = ui.view === VIEW.LIVE && !inSetup;
    const bothHuman = ui.seats.black === HUMAN && ui.seats.white === HUMAN;
    const hintBtn = document.getElementById("hintBtn");
    if (hintBtn) {
      hintBtn.style.display = !isEnded ? "inline-flex" : "none";
      hintBtn.classList.toggle("active", this.hintOpen);
    }
    const vsCpuBtn = document.getElementById("vsCpuBtn");
    if (vsCpuBtn) {
      vsCpuBtn.style.display = live && bothHuman ? "inline-flex" : "none";
      vsCpuBtn.textContent = tr("vsCpu", { name: state.currentTurn === BLACK ? tr("black") : tr("white") });
    }
    show("twoPlayerBtn", live && !bothHuman);
    show("watchBtn", live && !ui.isCpuVsCpu);
    const pauseBtn = document.getElementById("pauseResumeBtn");
    if (pauseBtn) {
      if (isCpuTurn) {
        pauseBtn.style.display = ui.isCpuVsCpu ? "inline-flex" : "none";
        pauseBtn.textContent = tr("pause");
        pauseBtn.title = tr("pauseTip");
        pauseBtn.className = "btn small";
      } else if (isPaused) {
        pauseBtn.style.display = "inline-flex";
        pauseBtn.textContent = tr("resume");
        pauseBtn.title = tr("resumeTip");
        pauseBtn.className = "btn small primary";
      } else {
        pauseBtn.style.display = "none";
      }
    }

    // 8. 開發者 HUD
    const setText = (id, v) => { const el = document.getElementById(id); if (el) el.textContent = v; };
    setText("hudRenders", this.renderCount);
    setText("hudTurn", state.currentTurn === BLACK ? "BLACK" : "WHITE");
    setText("hudHand", state.hand != null ? `${state.hand} (W${whiteWeight(state.hand)}/B${blackWeight(state.hand)})` : "null");
    setText("hudNodes", this.engine.tree.nodes.size);
  }
}

if (typeof window !== "undefined") {
  window.addEventListener("DOMContentLoaded", () => {
    window.__app = new WeightedOthelloApp();
    window.WeightedOthello = {
      app: window.__app,
      getEngine: () => window.__app.engine,
      getState: () => window.__app.engine.getState(),
      reset: () => window.__app.engine.resetGame()
    };
  });
}


