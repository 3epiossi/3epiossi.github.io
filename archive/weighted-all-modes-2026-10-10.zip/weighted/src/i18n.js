/**
 * 🌐 權重黑白棋 - 多語系（中文 / English / 日本語）
 *
 * - tr(key, params)  依目前語言取字，{name} 占位符會被 params 取代，{bn}/{wn} 是雙方的自訂名稱
 * - msg(key, params) 建立結構化訊息，存進對局樹後切換語言也能重新翻譯；tx() 負責解開
 * - applyI18n()      翻譯 HTML 裡帶 data-i18n / data-i18n-title 的靜態文字
 *
 * 找不到的鍵會退回原專案的字典（外觀預設名稱 p_* 等共用字串）。
 */

import { tr as baseTr } from "../../src/i18n.js";

const D = {
  zh: {
    pageTitle: "權重黑白棋", brandName: "權重黑白棋",
    modePlay: "🎮 對局模式", modeRules: "📜 規則說明",
    btnDice: "🎲 誰會贏？", titleDice: "切換到「誰會贏？」骰子黑白棋",
    btnTheme: "🎨 主題與外觀", titleTheme: "切換棋盤主題風格與客製棋子外觀",
    btnFlip: "🔃 左右互換", titleFlip: "黑白雙方位置左右互換",
    seatWhite: "⚪ 白方", seatBlack: "⚫ 黑方", seatHuman: "👤 我", seatCpu: "🤖 CPU",
    scoreTie: "平手", btnSettings: "⚙️ 設定", titleSettings: "進階對弈設定",
    btnTwoPlayer: "👥 雙人對戰", titleTwoPlayer: "黑白雙方都由人類操作", btnWatch: "👁 CPU 對戰", btnPause: "⏸ 暫停",
    setupLabel: "擺盤筆刷：", brushToggle: "🔄 輪替", brushBlack: "⚫ 放置黑面朝上", brushWhite: "⚪ 放置白面朝上", brushEmpty: "🗑 清除格子",
    setupFirst: "先手：", setupContinue: "✅ 排定完成，接著下下去！",
    historyTitle: "📜 對局棋譜", branchLabel: "主線", btnSetupMode: "✏️ 自由排盤", btnRestart: "🔄 重設", titleRestart: "重新開局",
    historyFirst: "⏮ 首步", historyPrev: "◀ 上手", historyNext: "▶ 下手", historyLatest: "⏭ 最新",
    historyTip: "💡 提示：點擊任一步可回顧當時歷史局面。",
    coachBarTitle: "🧠 AI 教練", btnHint: "💡 提示",
    settingsTitle: "⚙️ 對弈進階設定",
    settingsHint: "💡 「黑白雙方由誰操作」在棋盤上方的席位列，點一下即時切換。這裡只設定 CPU 的思考時間與節奏。",
    settingsDone: "完成設定",
    v6TimeLabel: "🧠 CPU 每步思考時間：", time500: "0.5 秒", time1000: "1 秒（預設）", time2000: "2 秒", time4000: "4 秒",
    exDepth: "搜尋 {d} 層，評估 {s}", exExact: "終盤已算到底：預期終局分差 {s}", exChanceExact: "終盤精確計算（含每一種抽棋）：預期終局分差 {s}",
    tutorialModalTitle: "60 秒掌握權重黑白棋！", tutorialOk: "我懂了，開始下棋！",
    rule1Title: "規則一：每顆棋兩面各有權重", rule1Text: "大數字是朝上那面的權重；右下角圈起來的小數字是背面的權重，圈的顏色就是背面的顏色。64 顆棋剛好是 1～8 × 1～8 的所有組合，各出現一次。", legendNote: "左：黑面朝上，黑面 1 分、白面 8 分（白色圈）。右：白面朝上，白面 8 分、黑面 1 分（黑色圈）。翻面後兩個數字互換位置。",
    rule2Title: "規則二：每回合抽一顆，你決定放哪", rule2Text: "輪到你時，系統從袋子隨機抽一顆棋，朝上的一面是你的顏色。你只能選擇落子位置，與黑白棋相同，必須夾住對手的棋。",
    rule3Title: "規則三：夾住就翻面，權重跟著換", rule3Text: "被翻的棋會換成另一面的權重。一顆棋翻來翻去，你得到的是你那一面的數字，對手得到的是另一面的數字。",
    rule4Title: "規則四：比權重總和，不比顆數", rule4Text: "終局時加總各自顏色朝上的權重，多者獲勝，相同為平手。沒有合法位置時 PASS，抽到的棋放回袋子。",
    confirmTitle: "請確認操作", confirmMsg: "您確定要執行這項操作嗎？", confirmCancel: "取消", confirmOk: "確認",
    branchModalTitle: "對局樹", branchClose: "關閉",
    skinTitle: "🎨 主題風格與棋子外觀工坊", skinSoundLabel: "🔊 遊戲音效",
    nameLabel: "🏷️ 自訂雙方名稱（左：黑方　右：白方，留空用預設）：",
    skinThemeSection: "🏞️ 棋盤場景風格主題",
    themeNeon: "霓虹深邃 (預設)", themeClassic: "經典翡翠", themeWood: "雅緻木紋", themeSlate: "玄武極簡",
    skinCustomHint: "自由客製化黑棋與白棋的外觀！可選擇高質感寶石預設、自訂專屬 3D 渲染色彩，或上傳圖片打造個性化棋子。",
    skinBlackTitle: "⚫ 黑方棋子外觀", skinWhiteTitle: "⚪ 白方棋子外觀", skinPreviewLabel: "棋盤實際外觀預覽",
    skinGemSection: "💎 寶石預設風格", skinColorSection: "🎨 自訂專屬 3D 色彩", skinColorHint: "挑選色彩 (自動生成 3D 球體光影)",
    skinUploadSection: "📷 上傳自訂圖片 / 圖案", skinUploadBtn: "📁 上傳圖片", skinClearImg: "🗑 移除圖片", skinGlossLabel: "3D 水晶高光",
    skinReset: "🔄 還原預設外觀", skinDone: "完成設定",
    ariaClose: "關閉", ariaModes: "遊戲模式", ariaBoard: "8x8 權重黑白棋盤", ariaWhiteSeat: "白方由誰操作", ariaBlackSeat: "黑方由誰操作",
    handLabel: "抽到的棋", handNone: "—", handBag: "袋中剩 {n} 顆", handUp: "朝上 {n} 分", handEnded: "終局",
    // 動態
    cellEmpty: "{c} 空格", cellDisc: "{c} {side} {up} 分（背面 {down}）", cellLegal: "{c} 可落子，翻 {n} 顆",
    black: "黑方", white: "白方",
    sideBlack: "⚫ {bn}", sideWhite: "⚪ {wn}",
    logRoot: "開局初始局面 (#0)", logMove: "#{idx} {side} 下在 {to}：落下 +{w}，翻 {n} 顆{bonus}", logPass: "{side} 無合法位置，PASS！棋放回袋子，輪到 {enemy}",
    branchMain: "主線", branchFrom: "第 {n} 手起", branchFromDup: "第 {n} 手起 ({dup})", branchDefault: "🌿 分支 #{n}",
    reasonFull: "棋盤已填滿", reasonNoMoves: "雙方都沒有合法位置", reasonDefault: "終局結算",
    stReview: "🕘 檢視第 #{n} 步歷史局面", stEnded: "🏁 對局已結束 · {reason}",
    stPaused: "⏸ 已暫停 · {turn} · 按 [▶ 繼續] 讓 CPU 相互對戰", stPausedOne: "⏸ 已暫停 · {turn} · 按 [▶ 繼續] 讓 CPU 走",
    stCpuVsCpu: "👁 CPU 對戰中", stCpu: "🤖 CPU",
    stCpuThinking: "{actor} · {turn} · 抽到 {w} 分的棋，思考落子中…",
    stHuman: "👤 你 · {turn} · 抽到朝上 {w} 分的棋，請點選綠點落子",
    stSetup: "✏️ 自由排盤中：點擊棋盤放置、翻面或清除棋子，完成後按「排定完成」",
    stPassing: "{turn} 沒有合法位置，PASS…",
    startFromHere: "🌿 從這裡開始下", startFromHereTip: "以此盤面為起點開始下棋", restart: "🔄 再來一局", restartTip: "重新開局",
    finalWin: "🏆 {name}獲勝 +{n}", finalDraw: "🤝 平手",
    leadBlack: "{bn}超前 {n}", leadWhite: "{wn}超前 {n}", leadTie: "平手",
    vsCpu: "🤖 {name}變成 CPU", pause: "⏸ 暫停", pauseTip: "暫停 CPU [空白鍵]", resume: "▶ 繼續", resumeTip: "繼續讓 CPU 下 [空白鍵]",
    restartTitle: "重新開始新局？", restartMsg: "目前的棋局進度將重置，並重新從袋子抽出起始棋子。", restartOk: "重新開局",
    renameTip: "點一下可自訂名稱", renamePrompt: "輸入自訂名稱（留空則恢復預設）：",
    imgReadFail: "圖片讀取失敗：", customImage: "自訂圖片", customColor: "自訂色彩",
    noHistory: "尚無棋譜", manageTree: "🌳 管理對局樹…",
    // 教練
    coachEmptyEnded: "對局已結束，點擊歷史棋譜可回顧任一手。", coachEmptyNoMove: "此局面當前無任何合法位置（須 PASS）。",
    coachEmptyDefault: "點擊「💡 提示」按鈕，將為您即時分析目前局面的最佳落子位置。",
    coachThinking: "提示分析中，請稍候...", coachThinkingSub: "正在遍歷候選位置與預期搜尋樹",
    coachTitle: "💡 提示分析", coachTop: "評估首選", applyThis: "採用此步", coachOthers: "🥈 其他候選位置排行榜",
    preview: "👁 預覽", apply: "採用", rank1: "👑 首選", rank2: "🥈 次選", rank3: "🥉 備選",
    exSummary: "落在 {coord} 後，預計權重 {mine} 比 {theirs}",
    exSwing: "落下朝上 {own} 分的棋，翻 {n} 顆，立即淨賺 {gain} 分",
    exBigSteal: "其中 {n} 顆是對手那面特別大的棋，翻過來賺很多",
    exCorner: "佔據角落，永遠不會被翻回去", exEdge: "落在邊上，比較穩定",
    exMobilityCut: "壓縮對手的選擇：可下位置 {a} → {b}",
    exMobilityGive: "放寬了對手的選擇：可下位置 {a} → {b}",
    exGiveCorner: "可能讓對手有機會佔角落",
    exVolatile: "這顆棋朝上 {own} 分、背面 {other} 分，被翻回去時損失較大",
    exLoss: "立即得分為負（{n}），需靠後續局面彌補",
    // 慶祝 / 其他
    pt_trips: "三條", pt_ordered: "順子", pt_ten: "湊十", listSep: "、",
    logBonus: "　🃏 {list} +{pts}",
    fxSingle: "{name} +{pts}", fxStep: "{i}/{k}　{name} +{pts}", fxComboTotal: "Combo ×{k}　+{pts}",
    exBonus: "🃏 完成{names}，加分 +{pts}", exBonusCombo: "🃏 一次完成 {n} 組（{names}），Combo ×{n}，加分 +{pts}",
    bonusLabel: "🃏 加分模式（牌型）：", bonusOff: "無加分（標準規則）", bonusLow: "輕：湊十 2／順子 4／三條 8", bonusMid: "中：湊十 4／順子 8／三條 16", bonusHigh: "重：湊十 8／順子 16／三條 32",
    bonusHint: "直線上連續 3 顆己方的棋（含剛下的那顆）組成牌型就加分，加分當下入袋。一步完成多組 = Combo，加分 × 組數。CPU 在加分模式下改用 v7 引擎。",
    bonusRestartTitle: "換加分模式要開新局", bonusRestartMsg: "加分模式在一局之中固定，切換後會重新開局。", bonusRestartOk: "開新局",
    handMode: "🃏 {ten}/{ordered}/{trips}",
    rule5Title: "加分模式（可在設定開啟）", rule5Text: "直線上連續 3 顆己方的棋（含剛下的那顆）：三條（同數字）、順子（依序連號，如 3-4-5、6-5-4）、湊十（相加 = 10）就加分。一步完成多組 = Combo，加分 × 組數，組成的棋會依序發光。",
    variantLabel: "🎮 遊戲模式：", variantClassic: "經典（加權）：棋子兩面權重不同，比權重總和", variantFive: "加權五連：棋子顯示 7×8，連成五直接獲勝，否則比左 × 右的總和",
    variantHint: "五連類模式：棋子有左、右兩個符號（兩面相同）。同一直線上連續 5 顆己方的棋，每顆任選左或右能全部相同就直接獲勝；沒人連成五就比分數。加權五連每顆 = 左 × 右，五連每顆 1 分（雙方合計 64 分）。CPU 在這兩種模式使用 v8 引擎。",
    variantRestartTitle: "換遊戲模式要開新局", variantRestartMsg: "遊戲模式在一局之中固定，切換後會重新開局。", variantRestartOk: "開新局",
    bonusFiveOff: "（五連類模式不使用加分）",
    handFive: "{disc} = {v} 分", cellDiscFive: "{c} {side} {disc}（{v} 分）",
    stHumanFive: "👤 你 · {turn} · 抽到 {disc}，請點選綠點落子（★5 = 直接連成五）",
    stCpuThinkingFive: "{actor} · {turn} · 抽到 {disc}，思考落子中…",
    reasonFive: "{side} 連成五條 {v}，直接獲勝！", fxFive: "五條 {v}！",
    exFiveWin: "🏆 直接連成五條 {v}，獲勝！", exFiveGain: "落下 {disc} = {v} 分，翻 {n} 顆（+{f} 分）",
    exFiveForced: "引擎判斷：這步之後必勝", exFiveLost: "引擎判斷：怎麼下都難逃落敗", exFiveWinrate: "引擎估計勝率約 {p}%",
    exFiveDanger: "下完後，對手抽到合適的棋就能直接連成五",
    legendFiveNote: "E|B、G|E、E|E 都含有 E：五顆都含同一個符號就是五條。加權五連把字母換成數字（5×2），終局分數 = 左 × 右。",
    logFive: "　🏆 五條 {v}！", finalFive: "🏆 {name}連成五",
    exSummaryFive: "落在 {coord} 後，分數 {mine} 比 {theirs}",
    variantFivePlain: "五連：棋子顯示 G|H，連成五直接獲勝，否則比棋子數",
    handFivePlain: "{disc}（1 分）",
    cellDiscFivePlain: "{c} {side} {disc}",
    discWithValue: "{disc}（{v} 分）",
    exFivePlainGain: "落下 {disc}，翻 {n} 顆",
    exSummaryFivePlain: "落在 {coord} 後，棋子數 {mine} 比 {theirs}",
    rule6Title: "五連／加權五連（可在設定切換）", rule6Text: "棋子改成左、右兩個符號（兩面相同）。同一直線（橫、直、斜）上連續 5 顆己方的棋，每顆任選左或右能全部相同，就直接獲勝，翻面造成的也算。整局沒人連成五就比分數：五連每顆 1 分（顯示 G|H），加權五連每顆 = 左 × 右（顯示 7×8）。",
    p_placeholder: ""
  },
  en: {
    pageTitle: "Weighted Othello", brandName: "Weighted Othello",
    modePlay: "🎮 Play", modeRules: "📜 Rules",
    btnDice: "🎲 Who will win?", titleDice: "Switch to “Who will win?” dice Othello",
    btnTheme: "🎨 Theme & Skin", titleTheme: "Board theme and custom piece look",
    btnFlip: "🔃 Swap sides", titleFlip: "Swap the left/right position of Black and White",
    seatWhite: "⚪ White", seatBlack: "⚫ Black", seatHuman: "👤 Me", seatCpu: "🤖 CPU",
    scoreTie: "Tied", btnSettings: "⚙️ Settings", titleSettings: "Advanced game settings",
    btnTwoPlayer: "👥 Two players", titleTwoPlayer: "Both sides played by humans", btnWatch: "👁 CPU vs CPU", btnPause: "⏸ Pause",
    setupLabel: "Setup brush:", brushToggle: "🔄 Cycle", brushBlack: "⚫ Black face up", brushWhite: "⚪ White face up", brushEmpty: "🗑 Clear",
    setupFirst: "First move:", setupContinue: "✅ Done, keep playing!",
    historyTitle: "📜 Game record", branchLabel: "Main line", btnSetupMode: "✏️ Free setup", btnRestart: "🔄 Reset", titleRestart: "Start a new game",
    historyFirst: "⏮ First", historyPrev: "◀ Prev", historyNext: "▶ Next", historyLatest: "⏭ Latest",
    historyTip: "💡 Tip: click any move to review that position.",
    coachBarTitle: "🧠 AI Coach", btnHint: "💡 Hint",
    settingsTitle: "⚙️ Game settings",
    settingsHint: "💡 Who plays each side is set in the seat bar above the board. Here you only tune the CPU's thinking time and pace.",
    settingsDone: "Done",
    v6TimeLabel: "🧠 CPU thinking time per move:", time500: "0.5 s", time1000: "1 s (default)", time2000: "2 s", time4000: "4 s",
    exDepth: "Searched {d} plies, evaluation {s}", exExact: "Solved to the end: expected final margin {s}", exChanceExact: "Exact endgame over every possible draw: expected final margin {s}",
    tutorialModalTitle: "Learn Weighted Othello in 60 seconds!", tutorialOk: "Got it, let's play!",
    rule1Title: "Rule 1: every disc has a weight on each side", rule1Text: "The big number is the weight of the face-up side; the small ringed number is the back, and the ring color is the back's color. The 64 discs are exactly every combination of 1–8 × 1–8, each once.", legendNote: "Left: black up, 1 on black and 8 on white (white ring). Right: white up, 8 on white and 1 on black (black ring). Flipping swaps the two numbers.",
    rule2Title: "Rule 2: draw one disc, you choose where", rule2Text: "On your turn a random disc is drawn from the bag with your color face up. You only choose the square; as in Othello you must outflank the opponent.",
    rule3Title: "Rule 3: flanked discs flip, weights follow", rule3Text: "A flipped disc switches to its other weight. You score the number on your side; the opponent scores the other.",
    rule4Title: "Rule 4: compare total weight, not disc count", rule4Text: "At the end each side adds up the weights of its face-up discs; higher wins, equal is a draw. With no legal square you pass and the drawn disc goes back to the bag.",
    confirmTitle: "Please confirm", confirmMsg: "Are you sure you want to do this?", confirmCancel: "Cancel", confirmOk: "Confirm",
    branchModalTitle: "Game tree", branchClose: "Close",
    skinTitle: "🎨 Theme & piece workshop", skinSoundLabel: "🔊 Game sounds",
    nameLabel: "🏷️ Custom names (left: Black, right: White; blank = default):",
    skinThemeSection: "🏞️ Board theme",
    themeNeon: "Neon Deep (default)", themeClassic: "Classic Jade", themeWood: "Elegant Wood", themeSlate: "Minimal Slate",
    skinCustomHint: "Customize the black and white pieces: gem presets, a custom 3D color, or your own image.",
    skinBlackTitle: "⚫ Black piece look", skinWhiteTitle: "⚪ White piece look", skinPreviewLabel: "Live board preview",
    skinGemSection: "💎 Gem presets", skinColorSection: "🎨 Custom 3D color", skinColorHint: "Pick a color (3D sphere shading is generated)",
    skinUploadSection: "📷 Upload your own image", skinUploadBtn: "📁 Upload image", skinClearImg: "🗑 Remove image", skinGlossLabel: "3D crystal gloss",
    skinReset: "🔄 Restore defaults", skinDone: "Done",
    ariaClose: "Close", ariaModes: "Game mode", ariaBoard: "8x8 weighted Othello board", ariaWhiteSeat: "Who plays White", ariaBlackSeat: "Who plays Black",
    handLabel: "Drawn disc", handNone: "—", handBag: "{n} left in bag", handUp: "{n} pts face up", handEnded: "Game over",
    cellEmpty: "{c} empty", cellDisc: "{c} {side} {up} pts (back {down})", cellLegal: "{c} playable, flips {n}",
    black: "Black", white: "White",
    sideBlack: "⚫ {bn}", sideWhite: "⚪ {wn}",
    logRoot: "Starting position (#0)", logMove: "#{idx} {side} plays {to}: +{w}, flips {n}{bonus}", logPass: "{side} has no legal square and passes! The disc goes back to the bag; {enemy} is up",
    branchMain: "Main line", branchFrom: "From move {n}", branchFromDup: "From move {n} ({dup})", branchDefault: "🌿 Branch #{n}",
    reasonFull: "The board is full", reasonNoMoves: "Neither side has a legal square", reasonDefault: "Final result",
    stReview: "🕘 Reviewing history, move #{n}", stEnded: "🏁 Game over · {reason}",
    stPaused: "⏸ Paused · {turn} · press [▶ Resume] to let the CPUs play", stPausedOne: "⏸ Paused · {turn} · press [▶ Resume] to let the CPU move",
    stCpuVsCpu: "👁 CPU vs CPU", stCpu: "🤖 CPU",
    stCpuThinking: "{actor} · {turn} · drew a {w}-point disc, thinking…",
    stHuman: "👤 You · {turn} · drew a {w}-point disc, click a green dot to place it",
    stSetup: "✏️ Free setup: click the board to place, flip or clear discs, then press “Done”",
    stPassing: "{turn} has no legal square, passing…",
    startFromHere: "🌿 Play from here", startFromHereTip: "Start playing from this position", restart: "🔄 Play again", restartTip: "New game",
    finalWin: "🏆 {name} wins by {n}", finalDraw: "🤝 Draw",
    leadBlack: "{bn} leads by {n}", leadWhite: "{wn} leads by {n}", leadTie: "Tied",
    vsCpu: "🤖 {name} becomes CPU", pause: "⏸ Pause", pauseTip: "Pause the CPU [Space]", resume: "▶ Resume", resumeTip: "Let the CPU play [Space]",
    restartTitle: "Start a new game?", restartMsg: "The current game is reset and the starting discs are drawn again.", restartOk: "New game",
    renameTip: "Click to rename", renamePrompt: "Enter a custom name (blank restores the default):",
    imgReadFail: "Could not read image: ", customImage: "Custom image", customColor: "Custom color",
    noHistory: "No moves yet", manageTree: "🌳 Manage game tree…",
    coachEmptyEnded: "The game is over. Click a move in the record to review it.", coachEmptyNoMove: "No legal square in this position (must pass).",
    coachEmptyDefault: "Press “💡 Hint” to analyze the best squares for this position.",
    coachThinking: "Analyzing…", coachThinkingSub: "Walking through candidate squares and the expectation tree",
    coachTitle: "💡 Hint analysis", coachTop: "Top pick", applyThis: "Play this", coachOthers: "🥈 Other candidates",
    preview: "👁 Preview", apply: "Play", rank1: "👑 Best", rank2: "🥈 2nd", rank3: "🥉 3rd",
    exSummary: "After {coord}, expected weight {mine} vs {theirs}",
    exSwing: "Place a {own}-point disc and flip {n}: net +{gain} right now",
    exBigSteal: "{n} of the flipped discs have a much bigger weight on your side",
    exCorner: "Takes a corner that can never be flipped back", exEdge: "On the edge, relatively stable",
    exMobilityCut: "Squeezes the opponent: legal squares {a} → {b}",
    exMobilityGive: "Opens options for the opponent: legal squares {a} → {b}",
    exGiveCorner: "May let the opponent take a corner",
    exVolatile: "This disc is {own} face up but {other} on the back, so a flip back hurts",
    exLoss: "Immediate score is negative ({n}); it has to pay off later",
    pt_trips: "Three of a kind", pt_ordered: "Straight", pt_ten: "Make ten", listSep: ", ",
    logBonus: "  🃏 {list} +{pts}",
    fxSingle: "{name} +{pts}", fxStep: "{i}/{k}  {name} +{pts}", fxComboTotal: "Combo ×{k}  +{pts}",
    exBonus: "🃏 Completes {names}: bonus +{pts}", exBonusCombo: "🃏 Completes {n} patterns at once ({names}), Combo ×{n}: bonus +{pts}",
    bonusLabel: "🃏 Bonus mode (patterns):", bonusOff: "No bonus (standard rules)", bonusLow: "Light: ten 2 / straight 4 / three 8", bonusMid: "Medium: ten 4 / straight 8 / three 16", bonusHigh: "Heavy: ten 8 / straight 16 / three 32",
    bonusHint: "Three of your discs in a straight line (including the one just placed) can form a pattern for a bonus, banked immediately. Several patterns in one move = Combo, bonus × count. In bonus mode the CPU uses the v7 engine.",
    bonusRestartTitle: "Changing bonus mode starts a new game", bonusRestartMsg: "The bonus mode is fixed for a whole game; switching restarts it.", bonusRestartOk: "New game",
    handMode: "🃏 {ten}/{ordered}/{trips}",
    rule5Title: "Bonus mode (enable in Settings)", rule5Text: "Three of your discs in a straight line (including the one just placed): three of a kind, a straight in order (3-4-5, 6-5-4) or a sum of ten scores a bonus. Several patterns in one move = Combo, bonus × count, and each pattern lights up in turn.",
    variantLabel: "🎮 Game mode:", variantClassic: "Classic (weighted): two-sided weights, compare total weight", variantFive: "Weighted Five: discs show 7×8, five in a row wins, else compare left × right totals",
    variantHint: "Five modes: each disc has a left and a right symbol (same on both sides). Five of your discs in a straight line where each can use its left or right symbol to make them all equal wins instantly; otherwise compare scores. Weighted Five: each disc = left × right. Five: each disc = 1 (64 in total). The CPU uses the v8 engine in both.",
    variantRestartTitle: "Changing the game mode starts a new game", variantRestartMsg: "The game mode is fixed for a whole game; switching restarts it.", variantRestartOk: "New game",
    bonusFiveOff: "(No bonus in Five modes)",
    handFive: "{disc} = {v} pts", cellDiscFive: "{c} {side} {disc} ({v} pts)",
    stHumanFive: "👤 You · {turn} · drew {disc}, click a green dot (★5 = makes five)",
    stCpuThinkingFive: "{actor} · {turn} · drew {disc}, thinking…",
    reasonFive: "{side} made five {v}s and wins!", fxFive: "Five {v}s!",
    exFiveWin: "🏆 Makes five {v}s: instant win!", exFiveGain: "Places {disc} = {v} pts, flips {n} (+{f} pts)",
    exFiveForced: "Engine: a forced win after this move", exFiveLost: "Engine: every move loses", exFiveWinrate: "Engine estimates about {p}% to win",
    exFiveDanger: "Afterwards the opponent can make five with the right draw",
    legendFiveNote: "E|B, G|E and E|E all contain an E: five discs sharing one symbol make five. Weighted Five uses numbers instead (5×2) and scores left × right.",
    logFive: "  🏆 Five {v}s!", finalFive: "🏆 {name} made five",
    exSummaryFive: "After {coord}, score {mine} vs {theirs}",
    variantFivePlain: "Five: discs show G|H, five in a row wins, else compare disc count",
    handFivePlain: "{disc} (1 pt)",
    cellDiscFivePlain: "{c} {side} {disc}",
    discWithValue: "{disc} ({v} pts)",
    exFivePlainGain: "Places {disc}, flips {n}",
    exSummaryFivePlain: "After {coord}, discs {mine} vs {theirs}",
    rule6Title: "Five / Weighted Five (switch in Settings)", rule6Text: "Discs have a left and a right symbol (same on both sides). Five of your discs in a straight line (row, column or diagonal), each using its left or right symbol so all are equal, wins instantly — flips count too. If nobody makes five, compare scores: in Five each disc = 1 (shown G|H); in Weighted Five each disc = left × right (shown 7×8).",
    p_placeholder: ""
  },
  ja: {
    pageTitle: "重みつきオセロ", brandName: "重みつきオセロ",
    modePlay: "🎮 対局", modeRules: "📜 ルール",
    btnDice: "🎲 誰が勝つ？", titleDice: "「誰が勝つ？」サイコロオセロに切り替え",
    btnTheme: "🎨 テーマと外観", titleTheme: "盤テーマと石の外観を変更",
    btnFlip: "🔃 左右入替", titleFlip: "黒白の左右位置を入れ替え",
    seatWhite: "⚪ 白番", seatBlack: "⚫ 黒番", seatHuman: "👤 自分", seatCpu: "🤖 CPU",
    scoreTie: "引き分け", btnSettings: "⚙️ 設定", titleSettings: "詳細設定",
    btnTwoPlayer: "👥 二人対戦", titleTwoPlayer: "黒白とも人間が操作", btnWatch: "👁 CPU対戦", btnPause: "⏸ 一時停止",
    setupLabel: "配置ブラシ：", brushToggle: "🔄 切替", brushBlack: "⚫ 黒面を上に", brushWhite: "⚪ 白面を上に", brushEmpty: "🗑 消去",
    setupFirst: "先手：", setupContinue: "✅ 配置完了、続けて打つ！",
    historyTitle: "📜 棋譜", branchLabel: "本線", btnSetupMode: "✏️ 自由配置", btnRestart: "🔄 リセット", titleRestart: "新しい対局",
    historyFirst: "⏮ 最初", historyPrev: "◀ 前へ", historyNext: "▶ 次へ", historyLatest: "⏭ 最新",
    historyTip: "💡 ヒント：手をクリックするとその局面を振り返れます。",
    coachBarTitle: "🧠 AIコーチ", btnHint: "💡 ヒント",
    settingsTitle: "⚙️ 対局の詳細設定",
    settingsHint: "💡 各手番の操作者は盤の上の席バーで切り替えます。ここではCPUの思考時間とテンポを設定します。",
    settingsDone: "完了",
    v6TimeLabel: "🧠 CPUの1手あたりの思考時間：", time500: "0.5 秒", time1000: "1 秒（標準）", time2000: "2 秒", time4000: "4 秒",
    exDepth: "{d} 手先まで探索、評価 {s}", exExact: "終局まで読み切り：予想最終差 {s}", exChanceExact: "全ての引き方を含む終盤完全読み：予想最終差 {s}",
    tutorialModalTitle: "60秒で覚える重みつきオセロ！", tutorialOk: "分かった、始めよう！",
    rule1Title: "ルール1：石の両面に重みがある", rule1Text: "大きい数字が表面の重み、右下の丸で囲んだ小さい数字が裏面の重みで、丸の色が裏面の色です。64枚は 1～8 × 1～8 の全組み合わせを1枚ずつ。", legendNote: "左：黒面が上、黒1点・白8点（白い丸）。右：白面が上、白8点・黒1点（黒い丸）。裏返すと2つの数字が入れ替わります。",
    rule2Title: "ルール2：1枚引いて、置く場所を選ぶ", rule2Text: "手番では袋からランダムに1枚引き、自分の色が上になります。選べるのは置く場所だけ。オセロと同じく相手を挟む必要があります。",
    rule3Title: "ルール3：挟むと裏返り、重みも入れ替わる", rule3Text: "裏返った石は反対面の重みになります。自分は自分側の数字、相手は反対側の数字を得ます。",
    rule4Title: "ルール4：枚数でなく重みの合計", rule4Text: "終局時に各色が上の石の重みを合計し、多い方が勝ち、同点は引き分け。打てる場所がなければパス、引いた石は袋に戻ります。",
    confirmTitle: "操作の確認", confirmMsg: "この操作を実行してよろしいですか？", confirmCancel: "キャンセル", confirmOk: "確認",
    branchModalTitle: "対局ツリー", branchClose: "閉じる",
    skinTitle: "🎨 テーマ・石外観ワークショップ", skinSoundLabel: "🔊 効果音",
    nameLabel: "🏷️ 名前のカスタム（左：黒番　右：白番、空欄でデフォルト）：",
    skinThemeSection: "🏞️ ボードテーマ",
    themeNeon: "ネオンディープ（デフォルト）", themeClassic: "クラシックジェイド", themeWood: "エレガントウッド", themeSlate: "ミニマルスレート",
    skinCustomHint: "黒石・白石の外観を自由にカスタマイズ！宝石プリセット、カスタム3Dカラー、または画像アップロードが選べます。",
    skinBlackTitle: "⚫ 黒石の外観", skinWhiteTitle: "⚪ 白石の外観", skinPreviewLabel: "ライブボードプレビュー",
    skinGemSection: "💎 宝石プリセット", skinColorSection: "🎨 カスタム3Dカラー", skinColorHint: "色を選択（3Dボール光影を自動生成）",
    skinUploadSection: "📷 カスタム画像をアップロード", skinUploadBtn: "📁 画像をアップロード", skinClearImg: "🗑 画像を削除", skinGlossLabel: "3Dクリスタルグロス",
    skinReset: "🔄 デフォルトに戻す", skinDone: "完了",
    ariaClose: "閉じる", ariaModes: "ゲームモード", ariaBoard: "8x8 重みつきオセロ盤", ariaWhiteSeat: "白番の操作者", ariaBlackSeat: "黒番の操作者",
    handLabel: "引いた石", handNone: "—", handBag: "袋に残り {n} 枚", handUp: "表 {n} 点", handEnded: "終局",
    cellEmpty: "{c} 空き", cellDisc: "{c} {side} {up}点（裏 {down}）", cellLegal: "{c} 着手可、{n}枚返る",
    black: "黒番", white: "白番",
    sideBlack: "⚫ {bn}", sideWhite: "⚪ {wn}",
    logRoot: "開始局面 (#0)", logMove: "#{idx} {side} {to}：+{w}、{n}枚返す{bonus}", logPass: "{side} 打てる場所なし、パス！石は袋へ戻り {enemy} の番",
    branchMain: "本線", branchFrom: "{n}手目から", branchFromDup: "{n}手目から ({dup})", branchDefault: "🌿 分岐 #{n}",
    reasonFull: "盤面が埋まりました", reasonNoMoves: "双方とも打てる場所がありません", reasonDefault: "終局結果",
    stReview: "🕘 履歴を確認中 #{n} 手目", stEnded: "🏁 対局終了 · {reason}",
    stPaused: "⏸ 一時停止中 · {turn} · [▶ 再開] でCPU同士が対戦", stPausedOne: "⏸ 一時停止中 · {turn} · [▶ 再開] でCPUが打ちます",
    stCpuVsCpu: "👁 CPU対戦中", stCpu: "🤖 CPU",
    stCpuThinking: "{actor} · {turn} · {w}点の石を引いて、思考中…",
    stHuman: "👤 あなた · {turn} · {w}点の石を引きました。緑の点をクリックして置く",
    stSetup: "✏️ 自由配置中：盤をクリックして置く・返す・消す。終わったら「配置完了」を押す",
    stPassing: "{turn} は打てる場所がなくパス…",
    startFromHere: "🌿 ここから打つ", startFromHereTip: "この局面から対局を始める", restart: "🔄 もう一局", restartTip: "新しい対局",
    finalWin: "🏆 {name}の勝ち +{n}", finalDraw: "🤝 引き分け",
    leadBlack: "{bn}が {n} リード", leadWhite: "{wn}が {n} リード", leadTie: "引き分け",
    vsCpu: "🤖 {name}をCPUに", pause: "⏸ 一時停止", pauseTip: "CPUを一時停止 [スペース]", resume: "▶ 再開", resumeTip: "CPUを再開 [スペース]",
    restartTitle: "新しい対局を始めますか？", restartMsg: "現在の対局はリセットされ、開始の石を引き直します。", restartOk: "新しい対局",
    renameTip: "クリックで名前を変更", renamePrompt: "名前を入力（空欄でデフォルト）：",
    imgReadFail: "画像の読み込みに失敗：", customImage: "カスタム画像", customColor: "カスタムカラー",
    noHistory: "まだ手がありません", manageTree: "🌳 対局ツリーを管理…",
    coachEmptyEnded: "対局は終了しました。棋譜の手をクリックして振り返れます。", coachEmptyNoMove: "この局面には打てる場所がありません（パス）。",
    coachEmptyDefault: "「💡 ヒント」を押すと、この局面の最善手を分析します。",
    coachThinking: "分析中…", coachThinkingSub: "候補手と期待値探索木をたどっています",
    coachTitle: "💡 ヒント分析", coachTop: "最有力", applyThis: "この手を打つ", coachOthers: "🥈 その他の候補",
    preview: "👁 プレビュー", apply: "採用", rank1: "👑 最善", rank2: "🥈 次善", rank3: "🥉 三番手",
    exSummary: "{coord} に置くと、予想の重みは {mine} 対 {theirs}",
    exSwing: "{own}点の石を置き {n}枚返す：その場で +{gain}",
    exBigSteal: "返す石のうち {n}枚は自分側の重みがかなり大きい",
    exCorner: "角を取る。二度と返されない", exEdge: "辺に置くので比較的安定",
    exMobilityCut: "相手の選択肢を減らす：着手数 {a} → {b}",
    exMobilityGive: "相手の選択肢を増やす：着手数 {a} → {b}",
    exGiveCorner: "相手に角を取られるおそれ",
    exVolatile: "この石は表 {own} 点・裏 {other} 点で、返されると損失が大きい",
    exLoss: "その場の得点がマイナス（{n}）。後で取り返す必要あり",
    pt_trips: "スリーカード", pt_ordered: "ストレート", pt_ten: "テン", listSep: "・",
    logBonus: "　🃏 {list} +{pts}",
    fxSingle: "{name} +{pts}", fxStep: "{i}/{k}　{name} +{pts}", fxComboTotal: "Combo ×{k}　+{pts}",
    exBonus: "🃏 {names}が完成、ボーナス +{pts}", exBonusCombo: "🃏 一度に {n} 組完成（{names}）、Combo ×{n}、ボーナス +{pts}",
    bonusLabel: "🃏 ボーナスモード（役）：", bonusOff: "ボーナスなし（標準ルール）", bonusLow: "軽：テン 2／ストレート 4／スリーカード 8", bonusMid: "中：テン 4／ストレート 8／スリーカード 16", bonusHigh: "重：テン 8／ストレート 16／スリーカード 32",
    bonusHint: "一直線に並んだ自分の石 3 つ（置いたばかりの石を含む）で役ができるとボーナス、即座に確定。一手で複数の役 = Combo、ボーナス × 組数。ボーナスモードでは CPU は v7 エンジンを使います。",
    bonusRestartTitle: "ボーナスモードの変更は新しい対局になります", bonusRestartMsg: "ボーナスモードは対局中は固定です。切り替えると対局をやり直します。", bonusRestartOk: "新しい対局",
    handMode: "🃏 {ten}/{ordered}/{trips}",
    rule5Title: "ボーナスモード（設定で有効化）", rule5Text: "一直線に並んだ自分の石 3 つ（置いたばかりの石を含む）：スリーカード（同じ数字）、ストレート（順番に連番、3-4-5・6-5-4）、テン（合計 10）でボーナス。一手で複数の役 = Combo、ボーナス × 組数、役の石が順番に光ります。",
    variantLabel: "🎮 ゲームモード：", variantClassic: "クラシック（加重）：表裏で重みが違い、重みの合計を比べる", variantFive: "加重五連：石は 7×8 表示、五連で即勝利、なければ左 × 右の合計を比べる",
    variantHint: "五連系モード：石には左右 2 つの記号（表裏同じ）。一直線に並んだ自分の石 5 つで、各石の左か右を選んで全部同じにできれば即勝利。誰もできなければ得点比べ：加重五連は石 1 つ = 左 × 右、五連は石 1 つ = 1 点（合計 64 点）。どちらも CPU は v8 エンジンを使います。",
    variantRestartTitle: "ゲームモードの変更は新しい対局になります", variantRestartMsg: "ゲームモードは対局中は固定です。切り替えると対局をやり直します。", variantRestartOk: "新しい対局",
    bonusFiveOff: "（五連系モードではボーナスなし）",
    handFive: "{disc} = {v} 点", cellDiscFive: "{c} {side} {disc}（{v} 点）",
    stHumanFive: "👤 あなた · {turn} · {disc} を引きました。緑の点をクリック（★5 = 五連完成）",
    stCpuThinkingFive: "{actor} · {turn} · {disc} を引いて、思考中…",
    reasonFive: "{side} が {v} の五連を完成、即勝利！", fxFive: "{v} の五連！",
    exFiveWin: "🏆 {v} の五連が完成、即勝利！", exFiveGain: "{disc} = {v} 点を置き、{n} 枚返す（+{f} 点）",
    exFiveForced: "エンジン判定：この手の後は必勝", exFiveLost: "エンジン判定：どう打っても負け", exFiveWinrate: "エンジンの推定勝率 約 {p}%",
    exFiveDanger: "この後、相手は合う石を引けば五連を完成できる",
    legendFiveNote: "E|B・G|E・E|E はどれも E を含む：五つが同じ記号を持てば五連。加重五連は文字の代わりに数字（5×2）で、得点 = 左 × 右。",
    logFive: "　🏆 {v} の五連！", finalFive: "🏆 {name}が五連",
    exSummaryFive: "{coord} に置くと、得点 {mine} 対 {theirs}",
    variantFivePlain: "五連：石は G|H 表示、五連で即勝利、なければ石の数を比べる",
    handFivePlain: "{disc}（1 点）",
    cellDiscFivePlain: "{c} {side} {disc}",
    discWithValue: "{disc}（{v} 点）",
    exFivePlainGain: "{disc} を置き、{n} 枚返す",
    exSummaryFivePlain: "{coord} に置くと、石の数 {mine} 対 {theirs}",
    rule6Title: "五連／加重五連（設定で切り替え）", rule6Text: "石に左右 2 つの記号（表裏同じ）。一直線（横・縦・斜め）に並んだ自分の石 5 つで、各石の左か右を選んで全部同じにできれば即勝利、返して並んだ場合も含む。誰もできなければ得点比べ：五連は石 1 つ = 1 点（G|H 表示）、加重五連は石 1 つ = 左 × 右（7×8 表示）。",
    p_placeholder: ""
  }
};

export function clampName(s) {
  return typeof window !== "undefined" && window.takuClampName
    ? window.takuClampName(s)
    : String(s || "").replace(/[<>&"']/g, "").slice(0, 10);
}

export function curLang() {
  return (typeof window !== "undefined" && window.currentLang) || "zh";
}

export function tr(key, params = {}) {
  const dict = D[curLang()] || D.zh;
  const has = dict[key] != null || D.zh[key] != null;
  if (!has) return baseTr(key, params); // 共用字串（外觀預設名稱等）
  const names = (typeof window !== "undefined" && window.takuNames) || {};
  const bn = clampName(names.black) || (dict.black), wn = clampName(names.white) || (dict.white);
  if (key === "black") return bn;
  if (key === "white") return wn;
  let s = dict[key] != null ? dict[key] : D.zh[key];
  const all = { bn, wn, ...params };
  for (const k in all) s = s.split(`{${k}}`).join(all[k]);
  return s;
}

/** 字串原樣回傳；{k, p} 結構化訊息依目前語言翻譯（p 內的 { k, p } 會遞迴翻譯，陣列會翻譯後串接） */
export function tx(v) {
  if (v == null) return "";
  if (typeof v === "string") return v;
  const p = {};
  for (const k in (v.p || {})) {
    const x = v.p[k];
    if (Array.isArray(x)) p[k] = x.map(tx).join(tr("listSep")); // 清單（例如多組牌型）
    else p[k] = x && typeof x === "object" ? tx(x) : (x == null ? "" : x);
  }
  return tr(v.k, p);
}

export const msg = (k, p) => ({ k, p });

/** 把文字裡的 ⚫ ⚪ 換成使用者自訂外觀的小棋子（輸入須是已可安全放進 HTML 的文字） */
export function pieceify(html) {
  return String(html)
    .replace(/⚫/g, '<span class="pieceDot black"></span>')
    .replace(/⚪/g, '<span class="pieceDot white"></span>');
}

export const escapeHtml = (s) => String(s).replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;");

// ===== 靜態 HTML 翻譯與語言切換 =====

/** 顯示寬度上限 20（英數 1、中日韓 2），並濾掉 HTML 特殊字元 */
function clampWidth(s, max = 20) {
  let out = "", w = 0;
  for (const ch of String(s || "").replace(/[<>&"']/g, "")) {
    const cp = ch.codePointAt(0);
    const cw = (cp >= 0x1100 && cp <= 0x115F) || (cp >= 0x2E80 && cp <= 0xA4CF) || (cp >= 0xAC00 && cp <= 0xD7A3) ||
      (cp >= 0xF900 && cp <= 0xFAFF) || (cp >= 0xFE30 && cp <= 0xFE6F) || (cp >= 0xFF00 && cp <= 0xFF60) ||
      (cp >= 0xFFE0 && cp <= 0xFFE6) || cp >= 0x1F300 ? 2 : 1;
    if (w + cw > max) break;
    out += ch; w += cw;
  }
  return out;
}

const SIDE_KEYS = { seatWhite: "white", seatBlack: "black" };
const SIDE_WORDS = { zh: { black: ["黑方"], white: ["白方"] }, en: { black: ["Black"], white: ["White"] }, ja: { black: ["黒番"], white: ["白番"] } };

/** 靜態文字專用：支援自訂名稱與 ⚫⚪ 轉棋子圖示 */
export function t(key) {
  const lang = curLang();
  let s = (D[lang] || D.zh)[key] != null ? (D[lang] || D.zh)[key] : (D.zh[key] != null ? D.zh[key] : key);
  const side = SIDE_KEYS[key];
  const custom = side && window.takuNames && window.takuNames[side];
  if (custom) {
    const w = (SIDE_WORDS[lang] || SIDE_WORDS.zh)[side].find(x => s.includes(x));
    if (w) s = s.replace(w, custom.replace(/</g, "&lt;"));
  }
  if (key === "seatBlack" || key === "seatWhite") {
    s = s.replace(/^[⚫⚪]\s*/, '<span class="pieceDot ' + (key === "seatBlack" ? "black" : "white") + '"></span>');
  }
  return s;
}

export function applyI18n() {
  document.querySelectorAll("[data-i18n]").forEach(el => { el.innerHTML = t(el.dataset.i18n); });
  document.querySelectorAll("[data-i18n-title]").forEach(el => { el.title = t(el.dataset.i18nTitle); });
  document.querySelectorAll(".modalCloseBtn").forEach(el => el.setAttribute("aria-label", t("ariaClose")));
  const setAria = (sel, key) => { const el = document.querySelector(sel); if (el) el.setAttribute("aria-label", t(key)); };
  setAria(".modeTabs", "ariaModes");
  setAria("#boardContainer", "ariaBoard");
  document.querySelectorAll(".seatToggle").forEach((el, i) => el.setAttribute("aria-label", t(i === 0 ? "ariaWhiteSeat" : "ariaBlackSeat")));
  document.title = t("pageTitle");
  const lang = curLang();
  document.documentElement.lang = lang === "ja" ? "ja" : (lang === "en" ? "en" : "zh-Hant");
  document.querySelectorAll(".langBtn").forEach(btn => btn.classList.toggle("active", btn.dataset.lang === lang));
}

export function setLang(lang) {
  window.currentLang = lang;
  try { localStorage.setItem("takuLang", lang); } catch (e) {}
  applyI18n();
  window.dispatchEvent(new Event("langchange"));
}

/** 初始化：語言偏好與自訂名稱需要在第一次渲染前就備妥 */
export function initI18n(savedNames = {}) {
  window.takuClampName = clampWidth;
  window.takuNames = { black: clampWidth(savedNames.black), white: clampWidth(savedNames.white) };
  let lang = "zh";
  try { lang = localStorage.getItem("takuLang") || "zh"; } catch (e) {}
  window.currentLang = D[lang] ? lang : "zh";
  window.t = t;
  window.setLang = setLang;
  window.applyI18n = applyI18n;
}

export const DICTIONARY = D;
