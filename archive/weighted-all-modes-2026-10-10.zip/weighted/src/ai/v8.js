/**
 * v8（五連模式）：v6 的黑白棋搜尋 + 五子棋的成五／威脅判斷。細節見 ./v8/search.js。
 */
import { remainingBag } from "../core/rules.js";
import { searchRootV8, V8_PARAMS } from "./v8/search.js";
import { V6_DEFAULT_TIME } from "./v6.js";

export function searchV8(board, player, handId, { timeMs = V6_DEFAULT_TIME, multiPV = false, maxDepth, params = V8_PARAMS } = {}) {
  return searchRootV8({ board, player, handId, bag: remainingBag(board, handId), timeMs, multiPV, maxDepth, params });
}
