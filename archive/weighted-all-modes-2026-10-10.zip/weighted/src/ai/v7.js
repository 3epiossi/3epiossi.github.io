/**
 * v7（加分模式）：v6 的搜尋再加上牌型加分。細節見 ./v7/search.js。
 */
import { remainingBag } from "../core/rules.js";
import { searchRootV7 } from "./v7/search.js";
import { V6_DEFAULT_TIME } from "./v6.js";

/**
 * @param {{ten:number, ordered:number, trips:number}} bonusPoints 該局的加分表
 */
export function searchV7(board, player, handId, bonusPoints, { timeMs = V6_DEFAULT_TIME, multiPV = false, maxDepth, params } = {}) {
  return searchRootV7({
    board, player, handId, bonusPoints,
    bag: remainingBag(board, handId),
    timeMs, multiPV, maxDepth,
    ...(params ? { params } : {})
  });
}
