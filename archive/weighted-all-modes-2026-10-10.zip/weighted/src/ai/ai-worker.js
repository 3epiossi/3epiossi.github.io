/**
 * 🧵 搜尋專用的 Web Worker（v6 / v7）：深度搜尋要花一秒左右，放在背景執行緒才不會卡住畫面。
 * 只回傳格子與分數；翻面資訊與教練說明（需要語系）由主執行緒補上。
 */
import { searchV6 } from "./v6.js";
import { searchV7 } from "./v7.js";
import { searchV8 } from "./v8.js";
import { V8_PARAMS, V8_PLAIN_PARAMS } from "./v8/search.js";

self.onmessage = (e) => {
  const { id, board, player, hand, timeMs, multiPV, bonusPoints, variant } = e.data;
  let result = null;
  try {
    const r = variant === "five" || variant === "fivePlain"
      ? searchV8(board, player, hand, { timeMs, multiPV, params: variant === "fivePlain" ? V8_PLAIN_PARAMS : V8_PARAMS })
      : bonusPoints
        ? searchV7(board, player, hand, bonusPoints, { timeMs, multiPV })
        : searchV6(board, player, hand, { timeMs, multiPV });
    if (r) result = { bestSq: r.bestSq, scores: r.scores, depth: r.depth, exact: r.exact, chanceExact: !!r.chanceExact };
  } catch (err) {
    console.error("v6 worker error:", err);
  }
  self.postMessage({ id, result });
};
