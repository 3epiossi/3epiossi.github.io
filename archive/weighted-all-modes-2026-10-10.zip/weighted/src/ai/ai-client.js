/**
 * 🧠 主執行緒呼叫搜尋引擎（v6 / v7）的介面：優先用 Web Worker，不支援時退回同步計算。
 */
import { searchEngine } from "./ai-service.js";

export class AiClient {
  constructor() {
    this.seq = 0;
    this.pending = new Map();
    try {
      this.worker = new Worker(new URL("./ai-worker.js", import.meta.url), { type: "module" });
      this.worker.onmessage = (e) => {
        const cb = this.pending.get(e.data.id);
        if (!cb) return;
        this.pending.delete(e.data.id);
        cb(e.data.result);
      };
      this.worker.onerror = (e) => {
        console.warn("v6 worker 無法使用，改為同步計算", e);
        this.worker = null;
        for (const [, cb] of this.pending) cb(undefined);
        this.pending.clear();
      };
    } catch (e) {
      this.worker = null;
    }
  }

  /**
   * @returns {Promise<{bestSq:number, scores:{sq:number,score:number}[], depth:number, exact:boolean} | null>}
   */
  search({ board, player, hand, timeMs, multiPV = false, bonusPoints = null, variant = "classic" }) {
    const syncRun = () => {
      const r = searchEngine(board, player, hand, { timeMs, multiPV, bonusPoints, variant });
      return r ? { bestSq: r.bestSq, scores: r.scores, depth: r.depth, exact: r.exact, chanceExact: !!r.chanceExact } : null;
    };
    if (!this.worker) return new Promise((resolve) => setTimeout(() => resolve(syncRun()), 0));
    const id = ++this.seq;
    return new Promise((resolve) => {
      this.pending.set(id, (result) => resolve(result === undefined ? syncRun() : result));
      this.worker.postMessage({ id, board, player, hand, timeMs, multiPV, bonusPoints, variant });
    });
  }
}
