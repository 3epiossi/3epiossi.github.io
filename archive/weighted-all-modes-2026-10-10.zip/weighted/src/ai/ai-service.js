/**
 * 🧠 權重黑白棋 - AI 服務層：選步、候選排行與教練說明
 * 標準模式由 v6 搜尋，加分模式（有加分表）由 v7 搜尋；這裡把結果轉成遊戲走步，並為教練產生說明。
 */

import { BLACK } from "../core/constants.js";
import { blackWeight, whiteWeight, posToCoord, applyMoveToBoard } from "../core/rules.js";
import { findPatterns, bonusOfPatterns } from "../core/bonus.js";
import { tr } from "../i18n.js";
import {
  toSearchBoard, legalMovesSb, applyMoveSb, immediateGain, scoreOf, countMoves, other
} from "./search-board.js";
import { searchV6, V6_DEFAULT_TIME } from "./v6.js";
import { searchV7 } from "./v7.js";
import { searchV8 } from "./v8.js";
import { findFive, fiveScores, valueOf, symbolOf, discLabel } from "../core/five-rules.js";
import { V8_PARAMS, V8_PLAIN_PARAMS } from "./v8/search.js";

/** 五連模式用 v8；經典模式有加分表用 v7，否則用 v6 */
export function searchEngine(board, player, handId, { bonusPoints = null, variant = "classic", ...opts } = {}) {
  if (variant === "five") return searchV8(board, player, handId, { params: V8_PARAMS, ...opts });
  if (variant === "fivePlain") return searchV8(board, player, handId, { ...opts, params: V8_PLAIN_PARAMS });
  return bonusPoints ? searchV7(board, player, handId, bonusPoints, opts) : searchV6(board, player, handId, opts);
}

const CORNER_IDX = new Set([0, 7, 56, 63]);
const N = 8;

const toGameMove = (sb, item, player) => ({
  r: item.sbMove.r,
  c: item.sbMove.c,
  player,
  flips: item.sbMove.flips.map(j => [Math.floor(j / N), j % N])
});

/** 引擎結果（格子 + 分數）轉成帶翻面資訊的候選清單，已由高到低排序 */
function toRanked(board, player, scores) {
  const sb = toSearchBoard(board);
  const bySq = new Map(legalMovesSb(sb, player).map(m => [m.r * N + m.c, m]));
  const ranked = scores.filter(x => bySq.has(x.sq)).map(x => ({ sbMove: bySq.get(x.sq), score: x.score }));
  return { sb, ranked };
}

/**
 * 選出最佳走步（同步版，測試與評測用；網頁用 AiClient 在 Worker 裡算）
 * @returns {{ chosen: object|null, maxScore: number, info?: object }}
 */
export function findBestMoveForCPU(board, player, handId, { timeMs = V6_DEFAULT_TIME, maxDepth, params, bonusPoints = null, variant = "classic" } = {}) {
  const res = searchEngine(board, player, handId, { timeMs, maxDepth, params, bonusPoints, variant });
  if (!res) return { chosen: null, maxScore: -Infinity };
  const { sb, ranked } = toRanked(board, player, res.scores);
  return { chosen: toGameMove(sb, ranked[0], player), maxScore: ranked[0].score, info: res };
}

/** 教練說明：從幾個看得懂的面向講這一步好在哪、要注意什麼；bonus = 這步完成的牌型（加分模式） */
export function generateMoveExplanation(sb, item, placed, player, bonus = null) {
  const m = item.sbMove;
  const pros = [], cons = [];
  const idx = m.r * N + m.c;
  const own = player === BLACK ? placed.b : placed.w;
  const swing = immediateGain(sb, m, placed, player);
  const after = applyMoveSb(sb, m, placed, player);
  const foe = other(player);

  pros.push(tr("exSwing", { own, n: m.flips.length, gain: Math.round(swing * 10) / 10 }));
  if (bonus && bonus.points > 0) {
    const names = bonus.patterns.map(p => tr("pt_" + p.type)).join(tr("listSep"));
    pros.push(bonus.patterns.length > 1
      ? tr("exBonusCombo", { names, n: bonus.patterns.length, pts: bonus.points })
      : tr("exBonus", { names, pts: bonus.points }));
  }

  // 翻到的棋裡，對手那面特別大的，是真正的大賺
  let bigSteal = 0;
  for (const j of m.flips) {
    const theirs = player === BLACK ? sb.w[j] : sb.b[j];
    const mine = player === BLACK ? sb.b[j] : sb.w[j];
    if (theirs - mine >= 4) bigSteal++;
  }
  if (bigSteal > 0) pros.push(tr("exBigSteal", { n: bigSteal }));

  if (CORNER_IDX.has(idx)) pros.push(tr("exCorner"));
  else if (m.r === 0 || m.r === N - 1 || m.c === 0 || m.c === N - 1) pros.push(tr("exEdge"));

  const foeBefore = countMoves(sb, foe), foeAfter = countMoves(after, foe);
  if (foeAfter < foeBefore) pros.push(tr("exMobilityCut", { a: foeBefore, b: foeAfter }));
  else if (foeAfter > foeBefore + 2) cons.push(tr("exMobilityGive", { a: foeBefore, b: foeAfter }));

  // 把對手的角落打開了嗎？
  const foeMoves = legalMovesSb(after, foe);
  for (const corner of CORNER_IDX) {
    if (sb.f[corner] === 0 && foeMoves.some(x => x.r * N + x.c === corner)) { cons.push(tr("exGiveCorner")); break; }
  }

  // 這顆棋之後被翻回去會虧多少
  const hisFace = player === BLACK ? placed.w : placed.b;
  if (hisFace - own >= 4) cons.push(tr("exVolatile", { own, other: hisFace }));
  if (swing < 0) cons.push(tr("exLoss", { n: Math.round(-swing * 10) / 10 }));

  const { mine, theirs } = scoreOf(after, player);
  const summary = tr("exSummary", { coord: posToCoord(m.r, m.c), mine, theirs });
  return { summary, pros, cons };
}

/**
 * 引擎只回傳 [{sq, score}]（Worker 不碰語系）。主執行緒用這個補上翻面資訊與教練說明。
 * @returns {{ move: object, score: number, explanation: object }[]} 前 topN 名
 */
export function explainScoredSquares(board, player, handId, scores, topN = 3, bonusPoints = null) {
  const { sb, ranked } = toRanked(board, player, scores);
  const placed = { b: blackWeight(handId), w: whiteWeight(handId) };
  return ranked.slice(0, topN).map(item => {
    const move = toGameMove(sb, item, player);
    const bonus = bonusPoints ? bonusForMove(board, move, handId, player, bonusPoints) : null;
    return { move, score: item.score, bonus, explanation: generateMoveExplanation(sb, item, placed, player, bonus) };
  });
}

/** 把 handId 下在 move 會完成哪些牌型、得幾分 */
export function bonusForMove(board, move, handId, player, bonusPoints) {
  const nb = applyMoveToBoard(board, move, handId, player);
  const patterns = findPatterns(nb, move.r, move.c, player);
  return { patterns, points: bonusOfPatterns(patterns, bonusPoints) };
}

/** 同步版教練（測試用）：每個位置都要精確分數，較慢 */
export function rankCandidateMoves(board, player, handId, topN = 3, { timeMs = V6_DEFAULT_TIME, bonusPoints = null } = {}) {
  const res = searchEngine(board, player, handId, { timeMs, multiPV: true, bonusPoints });
  if (!res) return [];
  return explainScoredSquares(board, player, handId, res.scores, topN, bonusPoints);
}

/**
 * 五連模式的教練說明（v8 的分數是勝率尺度 [-1, 1]）
 * @returns {{ move, score, five, explanation }[]} 前 topN 名
 */
export function explainFiveSquares(board, player, handId, scores, topN = 3, plain = false) {
  const { sb, ranked } = toRanked(board, player, scores);
  const foe = player === BLACK ? 2 : BLACK;
  return ranked.slice(0, topN).map(item => {
    const move = toGameMove(sb, item, player);
    const nb = applyMoveToBoard(board, move, handId, player);
    const five = findFive(nb, player);
    const sc = fiveScores(nb, !plain);
    const mine = player === BLACK ? sc.black : sc.white, theirs = player === BLACK ? sc.white : sc.black;
    let flipVal = 0;
    for (const [r, c] of move.flips) flipVal += valueOf(board[r][c].id);
    const pros = [], cons = [];
    if (five) pros.push(tr("exFiveWin", { v: symbolOf(five.value, plain) }));
    pros.push(plain
      ? tr("exFivePlainGain", { disc: discLabel(handId, true), n: move.flips.length })
      : tr("exFiveGain", { disc: discLabel(handId, false), v: valueOf(handId), n: move.flips.length, f: flipVal }));
    if (!five) {
      const s = item.score;
      if (s >= 0.999) pros.push(tr("exFiveForced"));
      else if (s <= -0.999) cons.push(tr("exFiveLost"));
      else pros.push(tr("exFiveWinrate", { p: Math.round((s + 1) * 50) }));
    }
    // 對手下一手是否有機會直接連成五（不管抽到什麼棋）
    if (!five && opponentCanFive(nb, foe)) cons.push(tr("exFiveDanger"));
    const summary = tr(plain ? "exSummaryFivePlain" : "exSummaryFive", { coord: posToCoord(move.r, move.c), mine, theirs });
    return { move, score: item.score, five, explanation: { summary, pros, cons } };
  });
}

/** 對手下一手有沒有任何「抽到合適的棋就能連成五」的位置（只看盤上已有的棋） */
function opponentCanFive(board, foe) {
  const sb = toSearchBoard(board);
  for (const m of legalMovesSb(sb, foe)) {
    // 只要試 8 顆左右同號的棋（v|v）：含 v 的棋能補成五，v|v 一定也能
    for (let v = 0; v < 8; v++) {
      const nb = applyMoveToBoard(board, { r: m.r, c: m.c, flips: m.flips.map(j => [Math.floor(j / N), j % N]) }, v * 8 + v, foe);
      if (findFive(nb, foe)) return true;
    }
  }
  return false;
}

/** Worker 回傳的最佳格轉成遊戲走步 */
export function moveFromSquare(board, player, sq) {
  const sb = toSearchBoard(board);
  const m = legalMovesSb(sb, player).find(x => x.r * N + x.c === sq);
  return m ? toGameMove(sb, { sbMove: m }, player) : null;
}
