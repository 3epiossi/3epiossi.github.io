/**
 * 🃏 v7 搜尋引擎：v6 + 加分模式（牌型）
 *
 * 搜尋架構與 v6 相同（位元棋盤、迭代加深 NegaScout、置換表、Multi-ProbCut、終盤精確期望值），
 * 共用 v6 的位元棋盤、評估函數、雜湊、置換表與 MPC 統計表；差別只在「落子當下的牌型加分」：
 *
 * - 加分當下入袋，所以「這一步的價值 = 這一步的加分 − 對手接下來的最佳結果」，直接放進 negamax，
 *   子節點的搜尋視窗扣掉這一步的加分即可。
 * - 根節點手上那顆棋已知 → 精確加分；搜尋中以平均棋代入的落子 → 依袋中 1～8 的分布取期望加分。
 *   三連中其他格若是平均棋（數字未知），這個三連不計（近似）。
 * - 終盤剩 EXACT_EMPTIES 格以內逐一展開抽棋，加分也精確計算。
 * - 評估值的刻度不等於終局分差（中盤約被壓縮 3 倍，見 tests/eval-scale.js），
 *   加分換算成評估值時，中盤乘上 bonusWeight，終盤逐步升到 1（bonusScale）。
 *
 * 驗證與調參：tests/bonus-duel.js（v7 對 v6；固定深度的結果才可靠，限時對戰雜訊很大）。
 */

import { RH, RL, mobility, flips, setBit, count, squaresOf } from "../v6/bitboard.js";
import { evaluate, finalDiff, PARAMS } from "../v6/eval.js";
import {
  EXACT_EMPTIES, Z1, Z2, H1, H2, SIDE1, SIDE2,
  TT_MASK, TT_K2, TT_DEPTH, TT_FLAG, TT_SCORE, TT_MOVE, EXACT, LOWER, UPPER,
  SQ_ORDER, MPC_SHALLOW, MPC_STATS, MPC_MIN_PLY,
  blackWeight, whiteWeight, keyAfter, insertionSort
} from "../v6/search.js";

const BLACK = 1, WHITE = 2;

export const V7_PARAMS = {
  ...PARAMS,
  bonusWeight: 0.15   // 中盤加分換算成評估值的係數（tests/bonus-duel.js，固定深度 100 局調得）
};

// ===== 搜尋狀態 =====
const FB = new Float64Array(64);    // 每格黑面權重
const FW = new Float64Array(64);    // 每格白面權重
const KNOWN = new Uint8Array(64);   // 這格的棋數字是否已知（搜尋中以平均棋代入的為 0）
const PB = new Float64Array(9), PW = new Float64Array(9);   // 袋中黑面 / 白面數字 1～8 的分布
let avgB = 4.5, avgW = 4.5;
let POINTS = { ten: 2, ordered: 4, trips: 8 };
let deadline = Infinity;
let nodes = 0;
let params = V7_PARAMS;
let inMpc = false;
const ABORT = { abort: true };
const MAX_PLY = 70;
const MOVES = Array.from({ length: MAX_PLY }, () => new Int8Array(32));
const KEYS = Array.from({ length: MAX_PLY }, () => new Float64Array(32));
const BONS = Array.from({ length: MAX_PLY }, () => new Float64Array(64)); // 排序時算好的每格加分，下棋時重用
const NULL_EPS = 0.01;
const sqBuf = [];

// ===== 牌型加分 =====

// 每一格所屬的直線三連：WIN[s] 依序存 (q0, q1, q2, 這一格的位置) 四個數字一組
const WIN = [];
{
  const AX = [[0, 1], [1, 0], [1, 1], [1, -1]];
  const lists = Array.from({ length: 64 }, () => []);
  for (let r = 0; r < 8; r++) for (let c = 0; c < 8; c++) {
    for (const [dr, dc] of AX) {
      const cells = [0, 1, 2].map(k => [r + k * dr, c + k * dc]);
      if (cells.some(([y, x]) => y < 0 || y > 7 || x < 0 || x > 7)) continue;
      const sq = cells.map(([y, x]) => y * 8 + x);
      sq.forEach((q, pos) => lists[q].push(sq[0], sq[1], sq[2], pos));
    }
  }
  for (let q = 0; q < 64; q++) WIN.push(Int8Array.from(lists[q]));
}
const SUM = new Float64Array(9), CNT = new Float64Array(9);
const isMine = (pH, pL, q) => (q < 32 ? (pL >>> q) & 1 : (pH >>> (q - 32)) & 1);

/**
 * 在 s 落子（下棋者 color，落子後己方位元 pH/pL）可得的加分，乘上換算係數 scale。
 * value > 0：落下的棋數字已知；value = 0：未知，依袋中分布取期望值。
 *
 * 每個三連另外兩顆的數字已知時，能湊成三條／有序順子／湊十的「第三顆數字」最多各一個，
 * 直接算出來累加到 SUM[v]、CNT[v]，不必對 1～8 逐一判斷。牌型規則見 core/bonus.js。
 */
function bonusAt(pH, pL, s, color, value, scale) {
  const own = color === BLACK ? FB : FW;
  const w = WIN[s];
  let any = false;
  for (let i = 0; i < w.length; i += 4) {
    const pos = w[i + 3];
    // 依直線順序，另外兩格
    const o1 = pos === 0 ? w[i + 1] : w[i];
    const o2 = pos === 2 ? w[i + 1] : w[i + 2];
    if (!KNOWN[o1] || !KNOWN[o2] || !isMine(pH, pL, o1) || !isMine(pH, pL, o2)) continue;
    if (!any) { SUM.fill(0); CNT.fill(0); any = true; }
    const x = own[o1], y = own[o2];
    // 三條
    if (x === y) { SUM[x] += POINTS.trips; CNT[x]++; }
    // 有序順子（依新棋在三連中的位置）
    const d = y - x;
    let v = 0;
    if (pos === 1) { if (d === 2 || d === -2) v = x + d / 2; }
    else if (d === 1 || d === -1) v = pos === 0 ? x - d : y + d;
    if (v >= 1 && v <= 8) { SUM[v] += POINTS.ordered; CNT[v]++; }
    // 湊十
    const t = 10 - x - y;
    if (t >= 1 && t <= 8) { SUM[t] += POINTS.ten; CNT[t]++; }
  }
  if (!any) return 0;
  if (value > 0) return scale * SUM[value] * CNT[value]; // Combo：總和 × 組數
  const P = color === BLACK ? PB : PW;
  let ev = 0;
  for (let v = 1; v <= 8; v++) if (CNT[v] > 0) ev += P[v] * SUM[v] * CNT[v];
  return scale * ev;
}

/**
 * 加分換算成評估值的係數，依落子後的剩餘空格決定。
 * tests/eval-scale.js 實測：中盤評估值約被壓縮 3 倍（終局分差 ≈ 2.5～3.3 × 評估值），
 * 終盤則幾乎等於終局分差。所以中盤加分要打折，終盤 1:1。
 */
function bonusScale(empties) {
  const early = params.bonusWeight;
  if (empties >= 25) return early;
  if (empties <= 10) return 1;
  return early + (1 - early) * (25 - empties) / 15;
}

// ===== 中盤搜尋 =====

function nega(pH, pL, oH, oL, color, depth, alpha, beta, k1, k2, ply) {
  if ((++nodes & 2047) === 0 && Date.now() > deadline) throw ABORT;

  const alphaOrig = alpha;
  const idx = k1 & TT_MASK;
  let ttMove = -1;
  if (TT_K2[idx] === k2 && TT_DEPTH[idx] >= 0) {
    ttMove = TT_MOVE[idx];
    if (TT_DEPTH[idx] >= depth) {
      const sc = TT_SCORE[idx], fl = TT_FLAG[idx];
      if (fl === EXACT) return sc;
      if (fl === LOWER) { if (sc > alpha) alpha = sc; }
      else if (sc < beta) beta = sc;
      if (alpha >= beta) return sc;
    }
  }

  mobility(pH, pL, oH, oL);
  const mH = RH, mL = RL;
  const other = color === BLACK ? WHITE : BLACK;
  if ((mH | mL) === 0) {
    mobility(oH, oL, pH, pL);
    if ((RH | RL) === 0) return finalDiff(pH, pL, oH, oL, color, FB, FW);
    return -nega(oH, oL, pH, pL, other, depth, -beta, -alpha, k1 ^ SIDE1, k2 ^ SIDE2, ply + 1);
  }
  if (depth <= 0) return evaluate(pH, pL, oH, oL, color, FB, FW, params);

  // Multi-ProbCut（同 v6）
  if (params.mpc && !inMpc && ply >= MPC_MIN_PLY && depth < MPC_SHALLOW.length && MPC_SHALLOW[depth] > 0 &&
      alpha > -Infinity && beta < Infinity) {
    const st = MPC_STATS[depth];
    const empties = 64 - count(pH | oH, pL | oL);
    if (st && depth < empties) {
      const [bias, sigma] = st[empties > 40 ? 0 : empties > 20 ? 1 : 2];
      const w = params.mpcT * sigma;
      const shallow = MPC_SHALLOW[depth];
      inMpc = true;
      try {
        const hi = beta + bias + w;
        if (nega(pH, pL, oH, oL, color, shallow, hi - NULL_EPS, hi, k1, k2, ply) >= hi) return beta;
        const lo = alpha + bias - w;
        if (nega(pH, pL, oH, oL, color, shallow, lo, lo + NULL_EPS, k1, k2, ply) <= lo) return alpha;
      } finally {
        inMpc = false;
      }
    }
  }

  // 走法排序：與 v6 相同，另外讓有加分的步往前
  const moves = MOVES[ply], keys = KEYS[ply], bons = BONS[ply];
  const bscale = bonusScale(63 - count(pH | oH, pL | oL)); // 落子後的空格數
  squaresOf(mH, mL, sqBuf);
  const n = sqBuf.length;
  for (let i = 0; i < n; i++) {
    const s = sqBuf[i];
    moves[i] = s;
    let key = SQ_ORDER[s];
    // 深度 ≥ 2 時先算好這步的期望加分（排序用，下棋時重用）；
    // 深度 1 的節點常常第一步就剪枝，留到真的要下時才算（NaN = 尚未計算）
    const preBonus = depth >= 2;
    bons[s] = NaN;
    if (preBonus || depth >= 3) {
      flips(pH, pL, oH, oL, s);
      const fH = RH, fL = RL;
      setBit(s);
      const nPH = pH | fH | RH, nPL = pL | fL | RL;
      if (preBonus) {
        KNOWN[s] = 0;
        const b = bonusAt(nPH, nPL, s, color, 0, bscale);
        bons[s] = b;
        key += b * 8;
      }
      // fastest-first：落子後對手能下的位置越少越好
      if (depth >= 3 && s !== ttMove) {
        mobility(oH & ~fH, oL & ~fL, nPH, nPL);
        key -= 2 * count(RH, RL);
      }
    }
    if (s === ttMove) key += 1000;
    keys[i] = key;
  }
  insertionSort(moves, keys, n);

  let best = -Infinity, bestMove = -1;
  for (let i = 0; i < n; i++) {
    const s = moves[i];
    flips(pH, pL, oH, oL, s);
    const fH = RH, fL = RL;
    setBit(s);
    const nPH = pH | fH | RH, nPL = pL | fL | RL;
    const nOH = oH & ~fH, nOL = oL & ~fL;
    FB[s] = avgB; FW[s] = avgW; KNOWN[s] = 0;
    const c1 = keyAfter(k1, Z1, color, s, fH, fL) ^ SIDE1;
    const c2 = keyAfter(k2, Z2, color, s, fH, fL) ^ SIDE2;
    // 這一步的加分直接入袋：子節點的視窗扣掉它
    let bon = bons[s];
    if (bon !== bon) bon = bonusAt(nPH, nPL, s, color, 0, bscale);
    const a2 = alpha - bon, b2 = beta - bon;

    let v;
    if (i === 0) {
      v = bon - nega(nOH, nOL, nPH, nPL, other, depth - 1, -b2, -a2, c1, c2, ply + 1);
    } else {
      v = bon - nega(nOH, nOL, nPH, nPL, other, depth - 1, -a2 - NULL_EPS, -a2, c1, c2, ply + 1);
      if (v > alpha && v < beta) v = bon - nega(nOH, nOL, nPH, nPL, other, depth - 1, -b2, -a2, c1, c2, ply + 1);
    }
    if (v > best) { best = v; bestMove = s; }
    if (v > alpha) alpha = v;
    if (alpha >= beta) break;
  }

  TT_K2[idx] = k2;
  TT_DEPTH[idx] = depth;
  TT_SCORE[idx] = best;
  TT_MOVE[idx] = bestMove;
  TT_FLAG[idx] = best <= alphaOrig ? UPPER : best >= beta ? LOWER : EXACT;
  return best;
}

// ===== 終盤：逐一展開抽棋的精確期望值（含精確加分） =====

function chance(pH, pL, oH, oL, color, bag, n) {
  if ((++nodes & 2047) === 0 && Date.now() > deadline) throw ABORT;
  mobility(pH, pL, oH, oL);
  const mH = RH, mL = RL;
  const other = color === BLACK ? WHITE : BLACK;
  if ((mH | mL) === 0) {
    mobility(oH, oL, pH, pL);
    if ((RH | RL) === 0) return finalDiff(pH, pL, oH, oL, color, FB, FW);
    return -chance(oH, oL, pH, pL, other, bag, n); // PASS：抽到的棋放回袋子
  }
  const moves = squaresOf(mH, mL, []);
  let sum = 0;
  for (let i = 0; i < n; i++) {
    const id = bag[i];
    bag[i] = bag[n - 1]; bag[n - 1] = id;
    sum += placeBest(pH, pL, oH, oL, color, moves, blackWeight(id), whiteWeight(id), bag, n - 1);
    bag[n - 1] = bag[i]; bag[i] = id;
  }
  return sum / n;
}

function placeBest(pH, pL, oH, oL, color, moves, wb, ww, bag, n) {
  const other = color === BLACK ? WHITE : BLACK;
  let best = -Infinity;
  for (let i = 0; i < moves.length; i++) {
    const s = moves[i];
    flips(pH, pL, oH, oL, s);
    const fH = RH, fL = RL;
    setBit(s);
    const nPH = pH | fH | RH, nPL = pL | fL | RL;
    FB[s] = wb; FW[s] = ww; KNOWN[s] = 1;
    const bon = bonusAt(nPH, nPL, s, color, color === BLACK ? wb : ww, 1);
    const v = bon - chance(oH & ~fH, oL & ~fL, nPH, nPL, other, bag, n);
    if (v > best) best = v;
  }
  return best;
}

function setBagStats(bag) {
  avgB = 4.5; avgW = 4.5;
  PB.fill(0); PW.fill(0);
  if (!bag.length) return;
  let sb = 0, sw = 0;
  for (const id of bag) {
    const b = blackWeight(id), w = whiteWeight(id);
    sb += b; sw += w; PB[b]++; PW[w]++;
  }
  avgB = sb / bag.length; avgW = sw / bag.length;
  for (let v = 1; v <= 8; v++) { PB[v] /= bag.length; PW[v] /= bag.length; }
}

// ===== 根節點 =====

/**
 * 參數同 v6 的 searchRoot，另加 bonusPoints（該局的加分表 { ten, ordered, trips }）。
 * 回傳的分數已包含「這一步之後」的加分（不含開局至今已入袋的加分）。
 */
export function searchRootV7({
  board, player, handId, bag, bonusPoints, timeMs = 1000, maxDepth = 60, multiPV = false,
  params: p = V7_PARAMS, exactEmpties = EXACT_EMPTIES
}) {
  const t0 = Date.now();
  params = p;
  POINTS = bonusPoints;
  nodes = 0;
  inMpc = false;

  let pH = 0, pL = 0, oH = 0, oL = 0;
  for (let s = 0; s < 64; s++) {
    const d = board[s >> 3][s & 7];
    if (!d) continue;
    FB[s] = blackWeight(d.id); FW[s] = whiteWeight(d.id); KNOWN[s] = 1;
    const mine = d.face === player;
    if (s < 32) { if (mine) pL |= 1 << s; else oL |= 1 << s; }
    else if (mine) pH |= 1 << (s - 32); else oH |= 1 << (s - 32);
  }
  setBagStats(bag);

  mobility(pH, pL, oH, oL);
  const rootMoves = squaresOf(RH, RL, []);
  if (rootMoves.length === 0) return null;

  const hb = blackWeight(handId), hw = whiteWeight(handId);
  const hv = player === BLACK ? hb : hw;
  const other = player === BLACK ? WHITE : BLACK;
  const empties = 64 - count(pH | oH, pL | oL);

  const child = (s) => {
    flips(pH, pL, oH, oL, s);
    const fH = RH, fL = RL;
    setBit(s);
    return { s, fH, fL, nPH: pH | fH | RH, nPL: pL | fL | RL, nOH: oH & ~fH, nOL: oL & ~fL };
  };

  // 1) 終盤精確求解
  if (empties <= exactEmpties) {
    deadline = t0 + Math.max(timeMs, 300) * 2;
    const bagArr = bag.slice();
    try {
      const scores = rootMoves.map(s => {
        const c = child(s);
        FB[s] = hb; FW[s] = hw; KNOWN[s] = 1;
        const bon = bonusAt(c.nPH, c.nPL, s, player, hv, 1);
        return { sq: s, score: bon - chance(c.nOH, c.nOL, c.nPH, c.nPL, other, bagArr, bagArr.length) };
      });
      scores.sort((a, b) => b.score - a.score);
      return { bestSq: scores[0].sq, scores, depth: empties, exact: true, chanceExact: true, nodes, ms: Date.now() - t0 };
    } catch (e) {
      if (e !== ABORT) throw e;
      for (let s = 0; s < 64; s++) {
        const d = board[s >> 3][s & 7];
        if (d) { FB[s] = blackWeight(d.id); FW[s] = whiteWeight(d.id); KNOWN[s] = 1; }
      }
    }
  }

  // 2) 迭代加深 NegaScout
  TT_DEPTH.fill(-1);
  deadline = Date.now() + timeMs;
  let k1 = 0, k2 = 0;
  for (let s = 0; s < 64; s++) {
    const d = board[s >> 3][s & 7];
    if (!d) continue;
    const ci = d.face === BLACK ? 0 : 64;
    k1 ^= Z1[ci + s]; k2 ^= Z2[ci + s];
  }

  let order = rootMoves.map(s => ({ sq: s, score: SQ_ORDER[s] }));
  let completed = null, completedDepth = 0;
  const limit = Math.min(maxDepth, empties);
  const rootScale = bonusScale(empties - 1);

  for (let depth = 1; depth <= limit; depth++) {
    const results = [];
    let alpha = -Infinity;
    try {
      for (let i = 0; i < order.length; i++) {
        const c = child(order[i].sq);
        const s = c.s;
        FB[s] = hb; FW[s] = hw; KNOWN[s] = 1;
        const c1 = keyAfter(k1, Z1, player, s, c.fH, c.fL) ^ SIDE1 ^ H1[s];
        const c2 = keyAfter(k2, Z2, player, s, c.fH, c.fL) ^ SIDE2 ^ H2[s];
        const bon = bonusAt(c.nPH, c.nPL, s, player, hv, rootScale);
        const a2 = alpha - bon;
        let v;
        if (multiPV || i === 0) {
          v = bon - nega(c.nOH, c.nOL, c.nPH, c.nPL, other, depth - 1, -Infinity, Infinity, c1, c2, 1);
        } else {
          v = bon - nega(c.nOH, c.nOL, c.nPH, c.nPL, other, depth - 1, -a2 - NULL_EPS, -a2, c1, c2, 1);
          if (v > alpha) v = bon - nega(c.nOH, c.nOL, c.nPH, c.nPL, other, depth - 1, -Infinity, -a2, c1, c2, 1);
        }
        results.push({ sq: s, score: v });
        if (v > alpha) alpha = v;
      }
    } catch (e) {
      if (e !== ABORT) throw e;
      if (completed && results.length) {
        const bestNew = results.reduce((a, b) => (b.score > a.score ? b : a));
        const prevBest = completed[0];
        if (bestNew.sq !== prevBest.sq && results[0].sq === prevBest.sq && bestNew.score > results[0].score) {
          completed = [bestNew, ...completed.filter(x => x.sq !== bestNew.sq)];
        }
      }
      break;
    }
    results.sort((a, b) => b.score - a.score);
    completed = results;
    completedDepth = depth;
    order = results;
    if (Date.now() - t0 > timeMs * 0.45) break;
  }

  if (!completed) completed = order;
  return { bestSq: completed[0].sq, scores: completed, depth: completedDepth, exact: completedDepth >= empties, nodes, ms: Date.now() - t0 };
}
