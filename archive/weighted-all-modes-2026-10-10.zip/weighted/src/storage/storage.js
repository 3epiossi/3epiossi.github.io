/**
 * 📦 權重黑白棋 - 儲存管理層 (Storage Layer)
 * 與原專案使用不同的 localStorage 鍵，兩個遊戲的設定互不影響。
 * （棋子外觀與語言偏好是刻意共用的：skin 在 SkinManager、語言是 takuLang。）
 */

const STORAGE_KEYS = {
  SETTINGS: "weighted_othello_settings_v1",
  ONBOARDING: "weighted_othello_onboarding_v1"
};

const DEFAULTS = {
  theme: "neon",
  soundEnabled: true,
  animationLevel: "standard", // "full" | "standard" | "minimal"
  blackRole: "human",
  whiteRole: "cpu",
  v6Time: 1000,
  variant: "classic", // 遊戲模式：classic 經典 / five 五連
  bonusLevel: "off", // 加分模式：off / low / mid / high（只用於經典模式）
  blackName: "",
  whiteName: "",
  flipped: false
};

export const Storage = {
  getSettings() {
    try {
      const raw = localStorage.getItem(STORAGE_KEYS.SETTINGS);
      if (raw) {
        const saved = { ...DEFAULTS, ...JSON.parse(raw) };
        // 已移除的欄位（舊版的演算法選擇與思考速度）不再保留
        for (const k of ["blackAlgo", "whiteAlgo", "aiDefaultsVersion", "cpuSpeed"]) delete saved[k];
        return saved;
      }
    } catch (e) {}
    return { ...DEFAULTS };
  },

  saveSettings(settings) {
    try {
      localStorage.setItem(STORAGE_KEYS.SETTINGS, JSON.stringify(settings));
    } catch (e) {}
  },

  hasSeenOnboarding() {
    try {
      return localStorage.getItem(STORAGE_KEYS.ONBOARDING) === "true";
    } catch (e) {
      return false;
    }
  },

  setOnboardingSeen() {
    try {
      localStorage.setItem(STORAGE_KEYS.ONBOARDING, "true");
    } catch (e) {}
  }
};
