/**
 * ⚖️ 權重黑白棋 (Weighted Othello) - 核心常數定義
 * 每顆棋子兩面各有 1～8 的權重，64 顆剛好是 8×8 所有 (白面, 黑面) 組合
 */

export const BOARD_SIZE = 8;
export const N = BOARD_SIZE;

// 與原專案 control-state.js 共用同一組數值
export const EMPTY = 0;
export const BLACK = 1;
export const WHITE = 2;

export const FILES = "ABCDEFGH";
export const DISC_COUNT = N * N;

export const DIRS = Object.freeze([
  [-1, -1], [-1, 0], [-1, 1],
  [0, -1],           [0, 1],
  [1, -1],  [1, 0],  [1, 1]
]);

export const MOVE_TYPE = Object.freeze({
  PLACE: "place",
  PASS: "pass"
});
