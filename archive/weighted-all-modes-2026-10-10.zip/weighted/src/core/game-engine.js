/**
 * ⚖️ 權重黑白棋 (Weighted Othello) - 核心遊戲引擎 (Game Engine)
 * 遵循單一真相來源 (Single Source of Truth)：棋盤、輪次、手上的棋都存在這裡，
 * 並透過對局樹記錄每一手，以支援時光機與分支。
 *
 * 每回合開始時，系統從袋子隨機抽一顆棋（hand）給當前玩家；玩家只決定下在哪裡。
 * 沒有合法位置時，抽到的棋放回袋子並跳過本回合（PASS）。
 *
 * 兩種遊戲模式（variant，每局固定）：
 *   classic  經典：棋子兩面權重不同，比權重總和；可搭配加分模式（core/bonus.js）
 *   five     加權五連：棋子有左右兩個數字、兩面相同，連成五條直接獲勝，否則比左 × 右的總和（core/five-rules.js）
 *   fivePlain 五連：同上，但每顆棋 1 分（顯示成 A～H 字母），否則比棋子數
 */

import { msg } from "../i18n.js";
import { BLACK, WHITE, MOVE_TYPE } from "./constants.js";
import {
  opp,
  cloneBoard,
  cloneMove,
  createInitialBoard,
  createDisc,
  remainingBag,
  getLegalMoves,
  hasLegalMove,
  applyMoveToBoard,
  isBoardFull,
  calculateSettlement,
  posToCoord,
  weightOf
} from "./rules.js";
import { GameTree } from "../history/game-tree.js";
import { findPatterns, bonusOfPatterns, emptyBonus, BONUS_LEVELS, normalizeBonusLevel } from "./bonus.js";
import { findFive, fiveScores, valueOf, letterOf } from "./five-rules.js";

export const VARIANTS = Object.freeze(["classic", "five", "fivePlain"]);
export const normalizeVariant = (v) => (VARIANTS.includes(v) ? v : "classic");
/** 是否為五連類規則（加權五連、五連） */
export const isFiveVariant = (v) => v === "five" || v === "fivePlain";

export class GameEngine {
  /**
   * @param {object} options
   * @param {() => number} [options.rng] 亂數來源（測試可注入固定種子）
   * @param {"off"|"low"|"mid"|"high"} [options.bonusLevel] 加分模式（牌型）的加分值，每局固定
   * @param {"classic"|"five"|"fivePlain"} [options.variant] 遊戲模式，每局固定
   */
  constructor(options = {}) {
    this.rng = options.rng || Math.random;
    this.variant = normalizeVariant(options.variant);
    this.setBonusLevel(options.bonusLevel);
    this.bonus = emptyBonus(); // 雙方累計加分
    this.blackPlayerType = options.blackPlayerType || "human";
    this.whitePlayerType = options.whitePlayerType || "cpu";

    this.board = null;
    this.currentTurn = BLACK;
    this.hand = null; // 當前玩家抽到的棋 id
    this.gameOver = false;
    this.lastMove = null;
    this.settlementData = null;
    this.tree = null;
    this.listeners = new Set();

    this.#newPosition();
  }

  subscribe(listener) {
    this.listeners.add(listener);
    return () => this.listeners.delete(listener);
  }

  notify(event, payload) {
    for (const listener of this.listeners) {
      try {
        listener(event, payload, this.getState());
      } catch (err) {
        console.error("GameEngine listener error:", err);
      }
    }
  }

  getState() {
    return {
      board: cloneBoard(this.board),
      currentTurn: this.currentTurn,
      hand: this.hand,
      gameOver: this.gameOver,
      variant: this.variant,
      bonusMode: this.bonusMode,
      bonusLevel: this.bonusLevel,
      bonusPoints: this.bonusPoints,
      bonus: { ...this.bonus },
      lastMove: this.lastMove ? cloneMove(this.lastMove) : null,
      settlementData: this.settlementData ? { ...this.settlementData } : null,
      blackPlayerType: this.blackPlayerType,
      whitePlayerType: this.whitePlayerType,
      currentNode: this.tree ? this.tree.getCurrentNode() : null
    };
  }

  /** 從袋子隨機抽一顆（不改變任何狀態，只回傳 id） */
  drawFromBag(excludeHand = true) {
    const bag = remainingBag(this.board, excludeHand ? this.hand : null);
    if (bag.length === 0) return null;
    return bag[Math.floor(this.rng() * bag.length)];
  }

  bagSize() {
    return remainingBag(this.board, this.hand).length;
  }

  legalMoves() {
    return this.gameOver ? [] : getLegalMoves(this.board, this.currentTurn);
  }

  findLegalMove(r, c) {
    return this.legalMoves().find(m => m.r === r && m.c === c) || null;
  }

  // 開新局面：標準開局，四顆起始棋由袋子隨機抽出
  #newPosition() {
    const taken = new Set();
    const drawInitial = () => {
      let id;
      do { id = Math.floor(this.rng() * 64); } while (taken.has(id));
      taken.add(id);
      return id;
    };
    this.board = createInitialBoard(drawInitial);
    this.currentTurn = BLACK;
    this.gameOver = false;
    this.lastMove = null;
    this.settlementData = null;
    this.bonus = emptyBonus();
    this.hand = this.drawFromBag(false);
    if (this.tree) this.tree.init(this.board, this.currentTurn, this.hand);
    else this.tree = new GameTree(this.board, this.currentTurn, this.hand);
  }

  setBonusLevel(level) {
    // 加分模式只屬於經典規則
    this.bonusLevel = isFiveVariant(this.variant) ? "off" : normalizeBonusLevel(level);
    this.bonusPoints = BONUS_LEVELS[this.bonusLevel];
    this.bonusMode = !!this.bonusPoints;
  }

  /** 開新局；可同時換遊戲模式與加分模式（兩者在一局之中固定） */
  resetGame(bonusLevel = this.bonusLevel, variant = this.variant) {
    this.variant = normalizeVariant(variant);
    this.setBonusLevel(bonusLevel);
    this.#newPosition();
    this.notify("GAME_RESET");
  }

  /**
   * 執行走步：把手上的棋下在 (r, c)。朝上的顏色就是下棋者的顏色。
   */
  executeMove(r, c) {
    if (this.gameOver || this.hand == null) return false;

    // REVIEW 狀態（非分支最新端點）不允許直接落子，須透過「從這裡開始下」建立新分支
    const tip = this.tree.getBranchTipNode();
    const curr = this.tree.getCurrentNode();
    if (curr && tip && curr.id !== tip.id) return false;

    const move = this.findLegalMove(r, c);
    if (!move) return false;

    const player = this.currentTurn;
    const placedId = this.hand;
    const gain = this.variant === "five" ? valueOf(placedId) : this.variant === "fivePlain" ? 1 : weightOf(placedId, player);
    this.board = applyMoveToBoard(this.board, move, placedId, player);
    this.lastMove = {
      type: MOVE_TYPE.PLACE, player, r, c, discId: placedId,
      flips: move.flips.map(f => [...f])
    };
    this.hand = null;

    let bonusText = "";
    if (this.bonusMode) {
      const patterns = findPatterns(this.board, r, c, player);
      const points = bonusOfPatterns(patterns, this.bonusPoints);
      if (points > 0) {
        this.bonus = { ...this.bonus, [player]: this.bonus[player] + points };
        this.lastMove.bonus = { patterns, points, combo: patterns.length };
        bonusText = msg("logBonus", { list: patterns.map(p => msg("pt_" + p.type)), pts: points });
      }
    }

    // 五連模式：連成五條直接獲勝（翻面造成的也算）
    const five = isFiveVariant(this.variant) ? findFive(this.board, player) : null;
    if (five) bonusText = msg("logFive", { v: this.fiveLabel(five.value) });

    const logText = msg("logMove", {
      idx: (curr ? curr.stepIdx : 0) + 1,
      side: msg(player === BLACK ? "sideBlack" : "sideWhite"),
      to: posToCoord(r, c),
      w: gain,
      n: move.flips.length,
      bonus: bonusText
    });
    if (five) {
      this.lastMove.five = five;
      this.#finishByFive(player, five, logText);
    } else {
      this.#advance(opp(player), logText, this.lastMove);
    }
    this.notify("MOVE_EXECUTED", { move: this.lastMove, gameOver: this.gameOver });
    if (this.gameOver) this.notify("GAME_OVER", this.settlementData);
    return true;
  }

  /** 五條的符號：五連模式顯示字母，加權五連顯示數字 */
  fiveLabel(n) {
    return this.variant === "fivePlain" ? letterOf(n) : n;
  }

  /** 雙方目前的分數（依遊戲模式） */
  scores() {
    if (isFiveVariant(this.variant)) return { ...fiveScores(this.board, this.variant === "five"), ...this.#discCounts() };
    const s = calculateSettlement(this.board);
    return { black: s.black, white: s.white, blackCount: s.blackCount, whiteCount: s.whiteCount };
  }

  #discCounts() {
    let blackCount = 0, whiteCount = 0;
    for (const row of this.board) for (const d of row) if (d) { if (d.face === BLACK) blackCount++; else whiteCount++; }
    return { blackCount, whiteCount };
  }

  /** 五連獲勝：立刻結束，記錄在對局樹 */
  #finishByFive(player, five, logText) {
    const sc = this.scores();
    this.gameOver = true;
    this.hand = null;
    this.settlementData = {
      ...sc,
      winner: player,
      diff: Math.abs(sc.black - sc.white),
      totalBlack: sc.black,
      totalWhite: sc.white,
      bonusBlack: 0,
      bonusWhite: 0,
      byFive: true,
      five,
      reason: msg("reasonFive", { side: msg(player === BLACK ? "sideBlack" : "sideWhite"), v: this.fiveLabel(five.value) })
    };
    this.tree.appendMoveNode({
      turn: this.currentTurn,
      hand: null,
      move: this.lastMove,
      board: this.board,
      gameOver: true,
      settlementData: this.settlementData,
      logText,
      bonus: this.bonus
    });
  }

  /** PASS：抽到的棋放回袋子，輪到對手並重新抽棋 */
  passTurn() {
    if (this.gameOver) return false;
    const player = this.currentTurn;
    this.hand = null;
    this.lastMove = { type: MOVE_TYPE.PASS, player, flips: [] };

    const logText = msg("logPass", {
      side: msg(player === BLACK ? "sideBlack" : "sideWhite"),
      enemy: msg(player === BLACK ? "sideWhite" : "sideBlack")
    });
    this.#advance(opp(player), logText, this.lastMove);
    this.notify("PASS_EXECUTED", { player, gameOver: this.gameOver });
    if (this.gameOver) this.notify("GAME_OVER", this.settlementData);
    return true;
  }

  // 輪到 next：判斷終局、抽棋、必要時要求 PASS，並寫入對局樹
  #advance(next, logText, move) {
    let over = false;
    if (isBoardFull(this.board) || (!hasLegalMove(this.board, next) && !hasLegalMove(this.board, opp(next)))) {
      over = true;
    }
    if (over) {
      this.gameOver = true;
      this.currentTurn = next;
      this.hand = null;
      this.settlementData = this.#settle();
    } else {
      this.currentTurn = next;
      this.hand = this.drawFromBag(false);
    }

    this.tree.appendMoveNode({
      turn: this.currentTurn,
      hand: this.hand,
      move,
      board: this.board,
      gameOver: this.gameOver,
      settlementData: this.settlementData,
      logText,
      bonus: this.bonus
    });

    if (!over && !hasLegalMove(this.board, this.currentTurn)) {
      this.notify("PASS_REQUIRED", { player: this.currentTurn });
    }
  }

  /** 終局結算：權重總和 + 加分（加分模式），多者勝 */
  #settle() {
    const reason = msg(isBoardFull(this.board) ? "reasonFull" : "reasonNoMoves");
    if (isFiveVariant(this.variant)) {
      const sc = this.scores();
      return {
        ...sc, reason, bonusBlack: 0, bonusWhite: 0, totalBlack: sc.black, totalWhite: sc.white,
        winner: sc.black === sc.white ? 0 : (sc.black > sc.white ? BLACK : WHITE),
        diff: Math.abs(sc.black - sc.white)
      };
    }
    const base = calculateSettlement(this.board);
    if (!this.bonusMode) return { ...base, reason, bonusBlack: 0, bonusWhite: 0, totalBlack: base.black, totalWhite: base.white };
    const totalBlack = base.black + this.bonus[BLACK], totalWhite = base.white + this.bonus[WHITE];
    return {
      ...base,
      reason,
      bonusBlack: this.bonus[BLACK],
      bonusWhite: this.bonus[WHITE],
      totalBlack,
      totalWhite,
      winner: totalBlack === totalWhite ? 0 : (totalBlack > totalWhite ? BLACK : WHITE),
      diff: Math.abs(totalBlack - totalWhite)
    };
  }

  /** 從歷史節點開闢全新分支並跳轉到該節點（唯一建立分支的入口） */
  startFromHere(nodeId, customBranchName = null) {
    const node = this.tree.getNode(nodeId);
    if (!node) return false;

    let name = customBranchName;
    if (!name) {
      let dupe = 0;
      for (const b of this.tree.branches.values()) {
        if (b.name && b.name.k && b.name.p && b.name.p.n === node.stepIdx) dupe++;
      }
      name = dupe === 0
        ? msg("branchFrom", { n: node.stepIdx })
        : msg("branchFromDup", { n: node.stepIdx, dup: dupe + 1 });
    }
    this.tree.createBranchFromNode(nodeId, name);
    this.jumpToNode(nodeId);
    return true;
  }

  jumpToNode(nodeId) {
    const node = this.tree.getNode(nodeId);
    if (!node) return false;
    this.tree.currentNodeId = node.id;
    this.board = cloneBoard(node.board);
    this.currentTurn = node.turn;
    this.hand = node.hand;
    this.gameOver = node.gameOver;
    this.lastMove = node.move ? cloneMove(node.move) : null;
    this.settlementData = node.settlementData ? { ...node.settlementData } : null;
    this.bonus = { ...node.bonus };
    this.notify("STATE_RESTORED", { node });
    return true;
  }

  // ===== 自由擺盤 =====

  /**
   * 擺盤筆刷作用在 (r, c)。
   * brush: "toggle" 空→黑→白→空；"black"/"white" 放置該面朝上的棋；"empty" 清除。
   * 新放的棋從袋子裡隨機取，因此盤面上不會有重複的棋。
   */
  setupCell(r, c, brush) {
    const cell = this.board[r][c];
    const place = (face) => {
      if (cell) { cell.face = face; return true; }
      const id = this.drawFromBag(true);
      if (id == null) return false;
      this.board[r][c] = createDisc(id, face);
      return true;
    };
    if (brush === "empty") this.board[r][c] = null;
    else if (brush === "black") place(BLACK);
    else if (brush === "white") place(WHITE);
    else if (!cell) place(BLACK);
    else if (cell.face === BLACK) cell.face = WHITE;
    else this.board[r][c] = null;
    this.notify("SETUP_CHANGED");
  }

  /**
   * 排盤完成：以目前盤面為新的開局（#0），由 firstTurn 先手，並重新抽棋。
   * 之前的歷程與分支會被清掉，因為它們屬於另一個局面。
   */
  commitSetup(firstTurn = BLACK) {
    this.currentTurn = firstTurn;
    this.gameOver = false;
    this.lastMove = null;
    this.settlementData = null;
    this.bonus = emptyBonus();
    this.hand = null;
    this.hand = this.drawFromBag(false);

    if (isBoardFull(this.board) || (!hasLegalMove(this.board, BLACK) && !hasLegalMove(this.board, WHITE))) {
      this.gameOver = true;
      this.hand = null;
      this.settlementData = this.#settle();
    }
    this.tree.init(this.board, this.currentTurn, this.hand);
    const root = this.tree.getCurrentNode();
    root.gameOver = this.gameOver;
    root.settlementData = this.settlementData ? { ...this.settlementData } : null;
    this.notify("GAME_RESET");
    if (!this.gameOver && !hasLegalMove(this.board, this.currentTurn)) {
      this.notify("PASS_REQUIRED", { player: this.currentTurn });
    }
  }
}
