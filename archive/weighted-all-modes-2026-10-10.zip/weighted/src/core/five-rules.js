/**
 * 🎯 五連規則（左右兩個符號的棋）
 *
 * 棋子：左、右各一個符號（1～8），64 顆剛好是所有 (左, 右) 組合各一顆，兩面相同，翻面只換顏色。
 * 兩種模式共用連五規則，只差在終局計分與顯示：
 *   加權五連  顯示「7×8」，一顆棋的分數 = 左 × 右（總和 1296）
 *   五連      顯示「G|H」（A～H 代替 1～8，避免讓人聯想到權重），每顆棋 1 分（總和 64）
 *
 * 勝負：
 *   - 落子後，下棋者在同一直線（橫、直、斜）上有連續 5 顆己方的棋，
 *     且每顆任選左或右的數字能全部相同（五條），立刻獲勝。翻面造成的五連也算。
 *   - 整局都沒人連成五 → 比各自棋子分數總和，多者勝，相同為平手。
 *
 * 棋子 id 沿用 0～63：左 = (id & 7) + 1，右 = (id >> 3) + 1。
 */

import { N, BLACK } from "./constants.js";

export const leftOf = (id) => (id & 7) + 1;
export const rightOf = (id) => (id >> 3) + 1;
export const valueOf = (id) => leftOf(id) * rightOf(id);
/** 五連模式用字母代替數字：1～8 → A～H */
export const LETTERS = "ABCDEFGH";
export const letterOf = (n) => LETTERS[n - 1];
/** 符號的顯示：五連（plain）用字母，加權五連用數字 */
export const symbolOf = (n, plain) => (plain ? letterOf(n) : String(n));
/** 棋子的顯示：加權五連「7×8」、五連「G|H」 */
export const discLabel = (id, plain) => (plain
  ? `${letterOf(leftOf(id))}|${letterOf(rightOf(id))}`
  : `${leftOf(id)}×${rightOf(id)}`);
/** 棋子的數字集合：第 v-1 位元代表含有數字 v */
export const numberMask = (id) => (1 << (leftOf(id) - 1)) | (1 << (rightOf(id) - 1));

export const FIVE = 5;
const AXES = [[0, 1], [1, 0], [1, 1], [1, -1]];

/** 盤上所有五連窗口（每個窗口是 5 個 [r, c]），共 96 個 */
export const FIVE_WINDOWS = [];
for (let r = 0; r < N; r++) for (let c = 0; c < N; c++) {
  for (const [dr, dc] of AXES) {
    const cells = Array.from({ length: FIVE }, (_, k) => [r + k * dr, c + k * dc]);
    if (cells.every(([y, x]) => y >= 0 && y < N && x >= 0 && x < N)) FIVE_WINDOWS.push(cells);
  }
}

/**
 * 找出 player 已連成的五條。回傳 { value, cells } 或 null。
 * 落子前不可能已有五條（否則比賽早就結束），所以掃整個棋盤即可。
 */
export function findFive(board, player) {
  for (const cells of FIVE_WINDOWS) {
    let mask = 0xFF;
    for (const [y, x] of cells) {
      const d = board[y][x];
      if (!d || d.face !== player) { mask = 0; break; }
      mask &= numberMask(d.id);
    }
    if (mask) return { value: 31 - Math.clz32(mask & -mask) + 1, cells: cells.map(c => [...c]) };
  }
  return null;
}

/** 雙方分數。weighted = true：每顆 = 左 × 右（加權五連）；false：每顆 1 分（五連） */
export function fiveScores(board, weighted = true) {
  const s = { black: 0, white: 0 };
  for (const row of board) for (const d of row) {
    if (!d) continue;
    const v = weighted ? valueOf(d.id) : 1;
    if (d.face === BLACK) s.black += v; else s.white += v;
  }
  return s;
}
