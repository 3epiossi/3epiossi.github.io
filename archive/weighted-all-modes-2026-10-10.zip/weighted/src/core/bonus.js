/**
 * 🃏 加分模式（牌型）規則
 *
 * 落子後，檢查「經過剛落下那顆棋、三格都是己方」的直線三連（橫、直、兩條斜線），
 * 讀三顆棋朝上那面（下棋者顏色）的數字，依直線上的順序判斷牌型：
 *
 *   三條       三顆同數字
 *   有序順子   沿直線依序連號，遞增或遞減（如 3-4-5、6-5-4）
 *   湊十       三顆相加 = 10
 *
 * 三種牌型互斥（順子的和 3a+3、三條的和 3a 都不可能是 10）。
 * 一步同時完成 k 組牌型 = Combo k，加分 = 各組加分總和 × k。
 * 加分當下入袋，之後棋被翻掉也不扣。
 *
 * 加分值有四段可選（每局開始時決定），比例都是 1 : 2 : 4：
 *   off 無加分；low 2/4/8；mid 4/8/16；high 8/16/32
 * 數值依據見 tests/bonus-balance.js、tests/bonus-duel.js。
 */

import { N } from "./constants.js";
import { weightOf } from "./rules.js";

export const BONUS_LEVELS = Object.freeze({
  off: null,
  low: Object.freeze({ ten: 2, ordered: 4, trips: 8 }),
  mid: Object.freeze({ ten: 4, ordered: 8, trips: 16 }),
  high: Object.freeze({ ten: 8, ordered: 16, trips: 32 })
});
export const BONUS_LEVEL_KEYS = Object.freeze(["off", "low", "mid", "high"]);
export const normalizeBonusLevel = (level) => (BONUS_LEVEL_KEYS.includes(level) ? level : "off");

export const PATTERN_TYPES = Object.freeze(["trips", "ordered", "ten"]);

/** a, b, c 依直線上的順序；回傳牌型或 null */
export function classifyPattern(a, b, c) {
  if (a === b && b === c) return "trips";
  if ((b === a + 1 && c === b + 1) || (b === a - 1 && c === b - 1)) return "ordered";
  if (a + b + c === 10) return "ten";
  return null;
}

export const comboMultiplier = (k) => (k > 0 ? k : 0);

/** 牌型清單 → 這一步的總加分（points 為該局的加分表） */
export function bonusOfPatterns(patterns, points) {
  if (!patterns.length || !points) return 0;
  let sum = 0;
  for (const p of patterns) sum += points[p.type];
  return sum * comboMultiplier(patterns.length);
}

const AXES = [[0, 1], [1, 0], [1, 1], [1, -1]];

/**
 * 落子後，找出經過 (r, c) 且三格都是 player 的三連所形成的牌型。
 * @returns {{ type: string, cells: [number, number][], values: number[] }[]}
 */
export function findPatterns(board, r, c, player) {
  const found = [];
  for (const [dr, dc] of AXES) {
    for (let start = -2; start <= 0; start++) {
      const cells = [];
      let ok = true;
      for (let k = 0; k < 3; k++) {
        const y = r + (start + k) * dr, x = c + (start + k) * dc;
        if (y < 0 || y >= N || x < 0 || x >= N) { ok = false; break; }
        const d = board[y][x];
        if (!d || d.face !== player) { ok = false; break; }
        cells.push([y, x]);
      }
      if (!ok) continue;
      const values = cells.map(([y, x]) => weightOf(board[y][x].id, player));
      const type = classifyPattern(values[0], values[1], values[2]);
      if (type) found.push({ type, cells, values });
    }
  }
  return found;
}

export const emptyBonus = () => ({ 1: 0, 2: 0 });
