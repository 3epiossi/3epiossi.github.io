/**
 * ✨ 牌型特效：完成牌型時，三顆棋依序發光並跳出提示。
 *
 * Combo 時一組一組輪流亮起（第 1 組 → 第 2 組 → …），每組各自顯示牌型與分數，
 * 最後再顯示「Combo ×k　+總分」，玩家才數得出這一步完成了幾組。
 *
 * 特效畫在棋盤上方獨立的圖層，不受棋盤重繪影響（CPU 落子後畫面會馬上重繪好幾次）。
 */

import { tr } from "../i18n.js";

const STEP_MS = 650;      // 每組之間的間隔
const LINGER_MS = 1300;   // 最後一組亮起後停留多久

export class PatternFx {
  /**
   * @param {object} o
   * @param {HTMLElement} o.frame   棋盤外框（定位基準，position: relative）
   * @param {HTMLElement} o.board   棋盤格容器
   */
  constructor({ frame, board }) {
    this.frame = frame;
    this.board = board;
    this.layer = document.createElement("div");
    this.layer.className = "patternLayer";
    this.layer.setAttribute("aria-hidden", "true");
    frame.appendChild(this.layer);
    this.live = document.createElement("div");
    this.live.className = "srOnly";
    this.live.setAttribute("aria-live", "polite");
    frame.appendChild(this.live);
    this.timers = [];
  }

  clear() {
    for (const t of this.timers) clearTimeout(t);
    this.timers = [];
    this.layer.replaceChildren();
  }

  /** 某格相對於棋盤外框的位置 */
  cellRect(r, c) {
    const cell = this.board.querySelector(`.cell[data-r="${r}"][data-c="${c}"]`);
    if (!cell) return null;
    const a = cell.getBoundingClientRect(), f = this.frame.getBoundingClientRect();
    return { left: a.left - f.left, top: a.top - f.top, width: a.width, height: a.height };
  }

  /**
   * @param {{ patterns: {type:string, cells:[number,number][]}[], points:number, combo:number }} bonus
   * @param {{ten:number, ordered:number, trips:number}} table 該局的加分表
   * @param {boolean} reduced 減少動畫（只顯示最後的總計）
   */
  play(bonus, table, reduced = false) {
    this.clear();
    if (!bonus || !bonus.patterns.length) return;
    const k = bonus.patterns.length;
    const names = bonus.patterns.map(p => tr("pt_" + p.type));
    this.live.textContent = k > 1
      ? tr("fxComboTotal", { k, pts: bonus.points })
      : tr("fxSingle", { name: names[0], pts: bonus.points });

    const showAt = (i, fn) => this.timers.push(setTimeout(fn, reduced ? 0 : i * STEP_MS));

    bonus.patterns.forEach((p, i) => {
      showAt(i, () => {
        // 前一組的光暗下來，保留淡淡的痕跡
        this.layer.querySelectorAll(".patternGlow.active").forEach(el => el.classList.remove("active"));
        for (const [r, c] of p.cells) {
          const rect = this.cellRect(r, c);
          if (!rect) continue;
          const g = document.createElement("div");
          g.className = `patternGlow active t-${p.type}`;
          Object.assign(g.style, { left: `${rect.left}px`, top: `${rect.top}px`, width: `${rect.width}px`, height: `${rect.height}px` });
          this.layer.appendChild(g);
        }
        this.toast(k > 1
          ? tr("fxStep", { i: i + 1, k, name: names[i], pts: table[p.type] })
          : tr("fxSingle", { name: names[i], pts: bonus.points }), p.type);
      });
    });

    const end = reduced ? 0 : (k - 1) * STEP_MS;
    if (k > 1) {
      this.timers.push(setTimeout(() => this.toast(tr("fxComboTotal", { k, pts: bonus.points }), "combo"), end + STEP_MS));
    }
    this.timers.push(setTimeout(() => this.clear(), end + (k > 1 ? STEP_MS : 0) + LINGER_MS));
  }

  /**
   * 五連獲勝：五顆依序亮起，最後宣告「五條 v！」
   * @param {{ value:number, cells:[number,number][] }} five
   * @param {string} label 五條的符號（五連顯示字母、加權五連顯示數字）
   */
  playFive(five, label, reduced = false) {
    this.clear();
    if (!five) return;
    this.live.textContent = tr("fxFive", { v: label });
    const step = reduced ? 0 : 110;
    five.cells.forEach(([r, c], i) => {
      this.timers.push(setTimeout(() => {
        const rect = this.cellRect(r, c);
        if (!rect) return;
        const g = document.createElement("div");
        g.className = "patternGlow active t-five";
        Object.assign(g.style, { left: `${rect.left}px`, top: `${rect.top}px`, width: `${rect.width}px`, height: `${rect.height}px` });
        this.layer.appendChild(g);
      }, i * step));
    });
    this.timers.push(setTimeout(() => this.toast(tr("fxFive", { v: label }), "five"), 5 * step));
    // 五連是終局：光效留在盤上，直到開新局或跳回歷史局面
  }

  toast(text, kind) {
    this.layer.querySelector(".patternToast")?.remove();
    const t = document.createElement("div");
    t.className = `patternToast t-${kind}`;
    t.textContent = text;
    this.layer.appendChild(t);
  }
}
