/**
 * 💡 權重黑白棋 - 提示分析與候選位置排行榜元件 (Coach View)
 */

import { posToCoord } from "../core/rules.js";
import { tr, escapeHtml } from "../i18n.js";

export class CoachView {
  constructor({ container, onPreviewMove, onApplyMove }) {
    this.container = container;
    this.onPreviewMove = onPreviewMove;
    this.onApplyMove = onApplyMove;
    this.candidates = [];

    if (this.container) {
      this.container.addEventListener("click", (e) => {
        const btn = e.target.closest("[data-apply]");
        if (btn && this.onApplyMove) { this.onApplyMove(this.candidates[Number(btn.dataset.apply)].move); return; }
        const pv = e.target.closest("[data-previewbtn]");
        if (pv && this.onPreviewMove) this.onPreviewMove(this.candidates[Number(pv.dataset.previewbtn)].move);
      });
      this.container.addEventListener("pointerover", (e) => {
        const row = e.target.closest("[data-preview]");
        if (!row || !this.onPreviewMove) return;
        if (e.relatedTarget && row.contains(e.relatedTarget)) return;
        this.onPreviewMove(this.candidates[Number(row.dataset.preview)].move);
      });
      this.container.addEventListener("pointerout", (e) => {
        const row = e.target.closest("[data-preview]");
        if (!row || !this.onPreviewMove) return;
        if (e.relatedTarget && row.contains(e.relatedTarget)) return;
        this.onPreviewMove(null);
      });
    }
  }

  render(candidates = [], isThinking = false, emptyMessage = null) {
    if (!this.container) return;
    this.candidates = candidates;

    if (isThinking) {
      this.container.innerHTML = `
        <div class="coachThinking">
          <div class="spinner"></div>
          <div><b>${tr("coachThinking")}</b><br><span style="font-size:12px; color:#94a3b8;">${tr("coachThinkingSub")}</span></div>
        </div>`;
      return;
    }

    if (!candidates || candidates.length === 0) {
      this.container.innerHTML = `
        <div class="coachEmpty">
          <span style="font-size:24px;">💡</span>
          <div>${emptyMessage || tr("coachEmptyDefault")}</div>
        </div>`;
      return;
    }

    const top = candidates[0];
    let html = `
      <div class="coachHeader">
        <div class="coachTitle">${tr("coachTitle")}</div>
        <span class="coachBadge">${tr("coachTop")}</span>
      </div>
      <div class="coachBestMoveCard" data-preview="0">
        <div class="coachBestMoveRow">
          <div class="coachMoveCoords">
            <span class="crown">👑</span>
            <span class="moveText">${posToCoord(top.move.r, top.move.c)}</span>
          </div>
          <button class="btn primary small applyBtn" data-apply="0">${tr("applyThis")}</button>
        </div>
        <div class="coachExplanation">
          <div class="explanationSummary">${escapeHtml(top.explanation.summary)}</div>
          <div class="explanationPros">
            ${top.explanation.pros.map(p => `<div class="proItem">✓ ${escapeHtml(p)}</div>`).join("")}
          </div>
          ${top.explanation.cons.length ? `
            <div class="explanationCons">
              ${top.explanation.cons.map(c => `<div class="conItem">⚠️ ${escapeHtml(c)}</div>`).join("")}
            </div>` : ""}
        </div>
      </div>`;

    if (candidates.length > 1) {
      html += `<div class="coachOthersTitle">${tr("coachOthers")}</div><div class="coachCandidateList">`;
      for (let i = 1; i < candidates.length; i++) {
        const cand = candidates[i];
        html += `
          <div class="candidateItem" data-preview="${i}">
            <div class="candidateLeft">
              <span class="candRank">${tr("rank" + (i + 1))}</span>
              <span class="candMove">${posToCoord(cand.move.r, cand.move.c)}</span>
              <span class="coachOtherDesc">${escapeHtml(cand.explanation.summary)}</span>
            </div>
            <div class="candidateRight">
              <button class="btn previewBtn small" data-previewbtn="${i}">${tr("preview")}</button>
              <button class="btn primary small applyBtn" data-apply="${i}">${tr("apply")}</button>
            </div>
          </div>`;
      }
      html += `</div>`;
    }
    this.container.innerHTML = html;
  }
}
