/**
 * 🎴 權重黑白棋 - 抽棋面板 (Hand View)：顯示這回合抽到的棋與袋中剩餘數量
 * 取代原專案的骰子面板。
 */

import { BLACK } from "../core/constants.js";
import { blackWeight, whiteWeight } from "../core/rules.js";
import { tr } from "../i18n.js";
import { discHtml, discHtmlFive } from "./board-view.js";
import { valueOf, discLabel } from "../core/five-rules.js";

export class HandView {
  constructor({ widget, valLabel, bagLabel, modeLabel }) {
    this.widget = widget;       // #handWidget
    this.valLabel = valLabel;   // #sideDiceValLabel
    this.bagLabel = bagLabel;   // #handBagLabel
    this.modeLabel = modeLabel; // #handModeLabel（加分模式的加分表）
  }

  /**
   * @param {{hand:number|null, face:number, bagSize:number, gameOver:boolean, bonusPoints:object|null}} s
   */
  render({ hand, face, bagSize, gameOver, bonusPoints = null, variant = "classic" }) {
    const five = variant === "five" || variant === "fivePlain";
    const plain = variant === "fivePlain";
    if (this.widget) {
      this.widget.classList.toggle("empty", hand == null);
      this.widget.innerHTML = hand == null
        ? `<span class="handPlaceholder">?</span>`
        : `<div class="handCell">${five ? discHtmlFive(hand, face, "", plain) : discHtml(hand, face)}</div>`;
    }
    if (this.valLabel) {
      if (gameOver) this.valLabel.textContent = tr("handEnded");
      else if (hand == null) this.valLabel.textContent = tr("handNone");
      else if (plain) this.valLabel.textContent = tr("handFivePlain", { disc: discLabel(hand, true) });
      else if (five) this.valLabel.textContent = tr("handFive", { disc: discLabel(hand, false), v: valueOf(hand) });
      else this.valLabel.textContent = tr("handUp", { n: face === BLACK ? blackWeight(hand) : whiteWeight(hand) });
    }
    if (this.bagLabel) this.bagLabel.textContent = tr("handBag", { n: bagSize });
    if (this.modeLabel) this.modeLabel.textContent = bonusPoints ? tr("handMode", bonusPoints) : "";
  }
}
