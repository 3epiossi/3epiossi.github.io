/**
 * ♟️ 權重黑白棋 - 棋盤視覺渲染元件 (Board View)
 * 每顆棋顯示朝上那面的大數字，右下角圈起來的小數字是背面的權重（圈的顏色就是背面的顏色）。
 */

import { N, BLACK } from "../core/constants.js";
import { posToCoord, inBounds, blackWeight, whiteWeight } from "../core/rules.js";
import { tr } from "../i18n.js";
import { leftOf, rightOf, valueOf, symbolOf, discLabel } from "../core/five-rules.js";

/**
 * 五連類的棋：左右兩個符號並排（兩面相同），顏色代表歸誰。
 * 加權五連顯示「7×8」（分數 = 左 × 右）；五連（plain）顯示「G|H」，避免讓人聯想到權重。
 */
export function discHtmlFive(id, face, extraClass = "", plain = false) {
  const cls = face === BLACK ? "black" : "white";
  return `<div class="disc fDisc ${cls} ${plain ? "plain" : "times"} ${extraClass}">` +
    `<span class="fn">${symbolOf(leftOf(id), plain)}</span><span class="fsep">${plain ? "|" : "×"}</span>` +
    `<span class="fn">${symbolOf(rightOf(id), plain)}</span></div>`;
}

/** 一顆棋的 HTML：face 朝上的顏色，大字是朝上權重，右下角圈起來的小數字是背面權重 */
export function discHtml(id, face, extraClass = "") {
  const up = face === BLACK ? blackWeight(id) : whiteWeight(id);
  const down = face === BLACK ? whiteWeight(id) : blackWeight(id);
  const cls = face === BLACK ? "black" : "white";
  return `<div class="disc wDisc ${cls} ${extraClass}"><span class="dw">${up}</span><span class="dchip">${down}</span></div>`;
}

export class BoardView {
  constructor({ boardContainer, onCellClick, onCellHover }) {
    this.variant = "classic";
    this.boardEl = boardContainer;
    this.onCellClick = onCellClick;
    this.onCellHover = onCellHover;
    this.flipped = false;
    this.cellElements = Array.from({ length: N }, () => Array(N).fill(null));
    this.prevKeys = Array.from({ length: N }, () => Array(N).fill(""));
    this.initDOM();
  }

  setFlipped(flipped) {
    this.flipped = !!flipped;
    for (let r = 0; r < N; r++) {
      for (let c = 0; c < N; c++) {
        const el = this.cellElements[r][c];
        el.style.gridRow = this.flipped ? String(N - r) : "";
        el.style.gridColumn = this.flipped ? String(N - c) : "";
      }
    }
    const cols = "ABCDEFGH".split(""), rows = "12345678".split("");
    if (this.flipped) { cols.reverse(); rows.reverse(); }
    document.querySelector(".coordTop")?.replaceChildren(...cols.map(x => Object.assign(document.createElement("span"), { textContent: x })));
    document.querySelector(".coordLeft")?.replaceChildren(...rows.map(x => Object.assign(document.createElement("span"), { textContent: x })));
  }

  initDOM() {
    this.boardEl.innerHTML = "";
    for (let r = 0; r < N; r++) {
      for (let c = 0; c < N; c++) {
        const cell = document.createElement("div");
        cell.className = "cell";
        cell.dataset.r = r;
        cell.dataset.c = c;
        cell.setAttribute("role", "button");
        cell.setAttribute("tabindex", "0");
        cell.setAttribute("aria-label", tr("cellEmpty", { c: posToCoord(r, c) }));
        this.boardEl.appendChild(cell);
        this.cellElements[r][c] = cell;
      }
    }

    const pick = (e) => {
      const cell = e.target.closest(".cell");
      if (!cell) return null;
      const r = Number(cell.dataset.r), c = Number(cell.dataset.c);
      return inBounds(r, c) ? { r, c, cell } : null;
    };
    this.boardEl.addEventListener("click", (e) => {
      const p = pick(e);
      if (p && this.onCellClick) this.onCellClick(p.r, p.c);
    });
    this.boardEl.addEventListener("keydown", (e) => {
      if (e.key !== "Enter" && e.key !== " ") return;
      const p = pick(e);
      if (!p) return;
      e.preventDefault();
      if (this.onCellClick) this.onCellClick(p.r, p.c);
    });
    const hover = (isEnter) => (e) => {
      const p = pick(e);
      if (!p || !this.onCellHover) return;
      if (e.relatedTarget && p.cell.contains(e.relatedTarget)) return;
      this.onCellHover(p.r, p.c, isEnter);
    };
    this.boardEl.addEventListener("pointerover", hover(true));
    this.boardEl.addEventListener("pointerout", hover(false));
  }

  /**
   * @param {object} p
   * @param {Array}  p.board 棋盤
   * @param {Map<string,object>} p.legalMoves "r,c" → { gain, bonus, flips }，可落子位置、預計權重得分與加分
   * @param {object|null} p.lastMove 最後一手
   * @param {Array}  p.activeAiHints AI 教練候選 [{move}]
   * @param {object|null} p.previewGhostMove 預覽中的候選（顯示半透明棋）
   * @param {{id:number, face:number}|null} p.ghostDisc 預覽用的棋（手上那顆）
   */
  render({ board, legalMoves = new Map(), lastMove = null, activeAiHints = [], previewGhostMove = null, ghostDisc = null, variant = "classic" }) {
    const five = variant === "five" || variant === "fivePlain";
    const plain = variant === "fivePlain";
    const drawDisc = five ? (id, face, extra) => discHtmlFive(id, face, extra, plain) : discHtml;
    // 換模式時棋子畫法不同：清掉快取，避免誤判成翻面動畫
    if (variant !== this.variant) { this.variant = variant; for (const row of this.prevKeys) row.fill(""); }
    const lastKey = lastMove && lastMove.r != null ? `${lastMove.r},${lastMove.c}` : null;

    for (let r = 0; r < N; r++) {
      for (let c = 0; c < N; c++) {
        const cell = this.cellElements[r][c];
        const d = board[r][c];
        const key = `${r},${c}`;
        const coord = posToCoord(r, c);

        cell.className = "cell";
        cell.innerHTML = "";

        if (d) {
          const sig = `${d.id}:${d.face}`;
          const prev = this.prevKeys[r][c];
          let anim = "";
          if (prev !== sig) {
            if (!prev) anim = "drop";
            else if (prev.split(":")[0] === String(d.id)) anim = "flip";
          }
          this.prevKeys[r][c] = sig;
          cell.innerHTML = drawDisc(d.id, d.face, anim);
          cell.setAttribute("aria-label", five
            ? tr(plain ? "cellDiscFivePlain" : "cellDiscFive", { c: coord, side: tr(d.face === BLACK ? "black" : "white"), disc: discLabel(d.id, plain), v: valueOf(d.id) })
            : tr("cellDisc", {
              c: coord,
              side: tr(d.face === BLACK ? "black" : "white"),
              up: d.face === BLACK ? blackWeight(d.id) : whiteWeight(d.id),
              down: d.face === BLACK ? whiteWeight(d.id) : blackWeight(d.id)
            }));
        } else {
          this.prevKeys[r][c] = "";
          cell.setAttribute("aria-label", tr("cellEmpty", { c: coord }));
        }

        const legal = legalMoves.get(key);
        if (legal && !d) {
          cell.classList.add("dest-spawn");
          const badge = document.createElement("span");
          if (legal.five) {
            // 五連模式：這一步直接連成五條
            badge.className = "stepBadge bonus";
            badge.textContent = "★5";
          } else {
            badge.className = legal.bonus > 0 ? "stepBadge bonus" : "stepBadge";
            const total = legal.gain + (legal.bonus || 0);
            badge.textContent = `${total >= 0 ? "+" : ""}${total}${legal.bonus > 0 ? "🃏" : ""}`;
          }
          cell.appendChild(badge);
          cell.setAttribute("aria-label", tr("cellLegal", { c: coord, n: legal.flips.length }));
        }

        if (lastKey === key) cell.classList.add("lastMove");

        const rank = activeAiHints.findIndex(h => h.move.r === r && h.move.c === c);
        if (rank >= 0) {
          cell.classList.add("ai-recommended");
          const badge = document.createElement("span");
          badge.className = "aiRankBadge";
          badge.textContent = ["👑", "🥈", "🥉"][rank] || "";
          cell.appendChild(badge);
        }

        if (previewGhostMove && previewGhostMove.r === r && previewGhostMove.c === c && ghostDisc && !d) {
          cell.classList.add("ghost-dest");
          cell.insertAdjacentHTML("afterbegin", drawDisc(ghostDisc.id, ghostDisc.face, "ghost"));
        }
      }
    }
  }
}
