/**
 * ⚖️ 五連黑白棋 (Five-in-a-Row Othello) - 核心遊戲引擎 (Game Engine)
 * 遵循單一真相來源 (Single Source of Truth)：棋盤、輪次、公開池子都存在這裡，
 * 並透過對局樹記錄每一手，以支援時光機與分支。
 *
 * 公開池子（pool）：從袋子抽 POOL_SIZE 顆攤開，雙方都看得到。輪到的人從池子挑一顆、下在合法位置，
 * 下完從袋子補一顆，補在被挑走的那個位置（其他棋不移動）。沒有合法位置時跳過本回合（PASS），池子不變。
 * hand = 目前選中、準備要下的那顆（介面選擇用；預設是池子第一顆）。
 *
 * 規則為五連：棋子有左右兩個字母（A～H）、兩面相同，連成五連直接獲勝，否則比棋子數（core/five-rules.js）。
 */

import { msg } from "../i18n.js";
import { BLACK, WHITE, MOVE_TYPE, POOL_SIZE } from "./constants.js";
import {
  opp,
  cloneBoard,
  cloneMove,
  createInitialBoard,
  remainingBag,
  getLegalMoves,
  hasLegalMove,
  applyMoveToBoard,
  isBoardFull,
  posToCoord
} from "./rules.js";
import { GameTree } from "../history/game-tree.js";
import { findFive, fiveScores } from "./five-rules.js";

export class GameEngine {
  /**
   * @param {object} options
   * @param {() => number} [options.rng] 亂數來源（測試可注入固定種子）
   */
  constructor(options = {}) {
    this.rng = options.rng || Math.random;
    this.blackPlayerType = options.blackPlayerType || "human";
    this.whitePlayerType = options.whitePlayerType || "cpu";

    this.board = null;
    this.currentTurn = BLACK;
    this.pool = [];     // 公開池子裡的棋 id
    this.selected = null; // 選中準備要下的棋（不在池子裡時視為池子第一顆）
    this.gameOver = false;
    this.lastMove = null;
    this.settlementData = null;
    this.tree = null;
    this.listeners = new Set();

    this.#newPosition();
  }

  subscribe(listener) {
    this.listeners.add(listener);
    return () => this.listeners.delete(listener);
  }

  notify(event, payload) {
    for (const listener of this.listeners) {
      try {
        listener(event, payload, this.getState());
      } catch (err) {
        console.error("GameEngine listener error:", err);
      }
    }
  }

  getState() {
    return {
      board: cloneBoard(this.board),
      currentTurn: this.currentTurn,
      hand: this.hand,
      pool: [...this.pool],
      gameOver: this.gameOver,
      lastMove: this.lastMove ? cloneMove(this.lastMove) : null,
      settlementData: this.settlementData ? { ...this.settlementData } : null,
      blackPlayerType: this.blackPlayerType,
      whitePlayerType: this.whitePlayerType,
      currentNode: this.tree ? this.tree.getCurrentNode() : null
    };
  }

  /** 目前選中準備要下的棋；終局或池子空了是 null */
  get hand() {
    if (this.gameOver || this.pool.length === 0) return null;
    return this.pool.includes(this.selected) ? this.selected : this.pool[0];
  }

  /** 選擇要下的棋（必須在池子裡） */
  selectDisc(id) {
    if (!this.pool.includes(id) || id === this.hand) return false;
    this.selected = id;
    this.notify("SELECTION_CHANGED", { id });
    return true;
  }

  /** 袋子：還沒上盤、也不在池子裡的棋 */
  bagIds() {
    const held = new Set(this.pool);
    return remainingBag(this.board).filter(id => !held.has(id));
  }

  /** 從袋子隨機抽一顆（不改變任何狀態，只回傳 id） */
  drawFromBag() {
    const bag = this.bagIds();
    if (bag.length === 0) return null;
    return bag[Math.floor(this.rng() * bag.length)];
  }

  /** 從袋子把池子補滿（袋子空了就停）。at = 剛被挑走的那顆原本的位置：新抽的棋補在那個空位，其他棋不動 */
  #refillPool(at = null) {
    while (this.pool.length < POOL_SIZE) {
      const id = this.drawFromBag();
      if (id == null) break;
      if (at != null && at <= this.pool.length) { this.pool.splice(at, 0, id); at = null; }
      else this.pool.push(id);
    }
  }

  bagSize() {
    return this.bagIds().length;
  }

  legalMoves() {
    return this.gameOver ? [] : getLegalMoves(this.board, this.currentTurn);
  }

  findLegalMove(r, c) {
    return this.legalMoves().find(m => m.r === r && m.c === c) || null;
  }

  // 開新局面：標準開局，四顆起始棋由袋子隨機抽出
  #newPosition() {
    const taken = new Set();
    const drawInitial = () => {
      let id;
      do { id = Math.floor(this.rng() * 64); } while (taken.has(id));
      taken.add(id);
      return id;
    };
    this.board = createInitialBoard(drawInitial);
    this.currentTurn = BLACK;
    this.gameOver = false;
    this.lastMove = null;
    this.settlementData = null;
    this.pool = [];
    this.#refillPool();
    this.selected = this.pool[0] ?? null;
    if (this.tree) this.tree.init(this.board, this.currentTurn, this.pool);
    else this.tree = new GameTree(this.board, this.currentTurn, this.pool);
  }

  /** 開新局 */
  resetGame() {
    this.#newPosition();
    this.notify("GAME_RESET");
  }

  /**
   * 執行走步：把池子裡的 discId（預設是選中的那顆）下在 (r, c)。朝上的顏色就是下棋者的顏色。
   */
  executeMove(r, c, discId = this.hand) {
    if (this.gameOver || discId == null || !this.pool.includes(discId)) return false;

    // REVIEW 狀態（非分支最新端點）不允許直接落子，須透過「從這裡開始下」建立新分支
    const tip = this.tree.getBranchTipNode();
    const curr = this.tree.getCurrentNode();
    if (curr && tip && curr.id !== tip.id) return false;

    const move = this.findLegalMove(r, c);
    if (!move) return false;

    const player = this.currentTurn;
    const placedId = discId;
    
    this.board = applyMoveToBoard(this.board, move, placedId, player);
    this.lastMove = {
      type: MOVE_TYPE.PLACE, player, r, c, discId: placedId,
      flips: move.flips.map(f => [...f])
    };
    this.vacantSlot = this.pool.indexOf(placedId); // 下完從袋子補的棋放回這個位置
    this.pool = this.pool.filter(id => id !== placedId);

    // 連成五連直接獲勝（翻面造成的也算）
    const five = findFive(this.board, player);
    const fiveText = five ? msg("logFive", { v: { $sym: five.value } }) : "";

    const logText = msg("logMove", {
      idx: (curr ? curr.stepIdx : 0) + 1,
      side: msg(player === BLACK ? "sideBlack" : "sideWhite"),
      to: posToCoord(r, c),
      disc: { $disc: placedId },
      n: move.flips.length,
      five: fiveText
    });
    if (five) {
      this.lastMove.five = five;
      this.#finishByFive(player, five, logText);
    } else {
      this.#advance(opp(player), logText, this.lastMove);
    }
    this.notify("MOVE_EXECUTED", { move: this.lastMove, gameOver: this.gameOver });
    if (this.gameOver) this.notify("GAME_OVER", this.settlementData);
    return true;
  }

  /** 雙方目前的分數（每顆 1 分）與棋子數 */
  scores() {
    return { ...fiveScores(this.board, false), ...this.#discCounts() };
  }

  #discCounts() {
    let blackCount = 0, whiteCount = 0;
    for (const row of this.board) for (const d of row) if (d) { if (d.face === BLACK) blackCount++; else whiteCount++; }
    return { blackCount, whiteCount };
  }

  /** 五連獲勝：立刻結束，記錄在對局樹 */
  #finishByFive(player, five, logText) {
    const sc = this.scores();
    this.gameOver = true;
    this.settlementData = {
      ...sc,
      winner: player,
      diff: Math.abs(sc.black - sc.white),
      totalBlack: sc.black,
      totalWhite: sc.white,
      byFive: true,
      five,
      reason: msg("reasonFive", { side: msg(player === BLACK ? "sideBlack" : "sideWhite"), v: { $sym: five.value } })
    };
    this.tree.appendMoveNode({
      turn: this.currentTurn,
      pool: this.pool,
      move: this.lastMove,
      board: this.board,
      gameOver: true,
      settlementData: this.settlementData,
      logText
    });
  }

  /** PASS：抽到的棋放回袋子，輪到對手並重新抽棋 */
  passTurn() {
    if (this.gameOver) return false;
    const player = this.currentTurn;
    this.lastMove = { type: MOVE_TYPE.PASS, player, flips: [] };

    const logText = msg("logPass", {
      side: msg(player === BLACK ? "sideBlack" : "sideWhite"),
      enemy: msg(player === BLACK ? "sideWhite" : "sideBlack")
    });
    this.#advance(opp(player), logText, this.lastMove);
    this.notify("PASS_EXECUTED", { player, gameOver: this.gameOver });
    if (this.gameOver) this.notify("GAME_OVER", this.settlementData);
    return true;
  }

  // 輪到 next：判斷終局、抽棋、必要時要求 PASS，並寫入對局樹
  #advance(next, logText, move) {
    let over = false;
    if (isBoardFull(this.board) || (!hasLegalMove(this.board, next) && !hasLegalMove(this.board, opp(next)))) {
      over = true;
    }
    // 下完從袋子補一顆（PASS 時池子不變）
    if (move.type === MOVE_TYPE.PLACE) this.#refillPool(this.vacantSlot);
    this.selected = this.pool[0] ?? null;
    this.currentTurn = next;
    if (over) {
      this.gameOver = true;
      this.settlementData = this.#settle();
    }

    this.tree.appendMoveNode({
      turn: this.currentTurn,
      pool: this.pool,
      move,
      board: this.board,
      gameOver: this.gameOver,
      settlementData: this.settlementData,
      logText
    });

    if (!over && !hasLegalMove(this.board, this.currentTurn)) {
      this.notify("PASS_REQUIRED", { player: this.currentTurn });
    }
  }

  /** 終局結算：比棋子數，多者勝 */
  #settle() {
    const reason = msg(isBoardFull(this.board) ? "reasonFull" : "reasonNoMoves");
    const sc = this.scores();
    return {
      ...sc, reason, totalBlack: sc.black, totalWhite: sc.white,
      winner: sc.black === sc.white ? 0 : (sc.black > sc.white ? BLACK : WHITE),
      diff: Math.abs(sc.black - sc.white)
    };
  }

  /** 從歷史節點開闢全新分支並跳轉到該節點（唯一建立分支的入口） */
  startFromHere(nodeId, customBranchName = null) {
    const node = this.tree.getNode(nodeId);
    if (!node) return false;

    let name = customBranchName;
    if (!name) {
      let dupe = 0;
      for (const b of this.tree.branches.values()) {
        if (b.name && b.name.k && b.name.p && b.name.p.n === node.stepIdx) dupe++;
      }
      name = dupe === 0
        ? msg("branchFrom", { n: node.stepIdx })
        : msg("branchFromDup", { n: node.stepIdx, dup: dupe + 1 });
    }
    this.tree.createBranchFromNode(nodeId, name);
    this.jumpToNode(nodeId);
    return true;
  }

  /**
   * 下一步，不論是不是在最新局面：
   *   在主線的歷史某一步下 → 從這一步開一條分支（只保留一條分支，舊的分支會被刪掉）
   *   在分支的歷史某一步下 → 這一步之後的分支內容換成新的這一步
   */
  playMove(r, c, discId = this.hand) {
    if (this.gameOver || !this.findLegalMove(r, c) || !this.pool.includes(discId)) return false;
    const tree = this.tree;
    const curr = tree.getCurrentNode();
    const tip = tree.getBranchTipNode();
    if (curr && tip && curr.id !== tip.id) {
      if (tree.activeBranchId === "main") {
        for (const id of [...tree.branches.keys()]) if (id !== "main") tree.deleteBranch(id);
        tree.createBranchFromNode(curr.id, msg("branchFrom", { n: curr.stepIdx }));
      } else {
        tree.truncateAfter(curr.id);
      }
    }
    return this.executeMove(r, c, discId);
  }

  /** 讀回存檔的對局樹（GameTree.toJSON 的結果），停在存檔時看的那一步；格式不對會丟出錯誤，原本的局面不變 */
  restoreTree(data) {
    const tree = GameTree.fromJSON(data);
    this.tree = tree;
    return this.jumpToNode(tree.currentNodeId);
  }

  /** 目前這一步變成最新一步：這條線到這一步設成正式棋譜，之後的棋與分支都刪掉，可以直接接著下 */
  makeCurrentLatest() {
    const curr = this.tree.getCurrentNode();
    if (!curr || curr.gameOver) return false;
    if (!this.tree.promoteLineTo(curr.id)) return false;
    return this.jumpToNode(curr.id);
  }

  /** 目前這條線（主線，或主線到分岔點＋分支）上第 step 步的節點 */
  lineNodeAt(step) {
    return this.tree.getBranchHistory()[step] || null;
  }

  /**
   * 跳到目前這條線的第 step 步。
   * 正在看分支、又退回分岔那一步或更早：分支消失，回到主線。
   */
  goToStep(step) {
    const tree = this.tree;
    const branch = tree.branches.get(tree.activeBranchId);
    if (tree.activeBranchId !== "main" && branch && step <= branch.forkStepIdx) {
      tree.deleteBranch(tree.activeBranchId);
      tree.activeBranchId = "main";
    }
    const node = this.lineNodeAt(step);
    return node ? this.jumpToNode(node.id) : false;
  }

  jumpToNode(nodeId) {
    const node = this.tree.getNode(nodeId);
    if (!node) return false;
    this.tree.currentNodeId = node.id;
    this.board = cloneBoard(node.board);
    this.currentTurn = node.turn;
    this.pool = [...node.pool];
    this.selected = this.pool[0] ?? null;
    this.gameOver = node.gameOver;
    this.lastMove = node.move ? cloneMove(node.move) : null;
    this.settlementData = node.settlementData ? { ...node.settlementData } : null;
    this.notify("STATE_RESTORED", { node });
    return true;
  }
}
