/**
 * 📖 使用說明（「說明」視窗的第二個分頁）：畫面、操作、威脅連線、勝率、走法標記、AI 教練、設定。
 * 內容較長，所以不放在 i18n.js；各語言一份 HTML。走法標記的色塊與棋盤上的標記同色（見 win-chart.js 的 MARK_COLOR）。
 */

const MARK = { "!!": "#1baca6", "!": "#22a06b", "!?": "#4f8cdb", "?!": "#ca8a04", "?": "#f59e0b", "??": "#dc2626" };
const badge = (sym) => `<span class="helpMark" style="background:${MARK[sym]}">${sym}</span>`;
const kbd = (k) => `<kbd>${k}</kbd>`;
const section = (title, body) => `<section class="helpSection"><h3>${title}</h3>${body}</section>`;
const markTable = (rows) => `<table class="helpMarks">${rows.map(([s, name, text]) => `<tr><td>${badge(s)}</td><td><b>${name}</b></td><td>${text}</td></tr>`).join("")}</table>`;

const ZH = [
  section("畫面", `<ul>
    <li><b>玩家卡</b>（棋盤上方）：名稱、「我」或「CPU 幾級」、目前的棋子數。輪到誰，誰的卡會亮起來。點「我 ▾ / CPU ▾」可以切換由你下或交給 CPU，以及 CPU 的難度（1～7 級，越高越強）；點名稱可以改名。</li>
    <li><b>勝率條</b>（棋盤左邊）：白方在上、黑方在下，數字是目前局面雙方的勝率。</li>
    <li><b>公開池子</b>（棋盤右邊，手機在下方）：4 顆雙方共用的棋，最下面是袋子裡還剩幾顆。</li>
    <li><b>狀態列</b>：現在輪到誰、該做什麼。左邊的色帶：藍＝輪到你、紫＝CPU 思考中、橘＝暫停或正在看歷史、灰＝棋局結束。</li>
    <li><b>操作列</b>：新局、${kbd("⏮")} ${kbd("◀")} ${kbd("▶")} ${kbd("⏭")}（第一手／上一手／下一手／最新一手）、💡 提示、▶ CPU 對下（雙方都交給 CPU，之後可以暫停或繼續）。手機上這列固定在畫面底部。</li>
    <li><b>勝率走勢</b>（右欄，手機在下方）：整盤棋的勝率變化，見下面「勝率與勝率走勢」。</li>
  </ul>`),
  section("怎麼下", `<ul>
    <li>點有綠點的格子就落子。標 ★5 的格子，下了就直接連成五。</li>
    <li><b>選棋</b>：還沒選棋時，點一下可下的格子，格子上會顯示池子裡的第 1 顆棋（右下角標「1/4」）；再點一下換下一顆，依序循環。<b>按住那一格不放</b>（約半秒，棋子外圍的虛線圈被黃色填滿，同時一根指針順時針掃過，掃過的地方棋子變成不透明、放大並發光）就下目前顯示的那顆；點別的地方（包括其他格子）就不下在這格。也可以先點池子裡的棋（或按 ${kbd("1")}～${kbd("4")}）再點格子；選棋中按 ${kbd("1")}～${kbd("4")} 或點池子，就直接下在那格。<b>開著 💡 提示時</b>：滑鼠移到格子上會預覽這格勝率最高的那顆，點一下格子就直接下那顆（手機上點一下就下）；先從池子選了某顆的話，就用你選的。</li>
    <li><b>快捷鍵</b>：${kbd("1")}～${kbd("4")} 選池子第幾顆、${kbd("←")} ${kbd("→")} 上一手／下一手、${kbd("空白鍵")} 暫停／繼續 CPU、${kbd("H")} 開關提示。</li>
    <li>沒有地方可下時會自動跳過（PASS），池子不變。</li>
  </ul>`),
  section("威脅連線", `<ul>
    <li>同一條直線上出現「三」（3 顆有共同的字，旁邊 2 格空著）或「四」（4 顆，只剩 1 格），會畫出那個字顏色的線，「四」的線比較粗。不分黑白，因為棋子還可能被翻面。</li>
    <li>「四」的缺口（再補一顆就連成五的空格）會畫虛線框，裡面的小棋表示<b>哪一方下在那裡真的能連成五</b>：白棋、黑棋，或半白半黑（雙方都可以）。雙方都連不成的缺口不畫。</li>
    <li>棋子上被用到的那個字會加底線。滑鼠移到某一組，只突顯那一組。</li>
  </ul>`),
  section("勝率與勝率走勢", `<ul>
    <li>勝率是引擎估計的，只是參考。輪到你、還沒下的時候，引擎會繼續往下算，勝率條、提示和走法標記會跟著變得更準。池子每一步會隨機補一顆新棋，所以勝率條下降不一定是你下錯，也可能只是對手補到了好棋。</li>
    <li>勝率走勢：白方在上、黑方在下，每一手一個點；有走法標記的點會用標記的顏色畫大一點。滑鼠移上去可以看那一手的紀錄、標記和原因。</li>
    <li>點圖上任一手就回到那時的局面。在歷史局面直接下棋，會岔出一條分支（分支研究：雙方都由你下）；退回分岔點或更早，分支就結束，回到原本的對局。</li>
    <li>看歷史（或分支研究）時按「<b>從這裡繼續下</b>」：這一步變成最新一步，之後的棋譜刪掉，座位換回原本的設定，接著正常下棋。</li>
  </ul>`),
  section("走法標記", `<p>每一手下完，那顆棋的右上角可能出現標記，雙方的棋都會評。滑鼠移到標記上會顯示原因，例如「局勢從優勢變成拉鋸（最佳：E3 ββ）」。</p>
    <p>局勢分五級：<b>勝定</b>、<b>優勢</b>、<b>拉鋸</b>、<b>劣勢</b>、<b>敗定</b>。</p>
    ${markTable([
      ["!!", "妙手", "只有這一步能守住局面（其他每個格子都差 20% 以上），而且很難找。"],
      ["!", "好手", "只有這一步能拿到這個局勢（其他格子都差一級以上），而且不容易看出來。"],
      ["!?", "設陷阱", "差不多是最好的一步，而且下完後，對手一半以上的下法會讓局勢倒向你。"],
      ["?!", "不精確", "局勢等級沒變，但讓掉了不少勝率。"],
      ["?", "失誤", "局勢掉了一級。"],
      ["??", "大漏著", "局勢掉了兩級以上。"]
    ])}
    <ul>
      <li>不標的情況：勝負已經分出來的局面、只有一格可下、直接連成五的那一步、很好找的唯一好步。終盤（剩 7 格以內）只標「對手失手、這步把握機會逆轉」的好棋。</li>
      <li>標記要等更完整的分析確認，通常晚一兩秒出現；偶爾出現後又改變，是因為更準的分析到了。</li>
    </ul>`),
  section("AI 教練（提示）", `<ul>
    <li>按「💡 提示」打開。每個可下的格子會顯示「這格配池子裡最好的那顆棋」的勝率，最高的那格有框。</li>
    <li>滑鼠移到格子上，池子裡每顆棋旁邊會顯示它下在這格的勝率。點池子的棋可以固定看那一顆在各格的勝率。</li>
    <li>數字很淡表示還在算；你還在想的時候引擎會繼續往下算，算得夠深（約 3 倍思考時間）數字就會變清楚，之後也可能小幅更新。</li>
    <li>教練的思考時間是「AI 思考時間」的兩倍，跟 7 級 CPU 差不多強。開著提示時，CPU 落子之前就會先替你算，所以通常很快出現。</li>
  </ul>`),
  section("設定", `<ul>
    <li><b>AI 思考時間</b>：越長越準，但要等比較久。7 級 CPU 每步想這麼久，勝率條至少分析這麼久，AI 教練用兩倍的時間。1～6 級 CPU 不受影響。</li>
    <li><b>下棋節奏</b>：CPU 落子的快慢（慢／正常／快／極速），只影響看起來的速度，不影響棋力和分析。極速不播動畫和落子音效，適合快轉看結果。CPU 對下時切到別的分頁會自動暫停。</li>
    <li><b>遊戲音效</b>、<b>雙方名稱</b>、<b>棋盤主題</b>。</li>
    <li><b>棋子文字</b>：預設是希臘字母 α～θ（不跟棋盤座標 A～H 混淆），也可以自訂 8 個不同的字（中文、英文、日文都行）。</li>
    <li><b>棋子顏色與文字顏色</b>：黑白棋子各自的寶石顏色，以及棋上文字的顏色。「還原預設外觀」可以全部改回來。</li>
  </ul>`),
  section("其他", `<ul>
    <li><b>匯出棋譜</b>（勝率走勢右上角）：把目前這條線存成 JSON 檔，裡面有每一手的局面、走法標記和勝率。</li>
    <li><b>自動存檔</b>：對局（包括分支）會存在這個瀏覽器裡，重新整理或關掉頁面再打開，會接著上次的局面。按「新局」才會清掉。</li>
    <li><b>語言</b>：右上角可以切換中文、English、日本語。</li>
    <li>設定會記在這台電腦的瀏覽器裡；對局本身不會保存，重新整理頁面會開新局。</li>
    <li>頁尾有另一個遊戲「誰會贏？」。</li>
  </ul>`)
];

const EN = [
  section("The screen", `<ul>
    <li><b>Player cards</b> (above the board): name, "Me" or "CPU level", and disc count. The card of the side to move lights up. Click "Me ▾ / CPU ▾" to switch between playing yourself and letting the CPU play, and to set the CPU level (1–7, higher is stronger); click a name to rename it.</li>
    <li><b>Win bar</b> (left of the board): White on top, Black at the bottom, with each side's current win chance.</li>
    <li><b>Open pool</b> (right of the board, below it on phones): the 4 discs both sides share, plus how many are left in the bag.</li>
    <li><b>Status line</b>: whose turn it is and what to do. The colour on the left: blue = your turn, purple = CPU thinking, orange = paused or viewing history, grey = game over.</li>
    <li><b>Action bar</b>: New game, ${kbd("⏮")} ${kbd("◀")} ${kbd("▶")} ${kbd("⏭")} (first / previous / next / latest move), 💡 Hints, ▶ CPU vs CPU (pause and resume afterwards). On phones it stays at the bottom of the screen.</li>
    <li><b>Win-chance chart</b> (right column, below on phones): see "Win chance and the chart" below.</li>
  </ul>`),
  section("Playing", `<ul>
    <li>Click a square with a green dot to play there. A square marked ★5 makes five in a row straight away.</li>
    <li><b>Choosing a disc</b>: without a chosen disc, click a playable square and it previews the first pool disc (marked “1/4” in the corner); click again for the next one, cycling round. <b>Press and hold</b> that square (about half a second; the dashed circle around the disc fills up in yellow while a sweeping hand makes the disc opaque, bigger and glowing as it passes) to play the disc shown; click anywhere else (including another square) to cancel. You can also click a pool disc first (or press ${kbd("1")}–${kbd("4")}) and then a square; while trying discs, pressing ${kbd("1")}–${kbd("4")} or clicking a pool disc plays it there. <b>With 💡 Hints on</b>: hovering a square previews its best disc and a single click plays it (a single tap on a phone); if you picked a pool disc first, that one is used.</li>
    <li><b>Shortcuts</b>: ${kbd("1")}–${kbd("4")} pick a pool disc, ${kbd("←")} ${kbd("→")} previous / next move, ${kbd("Space")} pause / resume the CPU, ${kbd("H")} toggle hints.</li>
    <li>With no legal move you pass automatically; the pool stays the same.</li>
  </ul>`),
  section("Threat lines", `<ul>
    <li>A "three" (3 discs sharing a symbol with 2 empty squares) or a "four" (4 discs, 1 empty square) on a line is drawn in that symbol's colour; fours are thicker. Colours are ignored because discs can still be flipped.</li>
    <li>The gap of a four (the empty square that would complete five) gets a dashed box, and the small disc inside shows <b>which side can really make five there</b>: White, Black, or half and half (both). Gaps nobody can complete are not drawn.</li>
    <li>The symbol a disc contributes is underlined. Hover a group to highlight just that group.</li>
  </ul>`),
  section("Win chance and the chart", `<ul>
    <li>Win chances are the engine's estimate and only a guide. While it is your turn and you are still thinking, the engine keeps analysing, so the bar, hints and move marks become more accurate. A random disc refills the pool after every move, so a drop in the bar is not always your mistake; the opponent may simply have drawn a good disc.</li>
    <li>The chart shows White on top and Black at the bottom, one dot per move; moves with a mark get a larger dot in the mark's colour. Hover to see the move, its mark and the reason.</li>
    <li>Click any move to go back to it. Playing a move from a past position starts a branch (study mode: you play both sides); going back to the fork or earlier ends the branch and returns to the game.</li>
    <li>While viewing history (or studying a branch), press "<b>Continue from here</b>": this move becomes the latest, later moves are deleted, the seats go back to your settings, and the game carries on normally.</li>
  </ul>`),
  section("Move marks", `<p>After each move a mark may appear at the disc's top-right corner, for both sides. Hover it to see why, e.g. "Position went from ahead to balanced (best: E3 ββ)".</p>
    <p>Positions come in five levels: <b>won</b>, <b>ahead</b>, <b>balanced</b>, <b>behind</b>, <b>lost</b>.</p>
    ${markTable([
      ["!!", "Brilliant", "The only move that holds the position (every other square is at least 20% worse), and hard to find."],
      ["!", "Good", "The only move that reaches this level (every other square is a level worse), and not easy to see."],
      ["!?", "Trap", "About as good as the best move, and afterwards more than half of the opponent's replies turn the game your way."],
      ["?!", "Inaccuracy", "Same level, but a fair amount of win chance given away."],
      ["?", "Mistake", "The position drops one level."],
      ["??", "Blunder", "The position drops two levels or more."]
    ])}
    <ul>
      <li>No mark when: the game is already decided, there is only one legal square, the move makes five, or the only good move is easy to find. In the endgame (7 or fewer empty squares) only comebacks after the opponent's slip are marked as good moves.</li>
      <li>Marks wait for a more thorough analysis, so they usually appear a second or two later; occasionally a mark changes once a more accurate analysis arrives.</li>
    </ul>`),
  section("AI coach (hints)", `<ul>
    <li>Press "💡 Hints". Each legal square shows the win chance of its best pool disc; the best square is outlined.</li>
    <li>Hover a square to see each pool disc's win chance there. Click a pool disc to see that disc's win chance on every square.</li>
    <li>Faint numbers are still being worked out. The engine keeps going while you think, and the numbers turn solid once it has gone deep enough (about 3× the thinking time); they may still update slightly afterwards.</li>
    <li>The coach thinks for twice the AI thinking time, so it is about as strong as the Level 7 CPU. With hints on it starts working on your position before the CPU's move lands, so hints usually appear quickly.</li>
  </ul>`),
  section("Settings", `<ul>
    <li><b>AI thinking time</b>: longer is more accurate but slower. The Level 7 CPU thinks this long per move, the win bar analyses at least this long, and the AI coach uses twice as long. Levels 1–6 are not affected.</li>
    <li><b>Game pace</b>: how quickly the CPU plays (slow / normal / fast / instant). It only changes how fast things look, not strength or analysis. Instant skips animations and stone sounds, handy for fast-forwarding. CPU vs CPU pauses itself when you switch to another tab.</li>
    <li><b>Sound</b>, <b>player names</b>, <b>board theme</b>.</li>
    <li><b>Symbols on the discs</b>: Greek letters α–θ by default (so they don't clash with the A–H board coordinates), or any 8 different characters of your own.</li>
    <li><b>Disc and symbol colours</b>: a gem colour for each side and the colour of the symbols on them. "Restore defaults" brings back the default look.</li>
  </ul>`),
  section("Other", `<ul>
    <li><b>Export record</b> (top right of the chart): saves the current line as a JSON file with every position, move mark and win chance.</li>
    <li><b>Auto-save</b>: the game (including branches) is kept in this browser. Reload or reopen the page and you continue where you left off. Only “New game” clears it.</li>
    <li><b>Language</b>: switch between 中文, English and 日本語 at the top right.</li>
    <li>Settings are kept in this browser; the game itself is not saved, so reloading the page starts a new game.</li>
    <li>Another game, "Who will win?", is linked at the bottom of the page.</li>
  </ul>`)
];

const JA = [
  section("画面", `<ul>
    <li><b>プレイヤーカード</b>（盤の上）：名前、「自分」または「CPU のレベル」、石の数。手番の側のカードが光ります。「自分 ▾ / CPU ▾」をクリックすると、自分で打つか CPU に任せるか、CPU の強さ（1～7、高いほど強い）を切り替えられます。名前をクリックすると名前を変えられます。</li>
    <li><b>勝率バー</b>（盤の左）：白が上、黒が下で、現在の局面の両者の勝率を表示します。</li>
    <li><b>公開プール</b>（盤の右、スマホでは下）：両者共通の 4 枚の石と、袋の残り枚数。</li>
    <li><b>ステータス行</b>：手番とやること。左の色帯：青＝あなたの番、紫＝CPU 思考中、橙＝一時停止中または履歴を表示中、灰＝対局終了。</li>
    <li><b>操作バー</b>：新規対局、${kbd("⏮")} ${kbd("◀")} ${kbd("▶")} ${kbd("⏭")}（最初／1 手戻る／1 手進む／最新）、💡 ヒント、▶ CPU 同士（あとで一時停止・再開できます）。スマホでは画面下に固定されます。</li>
    <li><b>勝率の推移</b>（右の欄、スマホでは下）：下の「勝率と勝率の推移」を参照。</li>
  </ul>`),
  section("打ち方", `<ul>
    <li>緑の点があるマスをクリックすると打てます。★5 のマスは打つとすぐ五連になります。</li>
    <li><b>石の選択</b>：石を選んでいないとき、打てるマスを 1 回クリックするとプールの 1 枚目がプレビューされます（右下に「1/4」）。もう一度クリックで次の石へ（順に循環）。<b>そのマスを長押し</b>（約 0.5 秒、石の周りの点線の円が黄色で満ち、針が時計回りに掃くように石が不透明になり、大きく光ります）すると表示中の石を打ちます。他の場所（他のマスを含む）をクリックするとこのマスには打ちません。先にプールの石をクリック（または ${kbd("1")}～${kbd("4")}）してからマスをクリックしても打てます。試している間に ${kbd("1")}～${kbd("4")} かプールの石をクリックすると、その石をそこに打ちます。<b>💡 ヒントがオンのとき</b>：マスにマウスを乗せるとそのマスで勝率最高の石がプレビューされ、1 回クリックでそれを打ちます（スマホでは 1 回タップ）。先にプールで選んだ石があればそれを使います。</li>
    <li><b>ショートカット</b>：${kbd("1")}～${kbd("4")} プールの石を選ぶ、${kbd("←")} ${kbd("→")} 1 手戻る／進む、${kbd("スペース")} CPU の一時停止／再開、${kbd("H")} ヒントの切り替え。</li>
    <li>打てる場所がないときは自動でパスし、プールはそのままです。</li>
  </ul>`),
  section("脅威ライン", `<ul>
    <li>一直線上に「三」（共通の文字を持つ石 3 枚と空き 2 マス）や「四」（4 枚と空き 1 マス）ができると、その文字の色で線を引きます。四の線は太めです。石はまだ裏返る可能性があるので、白黒は区別しません。</li>
    <li>四の空き（あと 1 枚で五連になるマス）には点線の枠を描き、中の小さな石で<b>どちらがそこに打つと本当に五連になるか</b>を示します：白、黒、または半分ずつ（両方）。どちらも五連にできない空きは描きません。</li>
    <li>石の中で使われている文字には下線が付きます。グループにマウスを乗せると、そのグループだけが強調されます。</li>
  </ul>`),
  section("勝率と勝率の推移", `<ul>
    <li>勝率はエンジンの見積もりで、あくまで目安です。あなたの番で考えている間もエンジンは計算を続けるので、勝率バー・ヒント・評価記号はだんだん正確になります。毎手プールにランダムな石が補充されるので、勝率バーが下がっても悪手とは限りません。相手に良い石が来ただけのこともあります。</li>
    <li>グラフは白が上・黒が下で、1 手に 1 つの点。評価記号の付いた手は、その色で大きめの点になります。マウスを乗せると、その手の記録・記号・理由が見られます。</li>
    <li>グラフの任意の手をクリックするとその局面に戻ります。過去の局面から打つと分岐（研究モード：両方を自分で打つ）になり、分岐点かそれより前に戻ると分岐は終わり、元の対局に戻ります。</li>
    <li>履歴（または分岐の研究）を見ているときに「<b>ここから続ける</b>」を押すと、この手が最新の手になり、以降の棋譜は削除され、席は元の設定に戻って通常の対局を続けます。</li>
  </ul>`),
  section("評価記号", `<p>各手のあと、その石の右上に記号が付くことがあります（両者の手が対象）。記号にマウスを乗せると理由が表示されます。例：「形勢が優勢から互角に（最善：E3 ββ）」。</p>
    <p>形勢は 5 段階です：<b>勝ち確定</b>、<b>優勢</b>、<b>互角</b>、<b>劣勢</b>、<b>負け確定</b>。</p>
    ${markTable([
      ["!!", "妙手", "形勢を保てる唯一の手（他のマスはすべて 20% 以上悪い）で、しかも見つけにくい。"],
      ["!", "好手", "この形勢にできる唯一の手（他のマスはすべて 1 段階以上悪い）で、見つけにくい。"],
      ["!?", "罠", "ほぼ最善で、打ったあと相手の手の半分以上で形勢がこちらに傾く。"],
      ["?!", "緩手", "形勢の段階は変わらないが、勝率をかなり失った。"],
      ["?", "悪手", "形勢が 1 段階下がった。"],
      ["??", "大悪手", "形勢が 2 段階以上下がった。"]
    ])}
    <ul>
      <li>記号を付けない場合：勝敗がすでに決まっている、打てるマスが 1 つだけ、その手で五連になる、唯一の好手でも見つけやすい。終盤（空き 7 マス以内）は「相手のミスを逃さず逆転した」好手だけに付けます。</li>
      <li>記号はより詳しい分析で確認してから付くので、たいてい 1～2 秒遅れて表示されます。より正確な分析が届いて記号が変わることもあります。</li>
    </ul>`),
  section("AI コーチ（ヒント）", `<ul>
    <li>「💡 ヒント」でオン。打てるマスごとに、プールで最善の石を打ったときの勝率を表示し、最も高いマスには枠が付きます。</li>
    <li>マスにマウスを乗せると、プールの各石をそのマスに打ったときの勝率が表示されます。プールの石をクリックすると、その石の各マスでの勝率を固定表示します。</li>
    <li>数字が薄いときはまだ計算中です。考えている間もエンジンは計算を続け、十分深くなると（思考時間の約 3 倍）はっきり表示されます。その後も少し更新されることがあります。</li>
    <li>コーチは「AI の思考時間」の 2 倍で考えるので、レベル7の CPU とほぼ同じ強さです。ヒントがオンのときは CPU が打つ前からあなたの局面を計算し始めるので、たいていすぐに表示されます。</li>
  </ul>`),
  section("設定", `<ul>
    <li><b>AI の思考時間</b>：長いほど正確ですが待ち時間も長くなります。レベル7の CPU は1手にこの時間考え、勝率バーは少なくともこの時間分析し、AI コーチは 2 倍の時間を使います。レベル1～6には影響しません。</li>
    <li><b>対局のテンポ</b>：CPU が石を置く速さ（遅い／標準／速い／最速）。見た目の速さだけが変わり、強さや分析には影響しません。最速はアニメーションと着手音を省くので、早送りに便利です。CPU 同士の対局は別のタブに切り替えると自動で一時停止します。</li>
    <li><b>効果音</b>、<b>両者の名前</b>、<b>盤のテーマ</b>。</li>
    <li><b>石の文字</b>：既定はギリシャ文字 α～θ（盤の座標 A～H と紛れないように）。異なる 8 文字を自分で指定することもできます。</li>
    <li><b>石の色と文字の色</b>：白黒それぞれの宝石の色と、石の上の文字の色。「デフォルトに戻す」で元に戻せます。</li>
  </ul>`),
  section("その他", `<ul>
    <li><b>棋譜を書き出す</b>（勝率の推移の右上）：今の手順を JSON ファイルに保存します。各局面・評価記号・勝率が入っています。</li>
    <li><b>自動保存</b>：対局（分岐を含む）はこのブラウザに保存されます。再読み込みしたりページを開き直したりしても、前回の局面から続けられます。「新規対局」を押したときだけ消えます。</li>
    <li><b>言語</b>：右上で中文・English・日本語を切り替えられます。</li>
    <li>設定はこのブラウザに保存されます。対局そのものは保存されないので、ページを再読み込みすると新しい対局になります。</li>
    <li>ページの下に、もう一つのゲーム「誰が勝つ？」へのリンクがあります。</li>
  </ul>`)
];

const CONTENT = { zh: ZH, en: EN, ja: JA };

/** 目前語言的使用說明 HTML */
export function helpGuideHtml(lang) {
  return (CONTENT[lang] || ZH).join("");
}
