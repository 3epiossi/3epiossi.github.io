/**
 * 🎴 五連黑白棋 - 公開池子面板 (Pool View)：池子裡的棋（雙方都看得到）與袋中剩餘數量。
 * 輪到人類時點一顆棋選擇要下的那顆；能直接連成五的棋標 ★。
 */

import { tr } from "../i18n.js";
import { discHtmlFive } from "./board-view.js";
import { discLabel } from "../core/five-rules.js";

export class PoolView {
  /**
   * @param {object} o
   * @param {HTMLElement} o.widget   #handWidget
   * @param {HTMLElement} o.valLabel #sideDiceValLabel（選中的棋）
   * @param {HTMLElement} o.bagLabel #handBagLabel
   * @param {(id:number) => void} o.onSelect 點選池子裡的棋
   */
  constructor({ widget, valLabel, bagLabel, onSelect }) {
    this.widget = widget;
    this.valLabel = valLabel;
    this.bagLabel = bagLabel;
    this.widget?.addEventListener("click", (e) => {
      const btn = e.target.closest(".poolDisc");
      if (btn && !btn.disabled) onSelect?.(Number(btn.dataset.id));
    });
  }

  /**
   * @param {object} s
   * @param {number[]} s.pool 池子裡的棋
   * @param {number|null} s.selected 選中的棋
   * @param {number} s.face 輪到的顏色（池子裡的棋畫成這個顏色）
   * @param {number} s.bagSize 袋中剩幾顆
   * @param {boolean} s.gameOver
   * @param {boolean} s.canSelect 現在能不能點選（人類的回合）
   * @param {Set<number>} s.fiveIds 能直接連成五的棋
   * @param {number|null} s.cpuPick CPU 選好、準備要下的棋（落子前先亮出來）
   * @param {Map<number,number>} s.discPcts 提示模式下滑鼠所在格子：每顆棋下在那格的勝率（%）
   * @param {"locked"|"auto"|"none"|null} s.hintSel 選中的棋是使用者固定選的（locked）、每格自動選最好的（auto），還是自己選棋但還沒選（none）
   */
  render({ pool, selected, face, bagSize, gameOver, canSelect, fiveIds = new Set(), cpuPick = null, discPcts = new Map(), hintSel = null }) {
    if (this.widget) {
      this.widget.classList.toggle("empty", pool.length === 0);
      this.widget.classList.toggle("locked", !canSelect);
      this.widget.innerHTML = pool.length === 0
        ? `<span class="handPlaceholder">?</span>`
        : pool.map(id => {
          const sel = canSelect && id === selected;
          const label = discLabel(id, true);
          // 提示模式：固定選了這顆 → 發光；每格自動用最高的那顆 → 淡淡的框
          const hintCls = sel && hintSel === "locked" ? " hintLocked" : sel && hintSel === "auto" ? " hintAuto" : "";
          return `<button type="button" class="poolDisc${sel ? " selected" : ""}${hintCls}${id === cpuPick ? " cpuPick" : ""}" data-id="${id}" ${canSelect ? "" : "disabled"}
              aria-pressed="${sel}" aria-label="${tr(fiveIds.has(id) ? "poolDiscFive" : "poolDisc", { disc: label })}">
              ${discHtmlFive(id, face)}${fiveIds.has(id) && !discPcts.size ? `<span class="poolFive">★5</span>` : ""}${discPcts.has(id) ? `<span class="poolPct">${discPcts.get(id)}%</span>` : ""}
            </button>`;
        }).join("");
    }
    if (this.valLabel) {
      if (gameOver) this.valLabel.textContent = tr("handEnded");
      else if (selected == null && hintSel === "none" && cpuPick == null) this.valLabel.textContent = tr("poolPickPrompt");
      else if (selected == null && hintSel !== "auto" && cpuPick == null) this.valLabel.textContent = tr("handNone");
      else if (cpuPick != null) this.valLabel.textContent = tr("poolCpuPick", { disc: discLabel(cpuPick, true) });
      else if (canSelect) this.valLabel.textContent = tr("poolSelected", { disc: discLabel(selected, true) });
      else this.valLabel.textContent = tr("poolWaiting");
    }
    if (this.bagLabel) this.bagLabel.textContent = tr("handBag", { n: bagSize });
  }
}
