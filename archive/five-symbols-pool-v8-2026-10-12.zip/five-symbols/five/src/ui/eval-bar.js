/**
 * 📊 勝率條（像 chess.com 棋盤左側那條）：黑方在下、白方在上，分界線依雙方勝率移動。
 */

import { tr } from "../i18n.js";

/**
 * 勝率條上的勝率換算。引擎搜尋本身仍用原本的分數；提示的百分比、走法評價（ai/move-quality.js 的五個等級）用這個換算。
 *
 * v8 的分數是 tanh(評估值 ÷ 係數)，中盤非常保守，直接當勝率會一直停在 50% 附近。
 * 這裡用自我對戰的實際結果校準：勝率 = sigmoid(k × atanh(分數))，k 依剩餘空格變化。
 * 資料：6 級自我對戰 400 局、約 2 萬個局面（tests/eval-calibration.js，原始資料在 tests/results/）。
 * 校準後「預測 75% 的局面實際贏 74%、預測 25% 的實際贏 21%」，所以放大後的數字是可信的。
 */
const CAL = [ // [剩餘空格（該段中點）, k]
  [53, 9.76], [40.5, 15.69], [30.5, 15.09], [20.5, 9.82], [11.5, 5.33], [3.5, 6.55]
];

function kAt(empties) {
  if (empties >= CAL[0][0]) return CAL[0][1];
  for (let i = 1; i < CAL.length; i++) {
    const [e1, k1] = CAL[i - 1], [e2, k2] = CAL[i];
    if (empties >= e2) return k2 + (k1 - k2) * (empties - e2) / (e1 - e2);
  }
  return CAL[CAL.length - 1][1];
}

/**
 * @param {number} score v8 的分數（下棋者角度，[-1, 1]）
 * @param {number} empties 剩幾格
 * @returns {number} 下棋者的勝率 [0, 1]
 */
export function displayWinProb(score, empties) {
  if (score >= 0.999) return 1;
  if (score <= -0.999) return 0;
  return 1 / (1 + Math.exp(-kAt(empties) * Math.atanh(score)));
}

export class EvalBar {
  /** @param {HTMLElement} el #evalBar */
  constructor(el) {
    this.el = el;
    this.white = el?.querySelector(".evalWhite");
    this.blackNum = el?.querySelector(".evalNumBlack");
    this.whiteNum = el?.querySelector(".evalNumWhite");
  }

  /**
   * @param {{ blackProb: number, pending?: boolean }} s blackProb：黑方勝率 [0, 1]
   */
  render({ blackProb, pending = false }) {
    if (!this.el) return;
    const b = Math.round(blackProb * 100), w = 100 - b;
    // 白色區塊在上方，高度 = 白方勝率
    if (this.white) this.white.style.height = `${w}%`;
    // 數字寫在占比較大的那一邊
    if (this.blackNum) this.blackNum.textContent = b >= w ? `${b}` : "";
    if (this.whiteNum) this.whiteNum.textContent = w > b ? `${w}` : "";
    this.el.classList.toggle("pending", pending);
    this.el.title = tr("evalTitle", { b, w });
    this.el.setAttribute("aria-label", tr("evalTitle", { b, w }));
  }
}
