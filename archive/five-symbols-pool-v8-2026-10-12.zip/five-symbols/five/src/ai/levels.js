/**
 * 🎚️ 難度分級：每一級都是 v8 的削弱版，最高一級就是完整的 v8（吃滿設定的思考時間）。
 *
 * 削弱的方式有三種，各級自由搭配：
 *   depth  搜尋層數上限（固定層數，棋力不受電腦快慢影響）
 *   exact  剩幾格以內才做終盤精確求解（0 = 不做；省略 = v8 預設）
 *   time  固定的思考時間（毫秒），沒設就用使用者在設定裡選的時間
 *   eps    每一步有多少機率改走隨機的合法位置（模擬失誤）
 * 第 1 級（kind: "grab"）只顧五連：池子裡任何一顆能一步連成五就下，否則隨機挑棋、隨機落子。
 *
 * 公開池子規則：每一級都從池子挑「棋＋位置」，回傳的 disc 是要下的那顆。
 *
 * 相鄰兩級的勝率目標約 73%，各級的設定由 tests/level-ladder.js 對戰校準（數據見 LEVELS 上方）。
 */

import { getLegalMoves, applyMoveToBoard } from "../core/rules.js";
import { findFive } from "../core/five-rules.js";
import { searchPoolV8 } from "./v8.js";
import { V8_PLAIN_PARAMS } from "./v8/search.js";

// 公開池子（4 顆）規則下，相鄰兩級對戰的實測勝率（上一級贏，各 100～300 局）：
// 2→1 74%、3→2 72%、4→3 72%、5→4 75%、6→5 75%、7→6 76%（第 7 級用 1 秒思考）
// 原本的「6 層＋2% 失誤」那一級對第 6 級 72%，但最強的一級對它只贏 62%，差距太小所以拿掉
export const LEVELS = [
  { id: 1, kind: "grab" },                  // 只顧五連
  { id: 2, depth: 1, eps: 0.25 },
  { id: 3, depth: 1 },
  { id: 4, depth: 2, eps: 0.13 },
  { id: 5, depth: 4, eps: 0.12 },
  { id: 6, depth: 4 },
  { id: 7 }                                 // 完整的 v8，吃滿設定的思考時間
];

export const MAX_LEVEL = LEVELS.length;
export const clampLevel = (n) => Math.min(MAX_LEVEL, Math.max(1, Math.round(Number(n)) || MAX_LEVEL));

const pickResult = (sq, disc) => ({ bestSq: sq, disc, scores: [{ sq, disc, key: disc * 64 + sq, score: 0 }], depth: 0, exact: false });

function randomPick(board, player, pool, rng) {
  const moves = getLegalMoves(board, player);
  if (!moves.length || !pool.length) return null;
  const m = moves[Math.floor(rng() * moves.length)];
  return pickResult(m.r * 8 + m.c, pool[Math.floor(rng() * pool.length)]);
}

/**
 * 依難度從池子選「棋＋位置」。回傳 { bestSq, disc, scores, ... }，沒有合法位置時回傳 null。
 * @param {number[]} pool 公開池子裡的棋
 * @param {object} cfg LEVELS 的一項（測試可直接傳自訂設定）
 */
export function searchLevel(board, player, pool, cfg, { timeMs = 1000, rng = Math.random } = {}) {
  if (cfg.kind === "grab") {
    const moves = getLegalMoves(board, player);
    for (const disc of pool) {
      const win = moves.find(m => findFive(applyMoveToBoard(board, m, disc, player), player));
      if (win) return pickResult(win.r * 8 + win.c, disc);
    }
    return randomPick(board, player, pool, rng);
  }
  if (cfg.eps && rng() < cfg.eps) return randomPick(board, player, pool, rng);
  return searchPoolV8(board, player, pool, {
    timeMs: cfg.depth ? 600000 : (cfg.time || timeMs),
    maxDepth: cfg.depth,
    ...(cfg.exact != null ? { exactEmpties: cfg.exact } : {}),
    params: V8_PLAIN_PARAMS
  });
}
