/**
 * 🧠 五連黑白棋 - AI 服務層：選步、候選排行與教練說明
 * 由 v8 搜尋（公開池子規則：每一種棋各搜一次）；這裡把結果轉成遊戲走步，並為教練產生說明。
 */

import { BLACK } from "../core/constants.js";
import { posToCoord, applyMoveToBoard } from "../core/rules.js";
import { tr } from "../i18n.js";
import { toSearchBoard, legalMovesSb } from "./search-board.js";
import { V6_DEFAULT_TIME } from "./v6.js";
import { searchPoolV8 } from "./v8.js";
import { findFive, fiveScores, letterOf, discLabel } from "../core/five-rules.js";

/** 從公開池子選「棋＋位置」：v8 對池子裡每一種棋各搜尋一次 */
export function searchEngine(board, player, pool, opts = {}) {
  return searchPoolV8(board, player, pool, opts);
}

const N = 8;

const toGameMove = (sb, item, player) => ({
  r: item.sbMove.r,
  c: item.sbMove.c,
  player,
  disc: item.disc,
  flips: item.sbMove.flips.map(j => [Math.floor(j / N), j % N])
});

/** 引擎結果（棋 + 格子 + 分數）轉成帶翻面資訊的候選清單，已由高到低排序 */
function toRanked(board, player, scores) {
  const sb = toSearchBoard(board);
  const bySq = new Map(legalMovesSb(sb, player).map(m => [m.r * N + m.c, m]));
  const ranked = scores.filter(x => bySq.has(x.sq)).map(x => ({ sbMove: bySq.get(x.sq), disc: x.disc, score: x.score }));
  return { sb, ranked };
}

/**
 * 選出最佳走步（同步版，測試與評測用；網頁用 AiClient 在 Worker 裡算）
 * @returns {{ chosen: object|null, maxScore: number, info?: object }}
 */
export function findBestMoveForCPU(board, player, pool, { timeMs = V6_DEFAULT_TIME, maxDepth, params } = {}) {
  const res = searchEngine(board, player, pool, { timeMs, maxDepth, params });
  if (!res) return { chosen: null, maxScore: -Infinity };
  const { sb, ranked } = toRanked(board, player, res.scores);
  return { chosen: toGameMove(sb, ranked[0], player), maxScore: ranked[0].score, info: res };
}

/**
 * 教練說明（v8 的分數是勝率尺度 [-1, 1]）
 * @param {{sq, disc, score}[]} scores 每個「棋＋位置」的分數
 * @param {number[]} pool 公開池子（判斷對手下一手能不能用池子裡的棋連成五）
 * @returns {{ move, score, five, explanation }[]} 前 topN 名；move.disc 是要下的棋
 */
export function explainFiveSquares(board, player, scores, topN = 3, pool = []) {
  const { sb, ranked } = toRanked(board, player, scores);
  const foe = player === BLACK ? 2 : BLACK;
  // 同一格只列最好的那顆棋（開局時很多棋效果一樣，否則前三名常常是同一格）
  const seen = new Set();
  const distinct = ranked.filter(x => {
    const sq = x.sbMove.r * N + x.sbMove.c;
    if (seen.has(sq)) return false;
    seen.add(sq);
    return true;
  });
  return distinct.slice(0, topN).map(item => {
    const move = toGameMove(sb, item, player);
    const handId = item.disc;
    const nb = applyMoveToBoard(board, move, handId, player);
    const five = findFive(nb, player);
    const sc = fiveScores(nb, false);
    const mine = player === BLACK ? sc.black : sc.white, theirs = player === BLACK ? sc.white : sc.black;
    const pros = [], cons = [];
    if (five) pros.push(tr("exFiveWin", { v: letterOf(five.value) }));
    pros.push(tr("exFivePlainGain", { disc: discLabel(handId, true), n: move.flips.length }));
    if (!five) {
      const s = item.score;
      if (s >= 0.999) pros.push(tr("exFiveForced"));
      else if (s <= -0.999) cons.push(tr("exFiveLost"));
      else pros.push(tr("exFiveWinrate", { p: Math.round((s + 1) * 50) }));
    }
    // 對手下一手：池子裡剩下的棋就能連成五（一定會發生），或補進來的棋剛好能連成五（有機會）
    if (!five) {
      const rest = pool.filter(id => id !== handId);
      const sure = rest.find(id => opponentCanFive(nb, foe, [id]));
      if (sure != null) cons.push(tr("exFiveDangerSure", { disc: discLabel(sure, true) }));
      else if (opponentCanFive(nb, foe)) cons.push(tr("exFiveDanger"));
    }
    const summary = tr("exSummaryFivePlain", { coord: posToCoord(move.r, move.c), disc: discLabel(handId, true), mine, theirs });
    return { move, score: item.score, five, explanation: { summary, pros, cons } };
  });
}

/**
 * 對手下一手能不能連成五（只看盤上已有的棋）。
 * discs 有給：只試這幾顆棋；沒給：試 8 顆左右同號的棋（v|v），含 v 的棋能補成五，v|v 一定也能
 */
function opponentCanFive(board, foe, discs = null) {
  const sb = toSearchBoard(board);
  const tryIds = discs || [0, 9, 18, 27, 36, 45, 54, 63];
  for (const m of legalMovesSb(sb, foe)) {
    const move = { r: m.r, c: m.c, flips: m.flips.map(j => [Math.floor(j / N), j % N]) };
    for (const id of tryIds) {
      if (findFive(applyMoveToBoard(board, move, id, foe), foe)) return true;
    }
  }
  return false;
}

/** Worker 回傳的最佳格轉成遊戲走步 */
export function moveFromSquare(board, player, sq, disc = null) {
  const sb = toSearchBoard(board);
  const m = legalMovesSb(sb, player).find(x => x.r * N + x.c === sq);
  return m ? toGameMove(sb, { sbMove: m, disc }, player) : null;
}
