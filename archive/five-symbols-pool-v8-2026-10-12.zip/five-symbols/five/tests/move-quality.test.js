import test from "node:test";
import assert from "node:assert/strict";
import { classifyMove, levelOf } from "../src/ai/move-quality.js";
import { createEmptyBoard } from "../src/core/rules.js";
import { BLACK, WHITE } from "../src/core/constants.js";

// 測試用：分數直接當勝率（score = 2p − 1），走法 key = 格子（棋 0）
const toProb = (s) => (s + 1) / 2;
const sc = (obj) => Object.entries(obj).map(([sq, p]) => ({ sq: Number(sq), score: 2 * p - 1 }));
/** 開局盤面（中間四顆），剩 60 格 */
function opening() {
  const b = createEmptyBoard();
  b[3][3] = { id: 9, face: WHITE }; b[4][4] = { id: 18, face: WHITE };
  b[3][4] = { id: 27, face: BLACK }; b[4][3] = { id: 36, face: BLACK };
  return b;
}
/** 終盤盤面：只剩 6 格空著 */
function endgame() {
  const b = createEmptyBoard();
  for (let s = 0; s < 64; s++) b[s >> 3][s & 7] = { id: s, face: (s * 7) % 3 ? BLACK : WHITE };
  for (const s of [20, 21, 22, 29, 30, 38]) b[s >> 3][s & 7] = null;
  return b;
}
const mark = (scores, played, extra = {}) => classifyMove({ scores: sc(scores), played, board: opening(), turn: BLACK, toProb, ...extra });
/** 開局盤面再加一條「三」（最下面一排 A8～C8 都有 α，D8、E8 空著）：盤面上有威脅 */
function withThree() {
  const b = opening();
  [1, 2, 3].forEach((r, c) => { b[7][c] = { id: (r - 1) * 8, face: BLACK }; }); // 左邊的字都是 α
  return b;
}
/**
 * 有難度的局面：可下的格子 7 個以上（多 5 個很差的格子）＋ 這一格換一顆棋勝率差 3%（選棋有差）＝ 2 分
 * withThree 的盤面再加 1 分（威脅）＝ 3 分
 */
const hard = (scores, played) => [
  ...sc(scores),
  ...sc({ 40: 0.05, 41: 0.05, 42: 0.05, 43: 0.05, 44: 0.05 }),
  { sq: 64 + played, score: 2 * (scores[played] - 0.03) - 1 }
];
const markHard = (scores, played, extra = {}) => classifyMove({ scores: hard(scores, played), played, board: opening(), turn: BLACK, toProb, ...extra });

test("局勢等級：敗定 ≤10%、劣勢、拉鋸 35～65%、優勢、勝定 ≥90%", () => {
  assert.deepEqual([0.05, 0.1, 0.2, 0.35, 0.5, 0.65, 0.8, 0.9, 1].map(levelOf), [0, 0, 1, 2, 2, 3, 3, 4, 4]);
});

test("不標：只有一個格子、勝負已定（雙方都在勝定或都在敗定）", () => {
  assert.equal(mark({ 19: 0.6 }, 19).sym, null);
  assert.equal(mark({ 19: 0.97, 26: 0.92, 37: 0.5 }, 26).sym, null);   // 勝定 → 勝定
  assert.equal(mark({ 19: 0.08, 26: 0.02, 37: 0.01 }, 26).sym, null);  // 敗定 → 敗定
});

test("失誤類：掉兩級 ??、掉一級 ?、等級沒變但損失 ≥ 8% ?!；損失不到 5% 不標（就算剛好跨過等級邊界）", () => {
  assert.equal(mark({ 19: 0.7, 26: 0.3, 37: 0.2 }, 26).sym, "??");    // 優勢 → 劣勢
  assert.equal(mark({ 19: 0.7, 26: 0.5, 37: 0.2 }, 26).sym, "?");     // 優勢 → 拉鋸
  assert.equal(mark({ 19: 0.6, 26: 0.51, 37: 0.2 }, 26).sym, "?!");   // 拉鋸裡讓掉 9%
  assert.equal(mark({ 19: 0.66, 26: 0.62, 37: 0.2 }, 26).sym, null);  // 優勢 → 拉鋸，但只少 4%
  const m = mark({ 19: 0.7, 26: 0.5, 37: 0.2 }, 26);
  assert.equal(m.why.key, "whyDrop");
  assert.deepEqual([m.why.p.from, m.why.p.to, m.why.p.at, m.why.p.disc], [3, 2, "D3", 0]); // 最佳步：D3 配第 0 顆棋
});

test("好手類：關鍵一手（其他格子都低一級、差 10% 以上），難度 ≥ 2 分 → !；其他每格都差 20% 以上而且難度 ≥ 3 分 → !!", () => {
  const m = markHard({ 20: 0.7, 26: 0.5, 37: 0.4 }, 20);   // E3：只看盤面也看得出來，難度剛好 2 分
  assert.equal(m.sym, "!");
  assert.equal(m.why.key, "whyOnly");
  assert.equal(markHard({ 20: 0.7, 26: 0.62, 37: 0.4 }, 20).sym, null);    // 最接近的只差 8%：不是關鍵一手
  // 多一條「三」（3 分），其他每格都差 20% 以上 → !!
  const bang = classifyMove({ scores: hard({ 20: 0.7, 26: 0.3, 37: 0.2 }, 20), played: 20, board: withThree(), turn: BLACK, toProb });
  assert.equal(bang.sym, "!!");
  assert.equal(markHard({ 20: 0.7, 26: 0.3, 37: 0.2 }, 20).sym, "!");     // 只有 2 分 → !
  const closeOne = classifyMove({ scores: hard({ 20: 0.7, 26: 0.55, 37: 0.2 }, 20), played: 20, board: withThree(), turn: BLACK, toProb });
  assert.equal(closeOne.sym, "!");                                         // 3 分，但最接近的格子只差 15% → 不到 !!
  const wideOne = classifyMove({ scores: hard({ 20: 0.7, 26: 0.45, 37: 0.2 }, 20), played: 20, board: withThree(), turn: BLACK, toProb });
  assert.equal(wideOne.sym, "!!");                                         // 其他格子差 25% 以上（即使只低一級）→ !!
});

test("很好找的關鍵一手不標：選擇很少、每格只有一種棋、盤面沒有威脅（難度不到 2 分）", () => {
  assert.equal(mark({ 19: 0.7, 26: 0.5, 37: 0.4 }, 19).sym, null);
  assert.equal(mark({ 0: 0.7, 26: 0.3, 37: 0.2 }, 0).sym, null);         // 佔角
});

test("很明顯的關鍵一手不標：佔角、只有兩個格子可下", () => {
  assert.equal(mark({ 0: 0.7, 26: 0.3, 37: 0.2 }, 0).sym, null);
  assert.equal(mark({ 19: 0.7, 26: 0.3 }, 19).sym, null);
});

test("終盤（剩 7 格以內）不標好手類；但對手翻車、這步把握機會逆轉時照常標", () => {
  const board = endgame();
  const scores = { 20: 0.95, 21: 0.5, 22: 0.4 };
  const run = (prevP) => classifyMove({ scores: sc(scores), played: 20, board, turn: BLACK, toProb, prevP });
  assert.equal(run(null).sym, null);
  assert.equal(run(0.6).sym, null);        // 對手下之前就是拉鋸：不是逆轉
  const m = run(0.2);                       // 對手下之前是劣勢 → 翻車 → 這步拿到勝定
  assert.equal(m.sym, "!");
  assert.equal(m.why.key, "whyComeback");
  // 終盤的失誤照常標
  assert.equal(classifyMove({ scores: sc(scores), played: 21, board, turn: BLACK, toProb }).sym, "??");
});

test("原本已經勝定：只有這步能贏也不標（勝負早就分了）；原本已經敗定：只有起死回生才標", () => {
  // 截圖的情況：對手下之前這一方就是 99%，現在只有 A2 能贏、其他格子都是 0%
  assert.equal(mark({ 8: 0.97, 5: 0.02, 14: 0.02, 15: 0.02 }, 8, { prevP: 0.99 }).sym, null);
  assert.equal(mark({ 19: 0.97, 26: 0.5, 37: 0.4 }, 19, { prevP: 0.95 }).sym, null);
  // 同樣的局面，但原本是拉鋸（對手剛翻車）→ 找到唯一的勝著，照常標
  assert.equal(markHard({ 20: 0.97, 26: 0.6, 37: 0.6 }, 20, { prevP: 0.5 }).sym, "!");
  // 原本敗定：這步只是從敗定撐到劣勢，不標；拉到拉鋸以上才是起死回生
  assert.equal(mark({ 19: 0.3, 26: 0.05, 37: 0.02 }, 19, { prevP: 0.03 }).sym, null);
  const back = mark({ 19: 0.7, 26: 0.5, 37: 0.4 }, 19, { prevP: 0.05 });
  assert.equal(back.sym, "!");
  assert.equal(back.why.key, "whyComeback");
  // 原本敗定、對手只放到劣勢、這步又掉回敗定：從頭到尾都是輸棋，不標
  assert.equal(mark({ 19: 0.3, 26: 0.05, 37: 0.02 }, 26, { prevP: 0.03 }).sym, null);
  // 原本敗定、對手給了拉鋸的機會、這步沒抓住：錯過起死回生，照常標
  assert.equal(mark({ 19: 0.5, 26: 0.2, 37: 0.02 }, 26, { prevP: 0.03 }).sym, "?");
  // 原本勝定、這步翻車：失誤照常標
  assert.equal(mark({ 19: 0.95, 26: 0.4, 37: 0.2 }, 26, { prevP: 0.97 }).sym, "??");
});

test("!? 設陷阱：損失 < 5%，下完後對手一半以上的格子（至少 3 格）會掉兩級以上", () => {
  const next = { scores: sc({ 10: 0.6, 11: 0.55, 12: 0.05, 13: 0.05, 14: 0.05 }) };
  assert.equal(mark({ 19: 0.5, 26: 0.48, 37: 0.2 }, 26, { next }).sym, "!?");
  // 只有 2 格會倒向你
  const few = { scores: sc({ 10: 0.6, 11: 0.55, 12: 0.5, 13: 0.05, 14: 0.05 }) };
  assert.equal(mark({ 19: 0.5, 26: 0.48, 37: 0.2 }, 26, { next: few }).sym, null);
  // 對手的最佳步是直接連成五（池子補進來的棋運氣好）：不算陷阱
  const lucky = { scores: sc({ 10: 1, 11: 0.55, 12: 0.05, 13: 0.05, 14: 0.05 }) };
  assert.equal(mark({ 19: 0.5, 26: 0.48, 37: 0.2 }, 26, { next: lucky }).sym, null);
});

test("找不到這一步的分數時回傳 null", () => {
  assert.equal(mark({ 19: 0.6, 26: 0.4 }, 7), null);
});

test("勝率條的換算：0 分 = 50%、單調遞增、±1 = 0%／100%，中盤比原本的換算明顯", async () => {
  const { displayWinProb } = await import("../src/ui/eval-bar.js");
  for (const empties of [58, 40, 30, 20, 10, 3]) {
    assert.equal(displayWinProb(0, empties), 0.5);
    assert.equal(displayWinProb(1, empties), 1);
    assert.equal(displayWinProb(-1, empties), 0);
    let prev = 0;
    for (let s = -0.95; s <= 0.95; s += 0.05) {
      const p = displayWinProb(s, empties);
      assert.ok(p >= prev);
      prev = p;
    }
  }
  // 中盤分數 0.05（原本只算 52.5%）放大後要超過 60%
  assert.ok(displayWinProb(0.05, 30) > 0.6);
});

test("棋盤上的評價標記：六種評價都有樣式與提示文字（少了會讓畫面更新出錯、CPU 卡住）", async () => {
  const { MARK_CLASS, MARK_TIP } = await import("../src/ui/board-view.js");
  for (const sym of ["!!", "!", "!?", "?!", "?", "??"]) {
    assert.ok(MARK_CLASS[sym], sym);
    assert.ok(MARK_TIP[sym], sym);
  }
});
