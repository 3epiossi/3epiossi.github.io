import test from "node:test";
import assert from "node:assert/strict";
import { BLACK, WHITE } from "../src/core/constants.js";
import { GameEngine } from "../src/core/game-engine.js";
import { createEmptyBoard, createDisc, applyMoveToBoard, remainingBag } from "../src/core/rules.js";
import { leftOf, rightOf, valueOf, numberMask, findFive, fiveScores, FIVE_WINDOWS } from "../src/core/five-rules.js";
import { searchRootV8, V8_PARAMS, WIN } from "../src/ai/v8/search.js";
import { mulberry32 } from "./helpers.js";

const idOf = (left, right) => (right - 1) * 8 + (left - 1);

test("棋子：64 顆是所有 (左, 右) 組合，分數 = 左 × 右，總和 1296", () => {
  const seen = new Set();
  let sum = 0;
  for (let id = 0; id < 64; id++) {
    seen.add(`${leftOf(id)},${rightOf(id)}`);
    sum += valueOf(id);
  }
  assert.equal(seen.size, 64);
  assert.equal(sum, 1296);
  assert.equal(valueOf(idOf(3, 7)), 21);
  assert.equal(numberMask(idOf(3, 7)), (1 << 2) | (1 << 6));
});

test("五連窗口共 96 個", () => {
  assert.equal(FIVE_WINDOWS.length, 96);
});

test("五連：每顆任選左或右能全部相同才算；同色、連續、直線", () => {
  const b = createEmptyBoard();
  // 第 1 列 A～E：(5,1) (2,5) (5,8) (7,5) (5,5) → 都含 5
  [[5, 1], [2, 5], [5, 8], [7, 5], [5, 5]].forEach(([l, r], c) => { b[0][c] = createDisc(idOf(l, r), BLACK); });
  assert.deepEqual(findFive(b, BLACK)?.value, 5);
  assert.equal(findFive(b, WHITE), null);
  b[0][3] = createDisc(idOf(7, 6), BLACK); // 第 4 顆不含 5
  assert.equal(findFive(b, BLACK), null);
  b[0][3] = createDisc(idOf(7, 5), WHITE); // 含 5 但是對手的
  assert.equal(findFive(b, BLACK), null);
});

test("斜線也算", () => {
  const b = createEmptyBoard();
  for (let k = 0; k < 5; k++) b[2 + k][1 + k] = createDisc(idOf(3, k + 1 === 3 ? 4 : k + 1), WHITE);
  assert.equal(findFive(b, WHITE)?.value, 3);
});

test("分數 = 各自棋子左 × 右的總和", () => {
  const b = createEmptyBoard();
  b[0][0] = createDisc(idOf(2, 3), BLACK);
  b[0][1] = createDisc(idOf(8, 8), WHITE);
  b[0][2] = createDisc(idOf(4, 1), BLACK);
  assert.deepEqual(fiveScores(b), { black: 6 + 4, white: 64 });
});

test("v8：手上的棋能直接成五時，立刻選那一步", () => {
  let checked = 0;
  for (let g = 0; g < 40 && checked < 8; g++) {
    const e = new GameEngine({ rng: mulberry32(100 + g) });
    for (let ply = 0; ply < 50 && !e.gameOver; ply++) {
      const moves = e.legalMoves();
      if (!moves.length) { e.passTurn(); continue; }
      const winning = moves.filter(m => findFive(applyMoveToBoard(e.board, m, e.hand, e.currentTurn), e.currentTurn));
      if (winning.length) {
        const r = searchRootV8({ board: e.board, player: e.currentTurn, handId: e.hand, bag: remainingBag(e.board, e.hand), timeMs: 200 });
        assert.ok(r.win && winning.some(m => m.r * 8 + m.c === r.bestSq));
        checked++;
        break;
      }
      e.executeMove(moves[Math.floor((g * 7 + ply) % moves.length)].r, moves[Math.floor((g * 7 + ply) % moves.length)].c);
    }
  }
  assert.ok(checked >= 3, `只找到 ${checked} 個可直接成五的局面`);
});

test("v8：對手下一手必定成五時，搜尋會察覺（分數接近 −WIN）或去擋", () => {
  // 白方在 A1～D1 有四顆含 5 的棋、E1 空著；黑方若不擋，白方任何含 5 的棋都能在 E1 成五（只要 E1 是合法步）
  // 這裡只檢查搜尋不會出錯、回傳合法步
  const e = new GameEngine({ rng: mulberry32(9) });
  const r = searchRootV8({ board: e.board, player: e.currentTurn, handId: e.hand, bag: remainingBag(e.board, e.hand), timeMs: 200 });
  assert.ok(e.findLegalMove(r.bestSq >> 3, r.bestSq & 7));
  assert.ok(Math.abs(r.scores[0].score) < WIN); // 開局不可能已經必勝／必敗
});

test("引擎（五連模式）：連成五立刻結束、由連成五的一方獲勝", () => {
  let ended = 0;
  for (let g = 0; g < 60 && ended < 3; g++) {
    const e = new GameEngine({ rng: mulberry32(800 + g) });
    while (!e.gameOver) {
      const m = e.legalMoves();
      if (!m.length) { e.passTurn(); continue; }
      const player = e.currentTurn;
      const pick = m[(g * 3 + e.tree.nodes.size) % m.length];
      e.executeMove(pick.r, pick.c);
      if (e.gameOver && e.settlementData.byFive) {
        assert.equal(e.settlementData.winner, player);
        assert.ok(findFive(e.board, player));
        assert.deepEqual(e.lastMove.five.cells, e.settlementData.five.cells);
        // 時光機：跳回上一手再回來，終局狀態完整還原
        const tip = e.tree.currentNodeId;
        const prev = e.tree.getNode(tip).parentId;
        e.jumpToNode(prev);
        assert.equal(e.gameOver, false);
        e.jumpToNode(tip);
        assert.equal(e.gameOver, true);
        assert.ok(e.settlementData.byFive);
        ended++;
      }
    }
    if (!e.settlementData.byFive) {
      const s = fiveScores(e.board, false);
      assert.equal(e.settlementData.black, s.black);
      assert.equal(e.settlementData.winner, s.black === s.white ? 0 : s.black > s.white ? BLACK : WHITE);
    }
  }
  assert.ok(ended >= 1);
});

test("引擎（五連模式）：每顆 1 分，雙方合計等於盤上棋子數（填滿時 64）；五連以字母標示", async () => {
  const { discLabel, letterOf } = await import("../src/core/five-rules.js");
  assert.equal(discLabel(idOf(7, 8), true), "ηθ");
  assert.equal(letterOf(1), "α");
  let sawFull = false, sawFive = false;
  for (let g = 0; g < 40 && !(sawFull && sawFive); g++) {
    const e = new GameEngine({ rng: mulberry32(900 + g) });
    while (!e.gameOver) {
      const m = e.legalMoves();
      if (!m.length) { e.passTurn(); continue; }
      const p = m[(g + e.tree.nodes.size) % m.length];
      e.executeMove(p.r, p.c);
    }
    const s = e.settlementData;
    const discs = e.board.flat().filter(Boolean).length;
    assert.equal(s.black + s.white, discs);
    if (discs === 64) sawFull = true;
    if (s.byFive) {
      sawFive = true;
      // 結算原因存的是符號編號（顯示時才依目前的符號組換成字），1～8
      assert.ok(s.reason.p.v.$sym >= 1 && s.reason.p.v.$sym <= 8);
      assert.match(letterOf(s.reason.p.v.$sym), /^[α-θ]$/);
    }
  }
  assert.ok(sawFull || sawFive);
});

test("v8（五連模式）：只選合法位置", async () => {
  const { findBestMoveForCPU } = await import("../src/ai/ai-service.js");
  const e = new GameEngine({ rng: mulberry32(77) });
  for (let i = 0; i < 10 && !e.gameOver; i++) {
    if (!e.legalMoves().length) { e.passTurn(); continue; }
    const r = findBestMoveForCPU(e.board, e.currentTurn, e.pool, { timeMs: 50 });
    assert.ok(e.findLegalMove(r.chosen.r, r.chosen.c));
    assert.ok(e.executeMove(r.chosen.r, r.chosen.c, r.chosen.disc));
  }
});

test("multiPV 搜尋：每個合法位置都有分數", () => {
  const e = new GameEngine({ rng: mulberry32(31) });
  const bag = remainingBag(e.board, e.hand);
  const r = searchRootV8({ board: e.board, player: e.currentTurn, handId: e.hand, bag, timeMs: 300, multiPV: true, params: V8_PARAMS });
  const legal = e.legalMoves().length;
  assert.equal(r.scores.length, legal);
});

test("池子規則：N = 1、池子沒有別的棋時，搜尋結果與一般規則完全相同（中盤與終盤）", async () => {
  const { searchV8 } = await import("../src/ai/v8.js");
  for (const seed of [41, 42]) {
    const e = new GameEngine({ rng: mulberry32(seed) });
    const rng = mulberry32(seed + 1);
    // 中盤一個局面、終盤（剩 5 格以內）一個局面
    for (const stop of [30, 5]) {
      while (!e.gameOver && e.board.flat().filter(x => !x).length > stop) {
        const m = e.legalMoves();
        if (!m.length) { e.passTurn(); continue; }
        const pick = m[Math.floor(rng() * m.length)];
        e.executeMove(pick.r, pick.c);
      }
      if (e.gameOver || !e.legalMoves().length) continue;
      const opts = { timeMs: 60000, maxDepth: 3, exactEmpties: 5 };
      const a = searchV8(e.board, e.currentTurn, e.hand, opts);
      const b = searchV8(e.board, e.currentTurn, e.hand, { ...opts, pool: { n: 1, mode: "shared", rest: [] } });
      assert.deepEqual(b.scores.map(x => [x.sq, +x.score.toFixed(9)]), a.scores.map(x => [x.sq, +x.score.toFixed(9)]));
    }
  }
});

test("棋子文字：預設希臘字母 α～θ；自訂要剛好 8 個不同的字（中英日文都可）；不合格或舊設定退回希臘字母", async () => {
  const { letterOf, setSymbolSet, getSymbolSet, parseCustomSymbols } = await import("../src/core/five-rules.js");
  assert.equal(letterOf(1), "α");
  assert.equal(letterOf(8), "θ");
  setSymbolSet("custom", "天地玄黃宇宙洪荒");
  assert.equal(getSymbolSet(), "custom");
  assert.equal(letterOf(1), "天");
  assert.equal(letterOf(8), "荒");
  setSymbolSet("custom", "あ い う え お か き く"); // 空白不算
  assert.equal(letterOf(5), "お");
  assert.deepEqual(parseCustomSymbols("ABCDEFG"), { ok: false, reason: "count", count: 7 });
  assert.deepEqual(parseCustomSymbols("天地天黃宇宙洪荒"), { ok: false, reason: "dupe", dupe: "天" });
  assert.equal(parseCustomSymbols("αβγδ天地AB").ok, true);
  assert.equal(parseCustomSymbols("👍🏽🍎🍊🍋🍌🍉🍇🍓").ok, true); // 一個表情符號（含膚色）算一個字
  for (const old of ["letters", "shapes", "nature", "bogus"]) {
    setSymbolSet(old);
    assert.equal(getSymbolSet(), "greek");
  }
  setSymbolSet("custom", "ABC");                 // 不合格 → 退回希臘字母
  assert.equal(getSymbolSet(), "greek");
  assert.equal(letterOf(1), "α");
});

test("五連威脅：不分黑白，4 顆有共同符號、剩一格空 → 四；3 顆 → 三；沒有共同符號不算", async () => {
  const { findThreats } = await import("../src/core/five-rules.js");
  const b = createEmptyBoard();
  // 第 0 列：A1～D1 黑白混雜，四顆都含數字 3，E1 空 → 四，缺口 E1 要補 3
  // （每一列右邊的數字都不一樣，避免直排、斜排意外湊出共同符號）
  for (let c = 0; c < 4; c++) b[0][c] = createDisc(idOf(3, [1, 2, 4, 6][c]), c % 2 ? WHITE : BLACK);
  // 第 2 列：A3～C3 黑白混雜，三顆都含 5，D3、E3 空 → 三
  for (let c = 0; c < 3; c++) b[2][c] = createDisc(idOf(5, [7, 8, 1][c]), c === 1 ? BLACK : WHITE);
  // 第 4 列：A5～C5 含 7，但 D5 是沒有 7 的棋 → A5～E5 這段沒有共同符號
  for (let c = 0; c < 3; c++) b[4][c] = createDisc(idOf(7, [4, 5, 6][c]), BLACK);
  b[4][3] = createDisc(idOf(2, 2), WHITE);
  const t = findThreats(b);
  for (let c = 0; c < 4; c++) assert.ok(t.fours.has(c), "A1～D1 是四（黑白混雜也算）");
  assert.equal(t.gaps.get(4), 1 << 2); // E1 缺口，要數字 3
  for (let c = 0; c < 3; c++) assert.ok(t.threes.has(16 + c), "A3～C3 是三（黑白混雜也算）");
  for (let c = 0; c < 3; c++) assert.ok(!t.threes.has(32 + c) && !t.fours.has(32 + c), "A5～C5 那段夾了沒有 7 的棋");
  const b2 = createEmptyBoard();
  b2[0][0] = createDisc(idOf(1, 2), BLACK); b2[0][1] = createDisc(idOf(3, 4), BLACK); b2[0][2] = createDisc(idOf(5, 6), BLACK);
  assert.equal(findThreats(b2).threes.size, 0);
});

test("五連威脅分組：同一條線、同一個符號的重疊窗口合併成一組（活四一組、兩個缺口）", async () => {
  const { findThreatGroups } = await import("../src/core/five-rules.js");
  const b = createEmptyBoard();
  for (let c = 1; c < 5; c++) b[1][c] = createDisc(idOf(3, [1, 2, 4, 6][c - 1]), c % 2 ? BLACK : WHITE);
  const groups = findThreatGroups(b);
  assert.equal(groups.length, 1);
  assert.equal(groups[0].kind, 4);
  assert.equal(groups[0].v, 3);
  assert.deepEqual(groups[0].cells, [9, 10, 11, 12]);
  assert.deepEqual([...groups[0].gaps].sort((a, c) => a - c), [8, 13]);
});

test("棋子文字顏色：借用另一方的寶石色；棋面只能用寶石預設色", async () => {
  const { resolveTextColor, textPaletteFor, normalizeFace } = await import("../src/ui/text-colors.js");
  const { DEFAULT_BLACK_PRESETS, DEFAULT_WHITE_PRESETS } = await import("../../src/ui/skin-workshop.js");
  assert.equal(textPaletteFor(true), DEFAULT_WHITE_PRESETS);   // 黑方棋面的字用白方的顏色（淺色系）
  assert.equal(textPaletteFor(false), DEFAULT_BLACK_PRESETS);  // 白方棋面的字用黑方的顏色（深色系）
  assert.equal(resolveTextColor(true, "rose").color, DEFAULT_WHITE_PRESETS.find(p => p.id === "rose").color);
  assert.equal(resolveTextColor(true, "ruby").id, DEFAULT_WHITE_PRESETS[0].id);  // 不在色系裡 → 第一個
  assert.equal(resolveTextColor(false, "").id, DEFAULT_BLACK_PRESETS[0].id);
  // 以前存的自訂色、圖片 → 該方的第一個預設色；預設色照舊
  assert.equal(normalizeFace({ type: "image", imageData: "data:" }, true).id, DEFAULT_BLACK_PRESETS[0].id);
  assert.equal(normalizeFace({ type: "color", color: "#fde68a" }, false).id, DEFAULT_WHITE_PRESETS[0].id);
  assert.equal(normalizeFace({ type: "preset", id: "ruby" }, true).gradient, DEFAULT_BLACK_PRESETS.find(p => p.id === "ruby").gradient);
});

test("makesFourAt：剛下的棋經過的窗口有 4 顆同色、有共同符號的棋，剩 1 格空的", async () => {
  const { makesFourAt } = await import("../src/core/five-rules.js");
  const { createEmptyBoard } = await import("../src/core/rules.js");
  const id = (l, r) => (r - 1) * 8 + (l - 1);
  const b = createEmptyBoard();
  // 第 0 列 c0～c3 都含符號 1，同色；c4 空 → 四
  [id(1, 2), id(1, 3), id(1, 4), id(1, 5)].forEach((d, c) => { b[0][c] = { id: d, face: 1 }; });
  assert.equal(makesFourAt(b, 0, 3), true);
  // 其中一顆是對方的顏色 → 不算
  b[0][1] = { id: id(1, 3), face: 2 };
  assert.equal(makesFourAt(b, 0, 3), false);
  // 沒有共同符號 → 不算
  b[0][1] = { id: id(6, 7), face: 1 };
  assert.equal(makesFourAt(b, 0, 3), false);
});

test("四的缺口：只有下在那裡真的會連成五（翻面也算）的那一方才標", async () => {
  const { completesFive, withGapOwners, findThreatGroups } = await import("../src/core/five-rules.js");
  const { createEmptyBoard } = await import("../src/core/rules.js");
  const { BLACK, WHITE } = await import("../src/core/constants.js");
  const id = (l, r) => (r - 1) * 8 + (l - 1);
  const B = 2; // β
  // 同一直行：第 1 列是缺口，下面 θβ δβ ζβ εβ 都有 β，最下面 ηζ
  const column = (faces) => {
    const b = createEmptyBoard();
    [[8, 2], [4, 2], [6, 2], [5, 2], [7, 6]].forEach(([l, r], i) => { b[1 + i][4] = { id: id(l, r), face: faces[i] }; });
    return b;
  };
  const gap = 0 * 8 + 4;
  // 第一張圖：黑 白 黑 白 白 → 白下會翻 θβ，但 ζβ 還是黑；黑下不翻 → 兩方都連不成
  const b1 = column([BLACK, WHITE, BLACK, WHITE, WHITE]);
  assert.equal(completesFive(b1, gap, B, WHITE), false);
  assert.equal(completesFive(b1, gap, B, BLACK), false);
  const g1 = withGapOwners(b1, findThreatGroups(b1)).find(g => g.kind === 4 && g.v === B);
  assert.deepEqual(g1.gaps, []);   // 缺口不顯示
  // 第二張圖：黑 黑 黑 白 白 → 白下把三顆黑翻成白 → 五連；黑下連不成
  const b2 = column([BLACK, BLACK, BLACK, WHITE, WHITE]);
  assert.equal(completesFive(b2, gap, B, WHITE), true);
  assert.equal(completesFive(b2, gap, B, BLACK), false);
  const g2 = withGapOwners(b2, findThreatGroups(b2)).find(g => g.kind === 4 && g.v === B);
  assert.deepEqual(g2.gaps, [gap]);
  assert.deepEqual(g2.gapOwners[gap], [WHITE]);
});

test("從這裡繼續下：目前這一步變成最新一步，之後的棋與分支都刪掉，可以直接接著下", async () => {
  const { GameEngine } = await import("../src/core/game-engine.js");
  const play = (e) => { const m = e.legalMoves()[0]; assert.ok(e.playMove(m.r, m.c, e.pool[0])); };
  // 主線：下 6 步，退回第 3 步，從這裡繼續
  const e = new GameEngine({ rng: mulberry32(7) });
  for (let i = 0; i < 6; i++) play(e);
  e.goToStep(3);
  const at3 = e.tree.currentNodeId;
  assert.ok(e.makeCurrentLatest());
  assert.equal(e.tree.getBranchHistory().length, 4);
  assert.equal(e.tree.getBranchTipNode().id, at3);
  assert.equal(e.tree.currentNodeId, at3);
  play(e);                                            // 直接接著下，不會開分支
  assert.equal(e.tree.activeBranchId, "main");
  assert.equal(e.tree.getBranchHistory().length, 5);

  // 分支：退回第 2 步改下別步（開分支），在分支上再下兩步、退一步，從這裡繼續 → 分支變成主線
  const f = new GameEngine({ rng: mulberry32(8) });
  for (let i = 0; i < 6; i++) play(f);
  f.goToStep(2);
  const alt = f.legalMoves()[1] || f.legalMoves()[0];
  assert.ok(f.playMove(alt.r, alt.c, f.pool[0]));
  assert.notEqual(f.tree.activeBranchId, "main");
  play(f); play(f);
  f.goToStep(4);
  const branchAt4 = f.tree.currentNodeId;
  assert.ok(f.makeCurrentLatest());
  assert.equal(f.tree.activeBranchId, "main");
  assert.equal(f.tree.branches.size, 1);
  const line = f.tree.getBranchHistory();
  assert.equal(line.length, 5);
  assert.equal(line[4].id, branchAt4);
  assert.ok(line.every(n => n.branchId === "main"));
  assert.equal(f.tree.nodes.size, 5);                 // 原本主線第 3 步之後的棋都刪掉了
});

test("存檔：對局樹（含分支）存成 JSON 再讀回，局面、分支、目前那一步都一樣，讀回後可以接著下", async () => {
  const play = (e) => { const m = e.legalMoves()[0]; assert.ok(e.playMove(m.r, m.c, e.pool[0])); };
  const e = new GameEngine({ rng: mulberry32(11) });
  for (let i = 0; i < 6; i++) play(e);
  e.goToStep(3);
  const alt = e.legalMoves()[1] || e.legalMoves()[0];
  assert.ok(e.playMove(alt.r, alt.c, e.pool[0]));     // 開一條分支
  play(e);
  e.tree.getCurrentNode().mark = { sym: "!", why: { key: "markKey", p: {} } }; // app 加在節點上的欄位也要保留
  const saved = JSON.parse(JSON.stringify(e.tree.toJSON()));

  const g = new GameEngine({ rng: mulberry32(99) });
  assert.ok(g.restoreTree(saved));
  assert.equal(g.tree.nodes.size, e.tree.nodes.size);
  assert.equal(g.tree.branches.size, 2);
  assert.equal(g.tree.activeBranchId, e.tree.activeBranchId);
  assert.equal(g.tree.currentNodeId, e.tree.currentNodeId);
  assert.deepEqual(g.board, e.board);
  assert.deepEqual(g.pool, e.pool);
  assert.equal(g.currentTurn, e.currentTurn);
  assert.deepEqual(g.tree.getCurrentNode().mark, e.tree.getCurrentNode().mark);
  assert.deepEqual(g.tree.getBranchHistory("main").map(n => n.id), e.tree.getBranchHistory("main").map(n => n.id));
  play(g);                                              // 讀回後照常下棋
  assert.equal(g.tree.getBranchHistory().length, e.tree.getBranchHistory().length + 1);

  // 壞掉的存檔：丟出錯誤，原本的局面不變
  const before = g.tree;
  assert.throws(() => g.restoreTree({ v: 1, nodes: [], branches: [] }));
  assert.equal(g.tree, before);
});

test("池子：被挑走的棋留下的空位由新抽的棋補上，其他棋不移動", () => {
  const e = new GameEngine({ rng: mulberry32(5) });
  for (let i = 0; i < 12 && !e.gameOver; i++) {
    const moves = e.legalMoves();
    if (!moves.length) { e.passTurn(); continue; }
    const before = [...e.pool];
    const slot = i % before.length;                      // 每次挑不同位置的棋
    const m = moves[0];
    assert.ok(e.playMove(m.r, m.c, before[slot]));
    if (e.gameOver) break;
    assert.equal(e.pool.length, before.length);
    before.forEach((id, k) => { if (k !== slot) assert.equal(e.pool[k], id); });
    assert.ok(!before.includes(e.pool[slot]));           // 空位補的是新抽的棋
  }
});
