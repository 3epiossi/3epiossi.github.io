import test from "node:test";
import assert from "node:assert/strict";
import { GameEngine } from "../src/core/game-engine.js";
import { findBestMoveForCPU, searchEngine, explainFiveSquares } from "../src/ai/ai-service.js";
import { mulberry32 } from "./helpers.js";

test("只會選合法位置", () => {
  const e = new GameEngine({ rng: mulberry32(21) });
  const res = findBestMoveForCPU(e.board, e.currentTurn, e.pool, { timeMs: 100 });
  assert.ok(res.chosen);
  assert.ok(e.findLegalMove(res.chosen.r, res.chosen.c));
  assert.ok(e.pool.includes(res.chosen.disc));
});

test("教練回傳前三名，附帶說明，且由高到低排序", () => {
  const e = new GameEngine({ rng: mulberry32(4) });
  const res = searchEngine(e.board, e.currentTurn, e.pool, { timeMs: 150, multiPV: true });
  const ranked = explainFiveSquares(e.board, e.currentTurn, res.scores, 3, e.pool);
  assert.ok(ranked.length >= 1 && ranked.length <= 3);
  for (const c of ranked) {
    assert.ok(e.findLegalMove(c.move.r, c.move.c));
    assert.ok(e.pool.includes(c.move.disc));
    assert.ok(c.explanation.summary.length > 0);
    assert.ok(c.explanation.pros.length > 0);
  }
  for (let i = 1; i < ranked.length; i++) assert.ok(ranked[i - 1].score >= ranked[i].score);
});

test("無合法位置時回傳 chosen = null", () => {
  const e = new GameEngine({ rng: mulberry32(1) });
  e.board = e.board.map(row => row.map(() => null));
  const res = findBestMoveForCPU(e.board, 1, e.pool, { timeMs: 50 });
  assert.equal(res.chosen, null);
});
